#!/bin/sh

# This script:
# 1- gathers information about the available disks, partitions,
# volumes, and bootloaders on the system. The information is then saved
# to a temporary file for later processing by the main DarwinDumper script.
#
# 2 - dumps any bootloader user config files it finds in an Extra or EFI
# folder at the same path as a found boot file.
#
# 3 - dumps the volume UUID's and GUID's to a UIDs.txt file.
#
# The idea for identifying boot sector code was taken from the original
# Chameleon package installer script where it checked for the existence of
# LILO. I'd since added further checks for the different stage0 versions
# and the windows disk signature to the later chameleon package installer
# scripts - see for example CheckDiskMicrocode.sh.
#
# This script makes use of Apple's plistbuddy which ships with the OS.
# However, under 10.5 I found plistbuddy returned incorrect values for
# large integers. As a result I have included the FAT binary plistbuddy
# from 10.6 in DarwinDumper's Resources/Tools folder which is used when
# this script is run on 10.6 and earlier.  

# It's been tested on 10.5, 10.6, 10.7 & 10.8. I'm aware of one issue
# under 10.5 where the disk size of the first disk has been shown as
# zero size but I've been unable to reproduce this behaviour.
#
# I would like to add detection for more stage 0 loaders, for example
# GRUB and anything else that people use in make the script more concise.
#
# Also note, that the current detection for existing known loaders is
# based on matching against known hex values so it relies on the code
# staying the same. If then, for example, the Chameleon boot0 code
# changes then it could affect identification.
#
# *************************************************************************************
# The script requires 5 arguments passed to it when called.
# 1 - Path    : Directory to save dumps
# 2 - 1 or 0  : Dump bootloader configuration files.
#               Creates a folder named BootloaderConfigFiles and in that, copies the
#               complete folder structure(s) leading to a pre-defined config file.
# 3 - 1 or 0  : Dump diskutil list & identify known bootloader code.
#               This option creates the following .txt files:
#               Hex dump of each disks' boot and partition sectors (1 file per disk).
#               diskutil list result.
#               /tmp/diskutilLoaderInfo.txt (an intermediary file for later processing).
# 4 - 1 or 0  : Dump Volume UUID's and Disk GUID's
#               Creates a .txt file named UIDs.txt.
# 5 - 1 or 0  : Dump disk partition table information.
#               Creates a .txt file for each disk.
#
# Note: 1 enables the routine, 0 disables the routine.
# *************************************************************************************
# 
# Blackosx (Thanks to STLVNUB for his help.)
# Thanks to STLVNUB, Slice and dmazar for extensive testing, bug fixing & suggestions 
#
# ---------------------------------------------------------------------------------------
Initialise()
{
    # String arrays for storing diskutil info.
    declare -a duContent
    declare -a duSize
    declare -a duVolumeName
    declare -a duIdentifier
    declare -a duWholeDisks
    declare -a allDisks
    
    diskScanFileFolder="BootSectDump"
    
    # If running this script locally then set BootSectDir,
    # otherwise get BootSectDir from passed argument.
    cdir="$( cd -P "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
    if [ "$1" == "" ]; then
        dumpFolderPath="${cdir}"
    else
        dumpFolderPath="$1"
    fi 
    cd "$cdir"; cd ..; 
    local toolsDir="$( pwd )"/Tools


    if [ "$2" == "0" ]; then
        gRunBootloaderConfigFiles=0
    else
        gRunBootloaderConfigFiles=1
        echo "S:diskLoaderConfigs" >> /tmp/dd_completed
    fi
    if [ "$3" == "0" ]; then
        gRunDiskutilAndLoaders=0
    else
        gRunDiskutilAndLoaders=1
        echo "S:diskUtilLoaders" >> /tmp/dd_completed
    fi
    if [ "$4" == "0" ]; then
        gRunVolumeXuids=0
    else
        gRunVolumeXuids=1
        echo "S:diskVolumeXuid" >> /tmp/dd_completed
    fi
    if [ "$5" == "0" ]; then
        gRunDiskPartitionInfo=0
    else
        gRunDiskPartitionInfo=1
        echo "S:diskPartitionInfo" >> /tmp/dd_completed
    fi
    
    fdisk440="$toolsDir/fdisk440"
    plistbuddy="$toolsDir/plistbuddy"
    
    gTMPDir=/tmp
    gBootSectDir="$dumpFolderPath"/$diskScanFileFolder
    gBootloaderConfigFilesDir="$dumpFolderPath"/BootloaderConfigFiles
    gBootloaderDriverFilesDir="$dumpFolderPath"/BootloaderDriverFiles
    gBootloadersTextBuildFile=""
    gXuidBuildFile="Device@Name@Volume UUID@Unique partition GUID"
    gXuidBuildFile="$gXuidBuildFile \n"
    gLogFile="${dumpFolderPath}"/DarwinDumper_log.txt 
    gESPMountPrefix="ddTempMp"
    gDataDir="$( pwd )"/Data
    UefiFileMatchList="$gDataDir/uefi_loaders.txt"
    gUefiKnownFiles=( $( < "$UefiFileMatchList" ) )
    gRootPriv=0
}

# ---------------------------------------------------------------------------------------
CheckRoot()
{
    if [ "`whoami`" != "root" ]; then
        #echo "Running this requires you to be root."
        #sudo "$0"
        gRootPriv=0
    else
        gRootPriv=1
    fi
}

# ---------------------------------------------------------------------------------------
CheckOsVersion()
{
    local osVer=`uname -r`
    local osVer=${osVer%%.*}
    local rootSystem=""
    
    if [ "$osVer" == "8" ]; then
	    rootSystem="Tiger"
    elif [ "$osVer" == "9" ]; then
	    rootSystem="LEO"
    elif [ "$osVer" == "10" ]; then
	    rootSystem="SL"
    elif [ "$osVer" == "11" ]; then
	    rootSystem="Lion"
    elif [ "$osVer" == "12" ]; then
	    rootSystem="ML"
	else 
	    rootSystem="Unknown"
    fi
    echo "$rootSystem"  # This line acts as a return to the caller.
}

# ---------------------------------------------------------------------------------------
DumpDiskUtilAndLoader()
{
    local checkSystemVersion
    local activeSliceNumber
    local diskPositionInArray
    local mbrBootCode
    local pbrBootCode
    local partitionActive
    local targetFormat
    local mountPointWasCreated
    local efiMountedIsVerified
    local espWasMounted=0
    local gpt=0
    local mounted
    local byteFiveTen=""
    local diskUtilInfoDump=""
    local fileSystemPersonality=""
    local mediaName=""
    local volumeName=""
    local partitionname=""
    local diskSectorDumpFile=""
    local diskUtilLoaderInfoFile="$gTMPDir"/diskutilLoaderInfo.txt
    local xuidFile="$gBootSectDir"/UIDs.txt
    
    # ---------------------------------------------------------------------------------------
    ConvertUnitPreSL()
    {
        local passedNumber="$1"
        local numberLength=$( echo "${#passedNumber}")
        local convertedNumber
    
        if [ $numberLength -le 15 ] && [ $numberLength -ge 13 ]; then # TB
            convertedNumber=$(((((passedNumber/1024)/1024)/1024)/1024))" TB"
        elif [ $numberLength -le 12 ] && [ $numberLength -ge 10 ]; then # GB
            convertedNumber=$((((passedNumber/1024)/1024)/1024))" GB"
        elif [ $numberLength -le 9 ] && [ $numberLength -ge 7 ]; then # MB
            convertedNumber=$(((passedNumber/1024)/1024))" MB"
        elif [ $numberLength -le 6 ] && [ $numberLength -ge 4 ]; then # KB
            convertedNumber=$((passedNumber/1024))" KB"  
        fi
        echo "$convertedNumber"
    }
    
    # ---------------------------------------------------------------------------------------
    ConvertUnit()
    {
        local passedNumber="$1"
        local numberLength=$( echo "${#passedNumber}")
        local convertedNumber
    
        if [ $numberLength -le 15 ] && [ $numberLength -ge 13 ]; then # TB
            convertedNumber=$((passedNumber/1000000000000))" TB"
        elif [ $numberLength -le 12 ] && [ $numberLength -ge 10 ]; then # GB
            convertedNumber=$((passedNumber/1000000000))" GB"
        elif [ $numberLength -le 9 ] && [ $numberLength -ge 7 ]; then # MB
            convertedNumber=$((passedNumber/1000000))" MB"
        elif [ $numberLength -le 6 ] && [ $numberLength -ge 4 ]; then # KB
            convertedNumber=$((passedNumber/100))" KB"  
        fi
        echo "$convertedNumber"
    }

    # ---------------------------------------------------------------------------------------
    BuildDiskUtilStringArrays()
    {
        # Six global string arrays are used for holding the disk information
        # that the DumpDiskUtilAndLoader() function walks through and uses.
        # They are declared in function Initiase().
    
        local checkSystemVersion
        local recordAdded=0
        local identifierFound=0
        local contentFound=0
        local sizeFound=0
        local humanSize=0
        local volumeName=""
        local oIFS="$IFS"
        IFS=$'\n'
    
        diskutil list -plist > /tmp/du.plist
        checkSystemVersion=$(CheckOsVersion)
        if [ "$checkSystemVersion" == "Tiger" ] || [ "$checkSystemVersion" == "LEO" ] || [ "$checkSystemVersion" == "SL" ]; then
            # Here I assume Tiger gives the same output as LEO and Snow LEO.
	    
	        # This section makes use of Apple's plistbuddy from OS X 10.6.
	        # TO DO - Remove the need to use it so I no longer have to include
	        # the binary in the DarwinDumper tools directory.
	    
    	    local allDisks=( $("$plistbuddy" -c "print :AllDisks" /tmp/du.plist) )
    	    local wholeDisks=( $("$plistbuddy" -c "print :WholeDisks" /tmp/du.plist) )
    	    for (( n=0; n<${#allDisks[@]}; n++ ))
            do
                if [[ "${allDisks[$n]}" == *disk* ]]; then
                    duIdentifier+=("${allDisks[$n]#*    }") 
                    diskutil info -plist /dev/${duIdentifier[$n-1]} > /tmp/duSliceinfo.plist
                    if [ -f "/tmp/duSliceinfo.plist" ]; then
                        duContent+=( $("$plistbuddy" -c "print :Content" /tmp/duSliceinfo.plist) )
                        sizeRead=$("$plistbuddy" -c "print :TotalSize" /tmp/duSliceinfo.plist)
                        if [ "$checkSystemVersion" == "Tiger" ] || [ "$checkSystemVersion" == "LEO" ]; then
                            humanSize=$(ConvertUnitPreSL "${sizeRead}")
                        else
                            humanSize=$(ConvertUnit "${sizeRead}")
                        fi
                        duSize+=("$humanSize")
                        volumeName=( $("$plistbuddy" -c "print :VolumeName" /tmp/duSliceinfo.plist) )
                        if [ ! "${volumeName}" == "" ]; then
                            duVolumeName+=( "${volumeName}" )
                        else
                            duVolumeName+=(" ")
                        fi
                        (( recordAdded++ ))
                        rm /tmp/duSliceinfo.plist
                    fi
                fi
            done
        
            for (( n=0; n<${#wholeDisks[@]}; n++ ))
            do
                if [[ "${wholeDisks[$n]}" == *disk* ]]; then
                    duWholeDisks+=("${wholeDisks[$n]#*    }")
                fi
            done  
         
            IFS="$oIFS"
            rm /tmp/du.plist  
                 
    	elif [ "$checkSystemVersion" == "Lion" ] || [ "$checkSystemVersion" == "ML" ]; then
	
	        # for OS X 10.7 and newer, we can use Apple's plistbuddy from the user's system.
	
            local diskUtilListDump=( $(/usr/libexec/plistbuddy -c "print :AllDisksAndPartitions" /tmp/du.plist) )
            local wholeDisks=( $(/usr/libexec/plistbuddy -c "print :WholeDisks" /tmp/du.plist) )

            for (( n=0; n<${#diskUtilListDump[@]}; n++ ))
            do  
                if [ $contentFound -eq 1 ]; then  
                    if [[ "${diskUtilListDump[$n]}" == *VolumeName* ]]; then
                        duVolumeName+=("${diskUtilListDump[$n]#*VolumeName = }")
                    else
                    	duVolumeName+=(" ")
                    fi
                    contentFound=0
                 fi
    
                if [ $sizeFound -eq 1 ]; then 
                    if [[ "${diskUtilListDump[$n]}" == *Content* ]]; then
                        duContent+=("${diskUtilListDump[$n]#*Content = }")
                        contentFound=1
                        sizeFound=0
                    fi
                fi
      
                if [ $identifierFound -eq 1 ]; then
                    if [[ "${diskUtilListDump[$n]}" == *Size* ]]; then
                        humanSize=$(ConvertUnit "${diskUtilListDump[$n]#*Size = }")
                        duSize+=("$humanSize")
                        sizeFound=1
                    fi
                identifierFound=0
                fi
    
                if [[ "${diskUtilListDump[$n]}" == *Device* ]]; then
                    duIdentifier+=("${diskUtilListDump[$n]#*DeviceIdentifier = }")
                    (( recordAdded++ ))
                    identifierFound=1
                fi
            done

            for (( n=0; n<${#wholeDisks[@]}; n++ ))
            do
                if [[ "${wholeDisks[$n]}" == *disk* ]]; then
                    duWholeDisks+=("${wholeDisks[$n]#*    }")
                fi
            done

            IFS="$oIFS"
            rm /tmp/du.plist
        fi

        # Before leaving, check all string array lengths are equal.
        if [ ${#duVolumeName[@]} -ne $recordAdded ] || [ ${#duContent[@]} -ne $recordAdded ] || [ ${#duSize[@]} -ne $recordAdded ] || [ ${#duIdentifier[@]} -ne $recordAdded ]; then
            echo "Error- Disk Utility string arrays are not equal lengths!"
            echo "records=$recordAdded V=${#duVolumeName[@]} C=${#duContent[@]} S=${#duSize[@]} I=${#duIdentifier[@]}"
            exit 1
        fi
    
        #DEBUG 
        #for (( n=0; n<$recordAdded; n++ ))
        #do
        #    echo "records=$recordAdded V=${duVolumeName[$n]} C=${duContent[$n]} S=${duSize[$n]} I=${duIdentifier[$n]}"
        #done
    }
    
    # ---------------------------------------------------------------------------------------
    BuildXuidTextFile()
    {
        local passedTextLine="$1"

        if [ ! "$passedTextLine" == "" ]; then
            gXuidBuildFile="$gXuidBuildFile"$(printf "$passedTextLine\n")
            gXuidBuildFile="$gXuidBuildFile \n" 
        fi
    }
     
    # ---------------------------------------------------------------------------------------
    GrabXUIDs()
    {
        local passedIdentifier="$1" 
        local passedVolumeName="$2"
        local uuid=""
        local guid=""
        
        uuid=`Diskutil info /dev/$passedIdentifier | grep "Volume UUID:" | awk {'print $3}'`
        guid=`ioreg -lxw0 -pIODeviceTree | grep -A 10 $passedIdentifier | sed -ne 's/.*UUID" = //p' | tr -d '"'`
        if [[ "$passedVolumeName" == "$gESPMountPrefix"* ]]; then
            passedVolumeName="EFI"
        fi
        # Check for a blank UUID and replace with spaces so the padding is correct
        # in the UIDs.txt file.
        if [ "${uuid}" == "" ]; then
            uuid="                                    "
        fi
        BuildXuidTextFile "$passedIdentifier@/Volumes/${passedVolumeName}@${uuid}@${guid}"
    }
    
    # ---------------------------------------------------------------------------------------
    CheckForBootFiles()
    {
        local passedVolumeName="/Volumes/$1"
        local passedDevice="$2"
        local bootFileCount=0
        local bootFiles=()
        local loaderVersion=""
        local firstRead=""
        local versionInfo=""
        local refitString=""
        local oIFS="$IFS"
        local checkMagic=""
        
        # Start checking for filenames beginning with boot
        #�ignoring any boot* files with .extensions.
        bootFileCount=`find 2>/dev/null "${passedVolumeName}"/boot* -depth 0 -type f ! -name "*.*" | wc | awk '{print $1}'`
        if [ $bootFileCount -gt 0 ]; then
            (( bootFileCount-- )) # reduce by one so for loop can run from zero.
            IFS=$'\n'
            bootFiles=( $(find "${passedVolumeName}"/boot* -depth 0 -type f ! -name "*.*" 2>/dev/null) )
            IFS="$oIFS"
            for (( b=0; b<=$bootFileCount; b++ ))
            do
                loaderVersion=""
                versionInfo=""
                if [ -f "${bootFiles[$b]}" ]; then
                
                    # Check file is not a stage 0 or stage 1 file
                    checkMagic=$(dd 2>/dev/null ibs=2 count=1 skip=255 if="${bootFiles[$b]}" | xxd -p)
                    if [ ! "$checkMagic" == "55aa" ]; then
                        
                        # Try to match a string inside the boot file.         
                        firstRead=$( strings "${bootFiles[$b]}" | grep -E 'Chameleon|Clover|RevoBoot|Windows Boot|EFILDR20' | sed -n '1p' )
                        if [[ "$firstRead" == *Chameleon* ]]; then
                            loaderVersion=$( strings "${bootFiles[$b]}" | sed -ne 's/.*Darwin\/x86 boot//p' )
                            loaderVersion="${loaderVersion#*- }"
                        elif [[ "$firstRead" == *Clover* ]]; then
                            loaderVersion="Clover"
                            # Try 2 attempts to get Clover boot file version
                            # 1 - read 'Clover revision' string from binary
                            versionInfo=$( strings "${bootFiles[$b]}" | grep -E 'Clover revision' )                        
                            if [ ! "$versionInfo" == "" ]; then
                                 versionInfo="${versionInfo##*: }"
                            fi
                            # 2 - read version from the string above 'Starting rEFIt rev'
                            if [ "$versionInfo" == "" ]; then
                                versionInfo=$( grep -B 1 -a "Starting rEFIt rev" "${bootFiles[$b]}" | head -1 )
                            fi

                            if [ ! "$versionInfo" == "" ]; then
                                loaderVersion="${loaderVersion}R${versionInfo}"
                            else
                                loaderVersion="${loaderVersion}"
                            fi
                        elif [[ $firstRead == *RevoBoot* ]]; then
                            loaderVersion="$firstRead"
                        elif [[ $firstRead == *Windows* ]]; then
                            loaderVersion="Windows Boot Manager" # Can we print version??
                        elif [[ $firstRead == *EFILDR* ]]; then
                            loaderVersion="dmazar XPC Efildr20 loader"
                        fi
                        BuildBootLoadersTextFile "BF:${bootFiles[$b]##*/}"
                        BuildBootLoadersTextFile "S2:$loaderVersion"
                    fi
                fi 
        	done
        fi
    }

    # ---------------------------------------------------------------------------------------
    CheckForEfildrFiles()
    {
        local passedVolumeName="/Volumes/$1"
        local passedDevice="$2"
        local efildFileCount=0
        local efildFiles=()
        local loaderVersion
        local oIFS="$IFS"
        local checkMagic=""
    
        # Start checking for filenames beginning with boot
        #�ignoring any boot* files with .extensions.
        efildFileCount="$( find 2>/dev/null "${passedVolumeName}"/Efild* -type f ! -name "*.*"| wc | awk '{print $1}' )"
        if [ $efildFileCount -gt 0 ]; then
            (( efildFileCount-- )) # reduce by one so for loop can run from zero.
            IFS=$'\n'
            efildFiles=( $(find "${passedVolumeName}"/Efild* -type f ! -name "*.*" 2>/dev/null) )
            IFS="$oIFS"
            for (( b=0; b<=$efildFileCount; b++ ))
            do
                loaderVersion=""
                bytesRead=$( dd 2>/dev/null if=${efildFiles[$b]} bs=512 count=1 | perl -ne '@a=split"";for(@a){printf"%02x",ord}'  )
                if [ "${bytesRead:1020:2}" == "55" ]; then
                    case "${bytesRead:0:8}" in
                        "eb589049")
                            case "${bytesRead:286:2}" in 
                                "79") loaderVersion="XPC Efildr20" ;;
                                "42") loaderVersion="EBL Efildr20" ;;
                            esac
                            ;;
                        "eb0190bd") 
                            case "${bytesRead:286:2}" in 
                                "3b") loaderVersion="XPC Efildgpt" ;;
                            esac
                            ;;
                    esac
                fi
                BuildBootLoadersTextFile "BF:${efildFiles[$b]##*/}"
                if [ ! "$loaderVersion" == "" ]; then
                    BuildBootLoadersTextFile "S2:$loaderVersion"
                fi
            done
        fi
    }
    
    # ---------------------------------------------------------------------------------------
    CheckForUEFIfiles()
    {
        local passedVolumeName="/Volumes/$1"
        local passedDevice="$2"
        local loaderVersion=""
        local lineRead=""
    
        for (( n=0; n<${#gUefiKnownFiles[@]}; n++ )) #gUefiKnownFiles is built in Initialise()
        do
            lineRead="${gUefiKnownFiles[$n]}"
            versionInfo=""
            if [ -f "${passedVolumeName}${lineRead}" ]; then
                if [ "${lineRead##*/}" == "BootX64.efi" ]; then
                    # This could be one of many files renamed as BootX64.efi
                    versionInfo=$( strings "${passedVolumeName}${lineRead}" | grep 'Clover revision' | head -n 1  )                        
                    if [ ! "$versionInfo" == "" ]; then
                         versionInfo="CloverR${versionInfo##*: }"
                    else
                        versionInfo=$( strings "${passedVolumeName}${lineRead}" | grep microsoft | head -n 1  )                        
                        if [ ! "$versionInfo" == "" ]; then
                             versionInfo="Windows"
                        else
                            versionInfo=$( strings "${passedVolumeName}${lineRead}" | grep elilo | head -n 1  )                        
                            if [ ! "$versionInfo" == "" ]; then
                                 versionInfo="ELILO"
                            fi
                        fi
                    fi
                fi
                if [[ "${lineRead##*/}" == Clover* ]]; then
                    versionInfo=$( strings "${passedVolumeName}${lineRead}" | grep 'Clover revision' )                        
                    if [ ! "$versionInfo" == "" ]; then
                         versionInfo="R${versionInfo##*: }"
                    fi
                fi
                #BuildBootLoadersTextFile "UF:${lineRead##*/}"
                BuildBootLoadersTextFile "UF:$lineRead" # Include full path.
                BuildBootLoadersTextFile "U2:$versionInfo"
            fi
        done
    }
   
    # ---------------------------------------------------------------------------------------
    FindAndCopyUserPlistFiles()
    {
        local passedVolumeName="/Volumes/$1"
        local passedDevice="$2"
        local searchPlist=""
        local dirToMake=""
        local oIFS="$IFS"
    
        echo "       Searching for Bootloader files on $passedDevice" >> "${gLogFile}"
    
        IFS=$'\n'
        if [ -d "${passedVolumeName}/Extra" ]; then
            searchPlist=""
            searchPlist=( $(find "${passedVolumeName}/Extra" -type f -name 'org.chameleon.Boot.plist') )
            if [ ! "$searchPlist" == "" ]; then
                for (( p=0; p<${#searchPlist[@]}; p++ ))
                do
                    dirToMake="${searchPlist[$p]%/*}"
                    dirToMake=$( echo "$dirToMake" | sed "s/\/Volumes\//${passedDevice}-/g" )
                    mkdir -p "$gBootloaderConfigFilesDir/$dirToMake"
                    cp "${searchPlist[$p]}" "$gBootloaderConfigFilesDir/$dirToMake"
                    # Copy also a SMBIOS.plist file if it exists.
                    searchPath="${searchPlist[$p]%/*}"
                    if [ -f "$searchPath"/SMBIOS.plist ]; then
                        cp "$searchPath"/SMBIOS.plist "$gBootloaderConfigFilesDir/$dirToMake"
                    fi
                done
            fi
        fi	

        if [ -d "${passedVolumeName}/EFI" ]; then
            # Could be with Clover, XPC or Genuine Mac
            # Check for Clover config.plist file
            searchPlist=""
            searchPlist=( $(find "${passedVolumeName}/EFI" -type f -name 'config.plist' 2>/dev/null) )
            if [ ! "$searchPlist" == "" ]; then
                for (( p=0; p<${#searchPlist[@]}; p++ ))
                do
                    dirToMake="${searchPlist[$p]%/*}"
                    noPlist=`echo $dirToMake | grep "System Product Name"` # No need to save this (i think)
                    if [ "$dirToMake" != "$noPlist" ]; then
                        if [[ "$1" == "$gESPMountPrefix"* ]]; then
                            dirToMake="${passedDevice}-EFI"
                        else
                            dirToMake=$( echo "$dirToMake" | sed "s/\/Volumes\//${passedDevice}-/g" )
                        fi
                        mkdir -p "$gBootloaderConfigFilesDir/$dirToMake"
                        cp "${searchPlist[$p]}" "$gBootloaderConfigFilesDir/$dirToMake"
                    fi
                done
                FindListAndCopyCloverDriverFiles "$1" "${passedDevice}"
                FindAndCopyRefitConfFile "$1" "${passedDevice}"
            fi
            
            # Check for XPC settings.plist file
            searchPlist=""
            searchPlist=( $(find "${passedVolumeName}/EFI" -type f -name 'settings.plist' 2>/dev/null) )
            for (( p=0; p<${#searchPlist[@]}; p++ ))
            do
                dirToMake="${searchPlist[$p]%/*}"
                dirToMake=$( echo "$dirToMake" | sed "s/\/Volumes\//${passedDevice}-/g" )
                mkdir -p "$gBootloaderConfigFilesDir/$dirToMake"
                cp "${searchPlist[$p]}" "$gBootloaderConfigFilesDir/$dirToMake"
            done
        fi	
        
        if [ -d "${passedVolumeName}/Library" ]; then
            searchPlist=""
            searchPlist=( $(find "${passedVolumeName}/Library" -type f -name 'com.apple.Boot.plist' 2>/dev/null) )
            for (( p=0; p<${#searchPlist[@]}; p++ ))
            do
                dirToMake="${searchPlist[$p]%/*}"
                dirToMake=$( echo "$dirToMake" | sed "s/\/Volumes\//${passedDevice}-/g" )
                mkdir -p "$gBootloaderConfigFilesDir/$dirToMake"
                cp "${searchPlist[$p]}" "$gBootloaderConfigFilesDir/$dirToMake"
            done
        fi
        IFS="$oIFS"
    }
    
    # ---------------------------------------------------------------------------------------
    FindListAndCopyCloverDriverFiles()
    {
        local passedVolumeName="/Volumes/$1/EFI"
        local passedDevice="$2"
        local driverFolders=(drivers32 drivers64 drivers64UEFI)

        for (( q=0; q<${#driverFolders[@]}; q++ ))
        do
            if [ -d "${passedVolumeName}"/"${driverFolders[$q]}" ]; then
                if [[ "$1" == "$gESPMountPrefix"* ]]; then
                    dirToMake="${passedDevice}-EFI"/"${driverFolders[$q]}"
                else
                    dirToMake="${passedVolumeName}"/"${driverFolders[$q]}"
                    dirToMake=$( echo "$dirToMake" | sed "s/\/Volumes\//${passedDevice}-/g" )
                fi
                mkdir -p "$gBootloaderDriverFilesDir/$dirToMake"
                cp -R "${passedVolumeName}"/"${driverFolders[$q]}"/* "$gBootloaderDriverFilesDir/$dirToMake"
                ls -l "${passedVolumeName}"/"${driverFolders[$q]}" > "$gBootloaderDriverFilesDir/$dirToMake.txt"
            fi
        done
    }
    
    # ---------------------------------------------------------------------------------------
    FindAndCopyRefitConfFile()
    {
        local passedVolumeName="$1"
        local passedDevice="$2"
        local pathToSearch="/Volumes/$passedVolumeName/EFI/BOOT"

        if [ -f "${pathToSearch}"/refit.conf ]; then
            if [[ "$1" == "$gESPMountPrefix"* ]]; then
                dirToMake="${passedDevice}-EFI"
            else
                dirToMake="${pathToSearch}"
                dirToMake=$( echo "$dirToMake" | sed "s/\/Volumes\//${passedDevice}-/g" )
            fi
            mkdir -p "$gBootloaderConfigFilesDir/$dirToMake"
            cp "${pathToSearch}"/refit.conf "$gBootloaderConfigFilesDir/$dirToMake"
        fi
    }
    
    # ---------------------------------------------------------------------------------------
    GetDiskMediaName()
    {
        local passedDevice="$1"
        local diskname=$(diskutil info "$passedDevice" | grep "Media Name")
    
        diskname="${diskname#*:      }"
        echo "$diskname" # This line acts as a return to the caller.
    }

    # ---------------------------------------------------------------------------------------
    FindMbrBootCode()
    {
        local passedDevice="$1"
        local stage0CodeDetected=""
        local bytesRead=$( dd 2>/dev/null if="/dev/$passedDevice" bs=512 count=1 | perl -ne '@a=split"";for(@a){printf"%02x",ord}' )
        if [ "${bytesRead:1020:2}" == "55" ]; then
            case "${bytesRead:210:6}" in
                "0a803c") stage0CodeDetected="Chameleon boot0" ;;
                "0b807c") stage0CodeDetected="Chameleon boot0hfs" ;;
                "742b80") stage0CodeDetected="Chameleon boot0md" ;;
                "ee7505") stage0CodeDetected="Chameleon boot0md (dmazar v1)" ;;
                "742b80") stage0CodeDetected="Chameleon boot0md (dmazar boot0workV2)" ;;
                "a300e4") stage0CodeDetected="Chameleon boot0 (dmazar timing)" ;;
                "060000") stage0CodeDetected="DUET" ;;
                "75d280") stage0CodeDetected="Windows XP MBR" ;;
                "760868") stage0CodeDetected="Windows Vista/7 MBR" ;;
                "0288c2") stage0CodeDetected="GRUB" ;;
            esac
            # If code is not yet identified then check is it blank?
            if [ "$stage0CodeDetected" == "" ]; then
                if [ "${bytesRead:0:32}" == "00000000000000000000000000000000" ] ; then 
                    stage0CodeDetected="None"
                fi
            fi
            # If code is not yet identified then check for known structures
            if [ "$stage0CodeDetected" == "" ]; then
                if [ "${bytesRead:164:16}" == "4641543332202020" ] ; then #FAT32
                    if [ "${bytesRead:6:16}" == "4d53444f53352e30" ]; then
                        stage0CodeDetected="FAT32 MSDOS 5.0 Boot Disk"
                    fi
                    if [ "${bytesRead:262:20}" == "4e6f6e2d73797374656d" ]; then
                        stage0CodeDetected="FAT32 Non-System Disk"
                    fi
                fi
                if [ "${bytesRead:108:16}" == "4641543136202020" ]; then #FAT16
                    if [ "${bytesRead:6:16}" == "4d53444f53352e30" ]; then
                        stage0CodeDetected="FAT16 MSDOS 5.0 Boot Disk"
                    fi
                    if [ "${bytesRead:206:20}" == "4e6f6e2d73797374656d" ]; then
                        stage0CodeDetected="FAT16 Non-System Disk"
                    fi
                fi
                
            fi
            # If code is not yet identified then mark as Unknown.
            if [ "$stage0CodeDetected" == "" ]; then
                stage0CodeDetected="Unknown (If you know, please report)."
            fi
        fi
        
        # Check of existence of the string GRUB as it can
        # appear at a different offsets depending on version.
        if [[ "${bytesRead}" == *475255422000* ]]; then
            stage0CodeDetected="GRUB"
            # TO DO - How to detect grub version?
        fi
        
        echo "$stage0CodeDetected" # This line acts as a return to the caller.
    }
    
    # ---------------------------------------------------------------------------------------
    FindPbrBootCode()
    {
        local passedDevice="$1"
        local stage1CodeDetected=""
        local pbrBytesToGrab=1024
        local bytesRead=$( dd 2>/dev/null if="/dev/r$passedDevice" bs=$pbrBytesToGrab count=1 | perl -ne '@a=split"";for(@a){printf"%02x",ord}' )
        local byteFiveTen="${bytesRead:1020:2}"

    	if [ "$byteFiveTen" == "55" ]; then         
            if [ "${bytesRead:0:16}" == "fa31c08ed0bcf0ff" ]; then
                case "${bytesRead:126:2}" in
                    "a3") stage1CodeDetected="Chameleon boot1h" ;;
                    "a2") stage1CodeDetected="Clover boot1h" ;;
                    "66") case "${bytesRead:194:4}" in 
                            "d007") stage1CodeDetected="Clover boot1h2" ;;
                            "8813") stage1CodeDetected="Clover boot1altV3" ;;
                          esac
                esac
            fi
            if [ "${bytesRead:0:4}" == "e962" ] && [ "${bytesRead:180:12}" == "424f4f542020" ]; then
                case "${bytesRead:290:2}" in
                    "bf") stage1CodeDetected="Chameleon boot1f32" ;;
                    "b9") stage1CodeDetected="Clover boot1f32alt" ;;
                esac
            fi
            if [ "${bytesRead:0:4}" == "eb58" ]; then
                case "${bytesRead:180:12}" in
                    "33c98ed1bcf4") stage1CodeDetected="Windows FAT32 NTLDR"
                                    pbrBytesToGrab=512 ;;
                    "8d36e301e8fc") stage1CodeDetected="FAT32 DUET"
                                    pbrBytesToGrab=512 ;;
                    "fa31c08ed0bc")
                    if [ "${bytesRead:142:6}" == "454649" ]; then 
                        stage1CodeDetected="Apple EFI"
                    else
                        stage1CodeDetected="FAT32 Non System disk"
                    fi
                    ;;
                esac
            elif [ "${bytesRead:0:4}" == "eb76" ] && [ "${bytesRead:6:16}" == "4558464154202020" ]; then #exFAT
                if [ "${bytesRead:1024:32}" == "00000000000000000000000000000000" ] ; then 
                    #stage1CodeDetected="exFAT Blank"
                    stage1CodeDetected="None"
                fi
                if [ "${bytesRead:1028:28}" == "42004f004f0054004d0047005200" ] ; then 
                    stage1CodeDetected="Windows exFAT NTLDR"
                fi
            elif [ "${bytesRead:0:4}" == "b800" ] && [ "${bytesRead:180:12}" == "5033c08ec0bf" ]; then
                stage1CodeDetected="GPT DUET"
            elif [ "${bytesRead:0:4}" == "eb3c" ] && [ "${bytesRead:180:12}" == "1333c08ac6fe" ]; then
                stage1CodeDetected="FAT16 DUET"
                pbrBytesToGrab=512
            elif [ "${bytesRead:0:16}" == "eb52904e54465320" ]; then
                stage1CodeDetected="Windows NTFS NTLDR"
                pbrBytesToGrab=512
            fi
            # Check of existence of the string GRUB as it can
            # appear at a different offsets depending on version.
            if [[ "${bytesRead}" == *475255422000* ]]; then
                stage1CodeDetected="GRUB"
                # TO DO - How to detect grub version?
                pbrBytesToGrab=512
            fi
            # If code is not yet identified then mark as Unknown.
            if [ "$stage1CodeDetected" == "" ]; then
                stage1CodeDetected="Unknown (If you know, please report)."
            fi
        fi    
        echo "${stage1CodeDetected}:$byteFiveTen" # This line acts as a return to the caller.
        if [ "$pbrBytesToGrab" == "1024" ]; then # need to pass this back to caller, exporting does not work
        	return 0
        else
        	return 1
        fi		
    }
    
    # ---------------------------------------------------------------------------------------
    GetEspMountPoint()
    {
         local passedDevice="$1"
         local passedTargetFormat="$2"
         local mountPoint=""
         
         # Note - recent versions of OS X's mount tool can now use: mount -t hfs & mount -t msdos.
         # However, is this supported in OS X 10.5 & 10.6 ?
         
         local checkMountPoint=$( df -T hfs,msdos | grep "$passedDevice" | sed -ne 's/.*Volumes\///p' )
         if [ "$checkMountPoint" == "" ]; then            
             # Create a temporary mountpoint
             local mountPoint=`/usr/bin/mktemp -d /Volumes/${gESPMountPrefix}XXXXXXXXX`
             if [ ! "$mountPoint" == "" ]; then
                if [ "$passedTargetFormat" == "hfs" ]; then
                    mount_hfs "$passedDevice" "$mountPoint"
                elif [ "$passedTargetFormat" == "msdos" ]; then
                    mount_msdos -u 0 -g 0 "$passedDevice" "$mountPoint"
                fi
                mountPoint="${mountPoint##*/}"
             fi
         else
             # User already has the ESP mounted.
             mountPoint=${checkMountPoint}
         fi
         echo "$mountPoint" # This line acts as a return to the caller.
    }
    
    # ---------------------------------------------------------------------------------------
    UnmountMountedEsp()
    {
        # This is called only if we created a mount point earlier.
        local passedMountPoint="$1"
        local attempts=1
        
        while [ "$( df | grep /Volumes/$passedMountPoint )" ] && [ $attempts -lt 5 ]; do
            umount -f "/Volumes/$passedMountPoint" && rm -rf "/Volumes/$passedMountPoint"
            (( attempts++ ))
        done
        if [ $attempts -eq 5 ]; then
            echo "Failed to unmount a volume named 'EFI' "
        fi
    }
    
    # ---------------------------------------------------------------------------------------
    SearchStringArraysdu()
    {
        local arrayToSearch="$1"
        local itemToFind="$2"
        local loopCount=0
        local itemfound=0
    
        if [ "$arrayToSearch" == "duIdentifier" ]; then
            while [ "$itemfound" -eq 0 ] && [ $loopCount -le "${#duIdentifier[@]}" ]; do
                if [ "${duIdentifier[$loopCount]}" == "$itemToFind" ]; then
                    itemfound=1
                fi
                (( loopCount++ ))
            done
            if [ $itemfound -eq 1 ]; then
                (( loopCount-- ))
                echo $loopCount # This line acts as a return to the caller.
            fi
        fi
    }

    # ---------------------------------------------------------------------------------------
    BuildBootLoadersTextFile()
    {
        local passedTextLine="$1"

        if [ ! "$passedTextLine" == "" ]; then
            gBootloadersTextBuildFile="$gBootloadersTextBuildFile"$(printf "$passedTextLine\n")
            gBootloadersTextBuildFile="$gBootloadersTextBuildFile \n" 
        fi
    }
    
     # ---------------------------------------------------------------------------------------
    BuildPartitionTableInfoTextFile()
    {
        local passedDevice="/dev/$1"
        local outFile="${gBootSectDir}/${1}-PartitionTableInfo.txt"
        local passedName="$2"
        local passedSize="$3"
        
        if [ ! "$passedDevice" == "" ]; then
            echo "============================================================================
$passedDevice - $passedName - $passedSize
----------------------------------------------------------------------------" >> "$outFile"
            if [ $gRootPriv -eq 1 ]; then
                gpt -r show "$passedDevice" >> "$outFile"
                echo "" >> "$outFile"
                "$fdisk440" "$passedDevice" >> "$outFile"
            else
                echo "** Root privileges required to read further info." >> "$outFile"
            fi
        fi
    }
    
    # ---------------------------------------------------------------------------------------
    
    echo "       Preparing to read disks...
       Note: There may be a delay if any disks are sleeping" >> "${gLogFile}"

    if [ $gRunDiskutilAndLoaders -eq 1 ] || [ $gRunDiskPartitionInfo -eq 1 ] || [ $gRunVolumeXuids -eq 1 ]; then
        mkdir $gBootSectDir
    fi
    
    if [ $gRunDiskutilAndLoaders -eq 1 ]; then
        diskutil list > "$gBootSectDir/diskutil_list.txt"
    fi
    BuildDiskUtilStringArrays

    # Loop through each disk
    for (( d=0; d<${#duWholeDisks[@]}; d++ ))
    do
        diskPositionInArray=$(SearchStringArraysdu "duIdentifier" "${duWholeDisks[$d]}")
        diskMediaName=$(GetDiskMediaName "/dev/${duWholeDisks[$d]}")
        echo "       Scanning disk: ${duWholeDisks[$d]}" >> "${gLogFile}"
        if [ $gRootPriv -eq 1 ]; then
            activeSliceNumber=$( fdisk -d "/dev/r${duWholeDisks[$d]}" | grep -n "*" | awk -F: '{print $1}' )
        fi
        mbrBootCode=$(FindMbrBootCode "${duWholeDisks[$d]}")
        BuildBootLoadersTextFile "WD:/dev/${duWholeDisks[$d]}"
        BuildBootLoadersTextFile "DN:$diskMediaName"
        BuildBootLoadersTextFile "DS:${duSize[$diskPositionInArray]}"
        BuildBootLoadersTextFile "DT:${duContent[$diskPositionInArray]}"
        BuildBootLoadersTextFile "S0:$mbrBootCode"
        if [ $gRunDiskPartitionInfo -eq 1 ]; then
            echo "       Reading partition info for: ${duWholeDisks[$d]}" >> "${gLogFile}"
            BuildPartitionTableInfoTextFile "${duWholeDisks[$d]}" "$diskMediaName" "${duSize[$diskPositionInArray]}"
        fi
        if [ $gRunDiskutilAndLoaders -eq 1 ]; then
            # Prepare file dump for disk sectors
            diskSectorDumpFile="$gBootSectDir/${duWholeDisks[$d]}-${diskMediaName}-${duSize[$diskPositionInArray]}.txt"
            echo "${duWholeDisks[$d]} - $diskMediaName - ${duSize[$diskPositionInArray]}" >> "$diskSectorDumpFile"
            echo "MBR: First 512 bytes    Code Detected: $mbrBootCode" >> "$diskSectorDumpFile"
        
            # Dump MBR to file
            if [ $gRootPriv -eq 1 ]; then
                xxd -l512 "/dev/${duWholeDisks[$d]}" >> "$diskSectorDumpFile"
            else
                echo "** Root privileges required to read further info." >> "$diskSectorDumpFile"
            fi
        fi
        
        gpt=0
        
        # Loop through each volume for current disk, writing details each time
        for (( v=0; v<${#duIdentifier[@]}; v++ ))
        do
            if [[ ${duIdentifier[$v]} == ${duWholeDisks[$d]} ]] && [ "${duContent[$v]}" == "GUID_partition_scheme" ]; then
                gpt=1
            fi
            if [[ ${duIdentifier[$v]} == ${duWholeDisks[$d]}* ]] && [[ ! ${duIdentifier[$v]} == ${duWholeDisks[$d]} ]] ; then   
                
                # If this slice is active then add asterisk
                partitionActive=" "
                if [ "${duIdentifier[$v]##*s}" == "$activeSliceNumber" ]; then 
                    partitionActive="*" 
                fi
    
                # Is the VolumeName empty or contains only whitespace?
                if [ "${duVolumeName[$v]}" == "" ] || [[ "${duVolumeName[$v]}" =~ ^\ +$ ]] ;then 
                    diskUtilInfoDump=$(diskutil info "${duIdentifier[$v]}")
                    fileSystemPersonality=$(echo "${diskUtilInfoDump}" | grep -F "File System Personality")
                    fileSystemPersonality=${fileSystemPersonality#*:  }
                    mediaName=$(echo "${diskUtilInfoDump}" | grep "Media Name")
                    mediaName=${mediaName#*:      }
                    volumeName=$(echo "${diskUtilInfoDump}" | grep "Volume Name")
                    volumeName=${volumeName#*:              }
                    if [ ! "$fileSystemPersonality" == "" ]; then
                        if [ "$fileSystemPersonality" == "NTFS" ]; then
                            partitionname=$mediaName
                        else
                            partitionname=$volumeName
                        fi
                    else
                        if [ "$volumeName" == "Apple_HFS" ]; then
                            partitionname=$volumeName
                        else
                            partitionname=$mediaName
                        fi
                    fi
                else
                    partitionname="${duVolumeName[$v]}"
                fi

                if [ $gRunDiskutilAndLoaders -eq 1 ]; then
                    returnValue=$(FindPbrBootCode "${duIdentifier[$v]}")
                    #Note: FindPbrBootCode returns $pbrBootCode":"$byteFiveTen"
                    pbrBootCode="${returnValue%:*}"
                    byteFiveTen="${returnValue##*:}"
                    if [ $? -eq 0 ];then
                        pbrBytesToGrab=1024
	    		    else
        	    		pbrBytesToGrab=512
	        		fi

		        	# Dump PBR to file
                    echo "" >> "$diskSectorDumpFile"
                    echo "${duIdentifier[$v]} - $partitionname - ${duSize[$v]}"  >> "$diskSectorDumpFile"
                    if [ "${pbrBootCode}" != "" ] || [ "$byteFiveTen" == "55" ]; then
                    	echo "PBR: First $pbrBytesToGrab bytes    Code Detected: ${pbrBootCode}" >> "$diskSectorDumpFile"
                    	if [ $gRootPriv -eq 1 ]; then
	                	    dd 2>/dev/null if="/dev/r"${duIdentifier[$v]} bs=$pbrBytesToGrab count=1 | xxd -l$pbrBytesToGrab >> "$diskSectorDumpFile"
	                	else
	                	    echo "** Root privileges required to read further info." >> "$diskSectorDumpFile"
	                	fi
	                	if [ "${pbrBootCode}" == "None" ]; then
	                	    pbrBootCode=""
	                	fi
                    else
	                	echo "PBR: No Stage1 Loader Detected" >> "$diskSectorDumpFile"
                    fi
                    echo >> "$diskSectorDumpFile"
                    BuildBootLoadersTextFile "VA:$partitionActive"
                    BuildBootLoadersTextFile "VD:${duIdentifier[$v]}"
                    BuildBootLoadersTextFile "VT:${duContent[$v]}"
                    BuildBootLoadersTextFile "VN:${duVolumeName[$v]}"
                    BuildBootLoadersTextFile "VS:${duSize[$v]}"
                    BuildBootLoadersTextFile "S1:$pbrBootCode"
                fi
                
                # -------------------------------
                # Check for stage 2 loader files.
                # -------------------------------
                # Are we reading a GPT disk?
                if [ $gpt -eq 1 ]; then
                   # is the slice of type "EFI"?
                    if [ "${duContent[$v]}" == "EFI" ]; then
                        targetFormat=$( fstyp "/dev/${duIdentifier[$v]}" )
                        returnValue=$(GetEspMountPoint "/dev/${duIdentifier[$v]}" "$targetFormat")
                        # Note: duVolumeName for this will currently be blank.
                        local oldVolumeName="${duVolumeName[$v]}"
                        duVolumeName[$v]="$returnValue"
                    fi
                fi
                
                # Check if the current volume is mounted as some will be hidden
                # For example, an unmounted ESP or Lion Recovery HD.
                # If not mounted then there's no need to check for stage2 files.
                mounted=""
                checkMounted=""
                checkMounted=(`mount | grep "/dev/${duIdentifier[$v]}"`)
                if [ ! "$checkMounted" == "" ]; then
                    mounted="${duVolumeName[$v]}"
                    # Check for Windows partitions
                    if [ "${duVolumeName[$v]}" == " " ] && [ "${duContent[$v]}" == "Microsoft Basic Data" ]; then
                        mounted="`mount | grep /dev/${duIdentifier[$v]} | awk {'print $3'}`"
                        mounted="${mounted##*/}"
                    fi
                fi
                
                if [ ! "${mounted}" == "" ] && [ ! "${mounted}" == " " ]; then
                    if [ $gRunDiskutilAndLoaders -eq 1 ]; then
	                    CheckForBootFiles "${mounted}" "${duIdentifier[$v]}"
	                    CheckForEfildrFiles "${mounted}" "${duIdentifier[$v]}"
	                    CheckForUEFIfiles "${mounted}" "${duIdentifier[$v]}"
	                fi
	                if [ $gRunBootloaderConfigFiles -eq 1 ]; then
	                    FindAndCopyUserPlistFiles "${mounted}" "${duIdentifier[$v]}"
	                fi
	                if [ $gRunVolumeXuids -eq 1 ]; then
	                    GrabXUIDs "${duIdentifier[$v]}" "${mounted}"
	                fi
                fi

                # If we mounted an EFI system partition earlier�then we should un-mount it.
                if [[ "${duVolumeName[$v]}" =~ ddTempMp ]]; then
                    UnmountMountedEsp "${duVolumeName[$v]}"
                    duVolumeName[$v]="$oldVolumeName"
                fi
            fi
        done 
        BuildBootLoadersTextFile "================================="
    done
    # ----------------------------------------------
    # Write the Bootloaders file to disk.
    # Also write the UID file to disk.
    # Doing it here allows columns to be aligned.
    # ----------------------------------------------
    if [ $gRunDiskutilAndLoaders -eq 1 ]; then
        printf "${gBootloadersTextBuildFile}" | column -t -s@ >> "${diskUtilLoaderInfoFile}"
    fi
    if [ $gRunVolumeXuids -eq 1 ]; then
        printf "${gXuidBuildFile}" | column -t -s@ >> "${xuidFile}"
    fi
}

# =======================================================================================
# MAIN
# =======================================================================================
#
Initialise "$1" "$2" "$3" "$4" "$5"
if [ $gRunBootloaderConfigFiles -eq 1 ] || [ $gRunDiskutilAndLoaders -eq 1 ] || [ $gRunVolumeXuids -eq 1 ] || [ $gRunDiskPartitionInfo -eq 1 ]; then
    CheckRoot
    DumpDiskUtilAndLoader
fi

# Send notification to the UI
if [ $gRunBootloaderConfigFiles -eq 1 ]; then
    echo "F:diskLoaderConfigs" >> /tmp/dd_completed
fi
if [ $gRunVolumeXuids -eq 1 ]; then
    echo "F:diskVolumeXuid" >> /tmp/dd_completed
fi
if [ $gRunDiskPartitionInfo -eq 1 ]; then
    echo "F:diskPartitionInfo" >> /tmp/dd_completed
fi
