#!/bin/sh

# This script reads through the dumps from the ioregwv tool
# and does what's needed to create a folder/file structure that's
# expected by the IORegistry Web Viewer code.
#
# Based on code from the ProjectOSX topic:
# http://www.projectosx.com/forum/index.php?showtopic=2549&pid=24775&st=0&#entry24775
#
# *************************************************************************************
#
# Blackosx.

# ---------------------------------------------------------------------------------------
Initialise()
{  
    cdir="$( cd -P "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
    if [ "$1" == "" ]; then
        dumpFolderPath="${cdir}"
    else
        dumpFolderPath="$1"
    fi 
    
    # Global Vars - HTML
    
    gTEMPDir="$dumpFolderPath"    
    gIOregDir="$gTEMPDir"/IORegDump
  
    # Files names as set from DarwinDumper
    gDumpFileIOReg="IORegDump"
    gDumpFileIORegDT="IORegDTDump"
    gDumpFileIORegACPI="IORegACPIDump"
    gDumpFileIORegPower="IORegPOWERDump"
    gDumpFileIORegUSB="IORegUSBDump"
    
    gWorkingDataPath="${gIOregDir}/IORegViewer/Resources/dataFiles"
    
    gIORegIoServiceDumpFolder="${gWorkingDataPath}/IOService"
    gIORegDeviceTreeDumpFolder="${gWorkingDataPath}/IODeviceTree"
    gIORegAcpiPlaneDumpFolder="${gWorkingDataPath}/IOACPIPlane"
    gIORegIoPowerPlaneDumpFolder="${gWorkingDataPath}/IOPower"
    gIORegIoUsbPlaneDumpFolder="${gWorkingDataPath}/IOUSB"
    
    gIORegIoServiceDumpFile="${gIORegIoServiceDumpFolder}/$gDumpFileIOReg"
    gIORegDeviceTreeDumpFile="${gIORegDeviceTreeDumpFolder}/$gDumpFileIORegDT"
    gIORegAcpiPlaneDumpFile="${gIORegAcpiPlaneDumpFolder}/$gDumpFileIORegACPI"
    gIORegIoPowerPlaneDumpFile="${gIORegIoPowerPlaneDumpFolder}/$gDumpFileIORegPower"
    gIORegIoUsbPlaneDumpFile="${gIORegIoUsbPlaneDumpFolder}/$gDumpFileIORegUSB"
    
    gLogFile="${dumpFolderPath}"/DarwinDumper_log.txt 
    
    gDataFileSizeWarningThreshold=100 # This value represents KB
    
    mkdir -p "${gIORegIoServiceDumpFolder}"
    mkdir -p "${gIORegDeviceTreeDumpFolder}"
    mkdir -p "${gIORegAcpiPlaneDumpFolder}"
    mkdir -p "${gIORegIoPowerPlaneDumpFolder}"
    mkdir -p "${gIORegIoUsbPlaneDumpFolder}"
    
    # Move Files from DarwinDumper in to it's own folder to process.
    if [ -f "${gIOregDir}/$gDumpFileIOReg" ]; then
        mv "${gIOregDir}/$gDumpFileIOReg" "${gIORegIoServiceDumpFolder}"
    fi
    if [ -f "${gIOregDir}/$gDumpFileIORegDT" ]; then
        mv "${gIOregDir}/$gDumpFileIORegDT" "${gIORegDeviceTreeDumpFolder}"
    fi
    if [ -f "${gIOregDir}/$gDumpFileIORegACPI" ]; then
        mv "${gIOregDir}/$gDumpFileIORegACPI" "${gIORegAcpiPlaneDumpFolder}"
    fi
    if [ -f "${gIOregDir}/$gDumpFileIORegPower" ]; then
        mv "${gIOregDir}/$gDumpFileIORegPower" "${gIORegIoPowerPlaneDumpFolder}"
    fi
    if [ -f "${gIOregDir}/$gDumpFileIORegUSB" ]; then
        mv "${gIOregDir}/$gDumpFileIORegUSB" "${gIORegIoUsbPlaneDumpFolder}"
    fi
}

# ---------------------------------------------------------------------------------------
ReadAndProcessIOregFile()
{
    local fileToRead="$1"
    local fileID="$2"
    
    local nubCount=0
    local indentPosition=-1
    local previousIndentPosition=-1
    local leftTreeBuffer=""
    local tempLine=""
    
    local oIFS="$IFS"
    IFS=$'\n'
    
    # =================
    if [ -f "$fileToRead" ]; then
        
        echo "<ul>" > "${gWorkingDataPath}/${fileID}/${fileID}".html  # Write initial opening to left pane tree file.
        
        # Read each line of the ioreg dump text file and process it. Separate Nubs for left pane tree, and property data for right pane tree(s).
        while read -r lineRead
        do

            # Build Left Tree - Nub Data
            if [ "${lineRead:0:7}" == "indent:" ]; then
            
                # Dump build string for this nub of the left tree to file.
                if [ ! "${leftTreeBuffer}" == "" ]; then
                    echo "${leftTreeBuffer}" >> "${gWorkingDataPath}/${fileID}/${fileID}".html
                    leftTreeBuffer=""
                fi
                
                ((nubCount++))
                
                # Remember the last indent we just used.
                previousIndentPosition=$indentPosition
                
                # select the number which appears after the characters 'indent:'
                indentPosition="${lineRead#*indent:}"
                
                # Add to remove HTML indents as required.
                if [ $indentPosition -gt $previousIndentPosition ]; then  
                    # Add HTML indent.
                    leftTreeBuffer="${leftTreeBuffer}"$(printf "<ul>\n")
                else
                    # reduce HTML indents by the difference in the number read this time to the number read previously
                    for (( c=$previousIndentPosition; c>$indentPosition; c-- ))
                    do
                        leftTreeBuffer="${leftTreeBuffer}"$(printf "</ul>\n")
                    done
                fi  

            fi   

            # Set left tree HTML to have some initial nodes default to open 
            if [ "${lineRead:0:3}" == "<li" ]; then
                if [ $nubCount -eq 1 ]; then
                    # This will be the first node and should be Root. The id of Root set here is used by the viewer to automatically select the first node.
                    tempLine=$( echo "${lineRead/<li/<li id=\"Root\" class=\"jstree-open\"}" )
                    leftTreeBuffer="${leftTreeBuffer}"$(printf "${tempLine}\n")
                elif [ $nubCount -eq 2 ] && [ ! "$fileID" == "IOUSB" ]; then # IOUSB doesn't need this or the next node opened by default.
                    tempLine=$( echo "${lineRead/<li/<li class=\"jstree-open\"}" )
                    leftTreeBuffer="${leftTreeBuffer}"$(printf "${tempLine}\n")
                elif [ $nubCount -eq 3 ] && [ ! "$fileID" == "IOUSB" ] && [ ! "$fileID" == "IOACPIPlane" ]; then # IOACPIPlane CPU0@0 is a leaf and therefore should not be able to be opened.
                    tempLine=$( echo "${lineRead/<li/<li class=\"jstree-open\"}" )
                    leftTreeBuffer="${leftTreeBuffer}"$(printf "${tempLine}\n")
                else
                    leftTreeBuffer="${leftTreeBuffer}"$(printf "${lineRead}\n")
                fi
            fi

            # Build Right Tree - Separate property data in to individual files.
            
            # Look for the beginning of the property data.
            if [ "${lineRead}" == "!!" ]; then 
                
                # add opening square bracket
                echo "[" >> "${gWorkingDataPath}/${fileID}/data${nubCount}.txt"
            fi
            
            # Look for each property data line.
            if [ "${lineRead:0:1}" == "{" ]; then 
                
                # write property data line(s) 
                echo "${lineRead}" >> "${gWorkingDataPath}/${fileID}/data${nubCount}.txt"
            fi
            
            # Look for the end of the property data.
            if [ "${lineRead}" == ";;" ]; then
            
                # Remove the last comma from the file.
                # Ideally, I would like to do this in the ioregwv tool - but how???
                LANC=C sed -ie '$s/.$//' "${gWorkingDataPath}/${fileID}/data${nubCount}.txt"
                
                # delete the backup file created by the sed command above.
                if [ -f "${gWorkingDataPath}/${fileID}/data${nubCount}.txte" ]; then
                    rm "${gWorkingDataPath}/${fileID}/data${nubCount}.txte"
                fi
                
                # add closing square bracket
                echo "]" >> "${gWorkingDataPath}/${fileID}/data${nubCount}.txt"
            fi

        done < "$fileToRead"
        IFS="$oIFS"

        if [ ! "${leftTreeBuffer}" == "" ]; then # Write last line of left tree as it's normally written at start of loop, but loop has now finished.
            echo "${leftTreeBuffer}" >> "${gWorkingDataPath}/${fileID}/${fileID}".html
            leftTreeBuffer=""
        fi    

        echo "</li>" >> "${gWorkingDataPath}/${fileID}/${fileID}".html  # Write final closing
        echo "</ul>" >> "${gWorkingDataPath}/${fileID}/${fileID}".html  # Write final closing
    fi
    
    echo "       IOReg: $fileID Plane: Processed ${nubCount} nodes" >> "${gLogFile}"
    
    # Loading a large file in the web browser can sometimes take a few seconds.
    # To help notify the user of this we can add a flag in the left tree data against
    # each large property data file. I've deemed this flag to be raised once a file
    # hits 100K and this value is held in the global variable gDataFileSizeWarningThreshold.
    # Here we get a directory listing of the right tree data files and flag the large ones.
    
    fileList=( `find "${gWorkingDataPath}/${fileID}" -type f -name "*.txt" -maxdepth 1 -size +${gDataFileSizeWarningThreshold}` )
    #echo "Number of data files larger than ${gDataFileSizeWarningThreshold}K=${#fileList[@]}"
    #echo "Flagging those now."
    for (( f=0; f<${#fileList[@]}; f++ ))
    do
        dataFile="${fileList[$f]##*/}"
        dataFileName="${dataFile%.txt}"
        findString="><a onClick=\"loadFile('${fileID}','${dataFileName}'"
        replaceString=" rel='large'><a onClick=\"loadFile('${fileID}','${dataFileName}'"
        LANC=C sed -ie "s/${findString}/${replaceString}/g" "${gWorkingDataPath}/${fileID}/${fileID}".html 
        
        # Remove backup file created by the sed command above.
        if [ -f "${gWorkingDataPath}/${fileID}/${fileID}".htmle ]; then
            rm "${gWorkingDataPath}/${fileID}/${fileID}".htmle
        fi
    done 
}


#
# =======================================================================================
# MAIN
# =======================================================================================
#


Initialise "$1"

# Array to hold each dump file path/name so we can loop through later?
declare -a gFileID=( "IOService" "IODeviceTree" "IOACPIPlane" "IOPower" "IOUSB" )
declare -a gFilesToProcess=("${gIORegIoServiceDumpFile}" "${gIORegDeviceTreeDumpFile}" "${gIORegAcpiPlaneDumpFile}" "${gIORegIoPowerPlaneDumpFile}" "${gIORegIoUsbPlaneDumpFile}")

for (( n=0; n<${#gFilesToProcess[@]}; n++ ))
do
    ReadAndProcessIOregFile "${gFilesToProcess[$n]}" "${gFileID[$n]}"
done


# Remove original ioreg dump files.
    
if [ -f "${gIORegIoServiceDumpFile}" ]; then
    rm "${gIORegIoServiceDumpFile}"
fi
if [ -f "${gIORegDeviceTreeDumpFile}" ]; then
    rm "${gIORegDeviceTreeDumpFile}"
fi
if [ -f "${gIORegAcpiPlaneDumpFile}" ]; then
    rm "${gIORegAcpiPlaneDumpFile}"
fi
if [ -f "${gIORegIoPowerPlaneDumpFile}" ]; then
    rm "${gIORegIoPowerPlaneDumpFile}"
fi
if [ -f "${gIORegIoUsbPlaneDumpFile}" ]; then
    rm "${gIORegIoUsbPlaneDumpFile}"
fi