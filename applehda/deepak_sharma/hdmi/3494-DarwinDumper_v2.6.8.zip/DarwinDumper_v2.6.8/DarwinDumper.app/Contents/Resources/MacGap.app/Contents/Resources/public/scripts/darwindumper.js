// This file controls the communication between the 
// DarwinDumper shell script and the user interface.  
//
// Built on the macgap project by Alex MacCaw 
// https://github.com/maccman/macgap
//
// I've modified the macgap source to print a debug
// message to stdout when the macgap.app.launch
// command is issued. This message is then directed
// to a temporary file which the shell script looks
// for and acts upon.
//
// In return, the shell script prints any messages
// to file that this script looks for and acts upon. 
//
// Blackosx - Feb 2013 -> March 2013
//
//


// set some initial javascript vars.
var optionsFedBackFromScriptArray="";
var prevSettings="";
var completed=0;
var userRunChoice=0;
var fileToLoad="";

//-------------------------------------------------------------------------------------
// On initial load - set Focus.
$(document).ready(function() {
    SetFocus();
		
	// Hide info div by id on launch.
	// The help and info pages get loaded in to this.
    $( "#infoWindow" ).hide();
    
    // Read version number to populate the interface
    getVersion();
    
    // Start time to check for update file, 5 seconds after launch
    // This will give time for the 'init' script to check.
    timerCheckUpdate = setTimeout(checkForUpdate, 5000);
 
    // Restore previous state.
    readLastSettings();
    
    // Enable/Disable 'collapsetables' checkbox depending
    // on the checked status of the enablehtml checkbox.
    toggleCheckbox(enablehtml);
    
    // Set the colour of the archive menu depending on the
    // selected value.
    setColour();
});

//-------------------------------------------------------------------------------------
function SetFocus() {
    macgap.app.activate();     
}

//-------------------------------------------------------------------------------------
// Called when the process is to close.
function terminate() {
    clearTimeout(timerFeedBack);
    macgap.app.launch("death"); // write string to file which should terminate shell script. 
    macgap.app.terminate();    
}

//-------------------------------------------------------------------------------------
$(function()
{
    // Respond to the 'Deselect All' button press.
    $("#DeselectAll").click(function() {
        // UnCheck all dump option checkboxes.
        $("#MiddleOptions .dump_option").prop('checked', false);
    });
    
    // Respond to the 'Select All' button press.
    $("#SelectAll").click(function() {
        // Enable all dump option checkboxes.
        $("#MiddleOptions .dump_option").prop('checked', true);
    });
    
    // On clicking the 'enablehtml' checkbox.
    $("#enablehtml").click(function() {
        toggleCheckbox(enablehtml);
    });
    
    // On changing the 'archive' dropdown menu.
    $("#archive").change(function() {
        setColour();
    });
});

//-------------------------------------------------------------------------------------
// Change colour of the archive drop down menu text
// depending on the selected value.
// Note: these colours match the values used in .css
function setColour()
{
    var temp=$("#archive").val(); 
    if ( temp=="ArchiveNone" ) {
        $("#archive").css("color","#666");
    } else {
        $("#archive").css("color","#FFF"); // 68CF44
    }
}  
    
//-------------------------------------------------------------------------------------
// Enable/Disable 'collapsetables' checkbox depending
// on the checked status of the enablehtml checkbox.
function toggleCheckbox(checkboxID)
{
    if ($(checkboxID).prop('checked')) {
        $("#collapsetables").prop('disabled', false);
    } else {
        $("#collapsetables").prop('disabled', true);
        // Also uncheck it as I can't work out how to change
        // the colour to the unchecked grey as it's set in css.
        $("#collapsetables").prop('checked', false);
    }
}

//-------------------------------------------------------------------------------------
// Check for file /tmp/dd_user_last_options and read
// contents to set the users' previous settings.
function readLastSettings()
{
    xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET","/tmp/dd_user_last_options",false);
    xmlhttp.send(null);
    fileContent = xmlhttp.responseText;
    prevSettings = fileContent.split('\n');
    
    // if array is not blank
    if (prevSettings != "") {

        // step through each element
        for (var i = 0; i < prevSettings.length; i++) {

            if (prevSettings[i] != "ArchiveZip" && prevSettings[i] != "ArchiveLzma" && prevSettings[i] != "ArchiveNone") {
                // Set each checkbox
                $("#"+prevSettings[i]).prop('checked', true);
            } else {
                // Set the archive drop down menu.
                $('[name=archiveOptions]').val(prevSettings[i]);
            }
        }
    }
}

//-------------------------------------------------------------------------------------
// The index.html form uses more than one button. 
// Work out which one was pressed and respond accordingly.
function formButtonPressed(f,whichButton)
{
    if(whichButton=="run")
    {
        // remember choice for later
        userRunChoice=0;
        processSelections();
    }
    else if(whichButton=="runAsRoot")
    {
        // remember choice for later
        userRunChoice=1;
        processSelections();
    }
    else
    { // the Quit button was pressed.
        macgap.app.launch("user_quit"); // write string to file to say user pressed quit. 
        terminate();
    }
}

//-------------------------------------------------------------------------------------
// React to the form submission.
// Find each item that was selected and build
// a string with each title. Then send the final
// string back to the Terminal.
function processSelections()
{ 
  var string="";
  var tmp="";
  
  // begin string with user choice of root privileges.
  string=(string+"Root="+userRunChoice);
  
  // add to string user choice of archive
  string=(string+","+$("#archive").val())
  
  for(i=0; i<document.User_Options.elements.length; i++)
  {
    tmp=document.User_Options.elements[i];
    if(tmp.checked){
        // write a comma to separate the contents.
        string=(string+",")
        
        // build output string.
        string=(string+tmp.id);

        // Not used - but kept for reference.
        //macgap.growl.notify({title: 'MacGap', content: "Checkbox:"+document.User_Options.elements[i].id});
        
        // update status bars to show process is waiting to process.
        // skip any non dump options
        if (tmp.id != "collapsetables" && tmp.id != "Public" && tmp.id != "ArchiveNone")
            $("#status_"+tmp.id).attr('class', 'statusBarWaiting');
    }
  }
  if($("#archive").val()=="ArchiveZip" || $("#archive").val()=="ArchiveLzma")
      $("#status_archive").attr('class', 'statusBarWaiting');

  // Return string back to stdout.
  macgap.app.launch(string); 
}

//-------------------------------------------------------------------------------------
// Initiate timer to run every second.
// for monitoring script feedback.
timerFeedBack = setTimeout(checkFeedback, 1000);
  
// Check for file /tmp/dd_completed and read
// contents to indicate completed processes.
// If the string "Done" is read then we can terminate.
function checkFeedback()
{
    xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET","/tmp/dd_completed",false);
    xmlhttp.send(null);
    fileContent = xmlhttp.responseText;
    optionsFedBackFromScriptArray = fileContent.split('\n');
    
    // if array is not blank
    if (optionsFedBackFromScriptArray != "") {

        // step through each element
        for (var i = 0; i < optionsFedBackFromScriptArray.length; i++) {
            
            // Check for progress bar updates.
            if (optionsFedBackFromScriptArray[i] != "done") {
            
               if (optionsFedBackFromScriptArray[i].substring(0, 2) == "S:")
                   $("#status_"+optionsFedBackFromScriptArray[i].substring(2)).attr('class', 'statusBarRunning');
                   
               if (optionsFedBackFromScriptArray[i].substring(0, 2) == "F:")
                   $("#status_"+optionsFedBackFromScriptArray[i].substring(2)).attr('class', 'statusBarComplete');
            }

            // break if we read "Done"
            if (optionsFedBackFromScriptArray[i] == "Done") {
                completed=1;
                terminate();
            }
        }
        // recursively call function providing we haven't completed.
        if(completed==0)
            timerFeedBack = setTimeout(checkFeedback, 1000);   
    }
    // recursively call function providing we haven't completed.
    if(completed==0)
        timerFeedBack = setTimeout(checkFeedback, 1000);   
}

//-------------------------------------------------------------------------------------
// Read DarwinDumper version to print in the window.
function getVersion()
{
    xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET","/tmp/dd_version",false);
    xmlhttp.send(null);
    fileContent = xmlhttp.responseText;
    
    if ( fileContent != "" )
	    $("#leftSideVersionBox").append("v"+fileContent);
}

//-------------------------------------------------------------------------------------
// Read DarwinDumper update to print in the window.
function checkForUpdate()
{
    xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET","/tmp/dd_update",false);
    xmlhttp.send(null);
    fileContent = xmlhttp.responseText;

    if ( fileContent != "" )
	    $("#leftSideUpdateBox").append('<a href="https://bitbucket.org/blackosx/darwindumper/downloads/DarwinDumper_v'+fileContent+'.zip" target="_blank">v'+fileContent+' available</a>');
}

//-------------------------------------------------------------------------------------
$(function()
{
    // Respond to the main window info buttons when clicked.
    $(".button_info").click(function() {
        // load respective page in to jquery window.
        loadInfoPageIntoDiv(this.id);
    });
    
    // Respond to the credits, info and symlink menu buttons when clicked.
    $(".button_showpage").click(function() {
        // load respective page in to jquery window.
        loadInfoPageIntoDiv(this.id);
        
        if(this.id=="info_symlink"){
            // Run a timer to check for feedback from init script.
            timerSymLink = setTimeout(getSymlinkStatus, 250);
        }
    });

    // Hide the div by id on click of button.
    $( "#infoWindowCloseButton" ).click(function() {
        $( "#infoWindow" ).hide( "slide", { direction: "up" }, 200);
        return false;
    });
});

//-------------------------------------------------------------------------------------
function loadInfoPageIntoDiv(idToLoad)
{
    // load respective page in to jquery window.
    fileToLoad=("info_pages/"+idToLoad+'.htm');
    $('#infoFileContents').load(fileToLoad,function(responseTxt,statusTxt,xhr){
        if(statusTxt=="success")
            $( "#infoWindow" ).show( "slide", { direction: "up" }, 200);
        if(statusTxt=="error")
            alert("Error: "+xhr.status+": "+xhr.statusText);
    });
}

//-------------------------------------------------------------------------------------
function updateSymlinkStatus(statusMessage,buttonText)
{
    // Set text of table cell contents to feedback status
    $("#table_symlink_status td").eq(1).html(statusMessage);
    // Set button text
    $("#table_symlink_status #symlink_page_button").val(buttonText);
    // Stop the timer
    clearTimeout(timerSymLink);
    SetFocus();
}

//-------------------------------------------------------------------------------------
// Read DarwinDumper symlink status from /tmp/dd_symlink
// Then set the table cell and button text accordingly.
// This function is repeated using a timer, until stopped.
function getSymlinkStatus()
{
    xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET","/tmp/dd_symlink",false);
    xmlhttp.send(null);
    fileContent = xmlhttp.responseText;
    
    // Remove new line at the end of the string.
    fileContentNoNewline = fileContent.split('\n');

    // Parse string
    if ( fileContentNoNewline[0] == "Create") {
	    updateSymlinkStatus("Not Installed","Create Symlink")
	} else if ( fileContentNoNewline[0] == "Update") {
	    updateSymlinkStatus("Exists but needs updating","Update Symlink")
	} else if ( fileContentNoNewline[0] == "Okay") {
	    updateSymlinkStatus("Correctly Installed","Delete Symlink")
	}
	else
	{
	    $("#table_symlink_status td").eq(1).html("Unable to determine.");
	    // call this again 
        timerSymLink = setTimeout(getSymlinkStatus, 1000);
	}
}

//-------------------------------------------------------------------------------------
function symlinkPageButtonPressed(text)
{
    // Send message back to 'init' script.
    macgap.app.launch("Symlink:"+text);
    // init script should now respond. Initiate timer to read response.
	timerSymLink = setTimeout(getSymlinkStatus, 1000);
}