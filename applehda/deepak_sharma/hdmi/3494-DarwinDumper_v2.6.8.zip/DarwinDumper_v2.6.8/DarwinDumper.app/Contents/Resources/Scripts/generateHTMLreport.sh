#!/bin/sh

# This script:
# 1- creates and initialises an html report. Two files are written to and
# then combined at the end. The first file contains the header and the css
# which is appended to as the script runs. The second file is built with the
# Javascript and the html. At the end both files are merged in to one.
#
# 2- scans through a pre-defined set of folders and if locating a set file
# will read the file and place the contents in to the html document. Any
# translations that might be required are also done, for example substituting
# spaces for an html non-breaking space to maintain column spacing.
#
# 3- Calculate table column widths and adjusts accordingly depending on the
# width set by the gMasterFrameWidth global variable. At this point in time,
# the overview section has not been set up to resize. This is to be done.
#
# *************************************************************************************
# The script requires 4 arguments passed to it when called.
# 1 - Path       : Directory of DarwinDumper dumps to read.
# 2 - App Name   : This is printed in the title header of the report
#                  Will almost certainly read 'DarwinDumper'.
# 3 - Version    : This is printed in the title header of the report
#                  This will be the current version of 'DarwinDumper'.
# 4 - TableState : A string of either 'none' or 'block'.
# *************************************************************************************
#
# Blackosx.
# Thanks to STLVNUB for the idea of using embedded images.

# ---------------------------------------------------------------------------------------
Initialise()
{   
    local passedDirToRead="$1"
    local passedAppName="$2"
    local passedVersion="$3"
    local passedTableState="$4"
    local passedCodecID="$5"
    local passedPrivacyState="$6" 
    
    # Global Vars - HTML
    gMasterFrameWidth="1000px" # Change this line to alter the width of the html output.
    gTableState="$passedTableState" # default acpi html table state. Use none for collapsed; block for visible
    gCodecID="$passedCodecID"
    gPrivateState="$passedPrivacyState"
    declare -i gTableBoxWidth
    declare -i gTableTextBoxWidth
    gColOne=0; gColTwo=0; gColThree=0; gColFour=0; gColFive=0; gColSix=0; gColSeven=0; gColEight=0
    
    # Base64 strings - Images converted at http://webcodertools.com/imagetobase64converter
    privateStamp="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADQAAAAWCAMAAAC4wk/kAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA2ZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDpBOEFBNEY2RjQxMjA2ODExOTJCMERBMDNGNkRBNjJGMSIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDowQURFQkQ0RUY1MTAxMUUxQTBEQUE4QjVDMjMzMUM1MCIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDowQURFQkQ0REY1MTAxMUUxQTBEQUE4QjVDMjMzMUM1MCIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ1M1IE1hY2ludG9zaCI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOkE4QUE0RjZGNDEyMDY4MTE5MkIwREEwM0Y2REE2MkYxIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOkE4QUE0RjZGNDEyMDY4MTE5MkIwREEwM0Y2REE2MkYxIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+uy27RQAAAwBQTFRF9lNP+YuI/728/+bn90E9+JiX+o2M9qek+oWC9MvK/+Xl/OHh/LCw+X59+FBN+kM/+727/NnZ+8fG/I6N9KWj98/O742L9UQ/+Kup8mZk/6qo9nRx9FBL9VZT84J/9UhD+d3d8JiV/VtW+np573l49y4m98zM//Pz9IB98oGB9oiF9nl5+0VC9DQs9nx6+6mp/BkE9h8U/vb2//Ly/Z6b90xG9goA9V9e+GBd/pyc+7m5+VpW+Hh39FpX+VNQ+FVT/D46+3Bt+TMt+01H8mxp+4OB82hn/9TT+Jyb//7+/c3M+MHC91hV9Jua9zgz8peU/K+u/cjH+aGh+nNx+sHA+pKS/+3t+GFg/+rq/a2s8oaE9oOB+1dS+jw1/8rI9np3/8zL/MzM93Vz+8rK/sbG+W1r+b+/92pm+re2/bS0+IB++bKw9K2s/Kim9ycd96in96Cg8qKg85+d//j49YyL8oWC/9HQ9nZz+szL/MrJ+MrK+8TD8nJv+WRg9ra2+amo9l5Z9qmn+6Wj+KWj+aSj9lJP9pOR8nV08mRg//r698fG//z8+3Z0//Dw+ayr+LW19Gll/87O9ZGR/ZuY/LW29Kan76ur9rm39cC++r+9/aOj85WT9IuL8re29m9u81tX9ltY98TF83Bs9aKi96Cf+JuY98nK/+3r/t7e/+Hg/9XU93Bt+m9t+NXU/TEo+8nJ/MjF7Wpn97u5/8/N+IyM+qqp/6up8JST8pOQ/7Sy+8XD//n4/vn5/NbW/ezs77269bi58sC/9r68/vLy/L68+pWV+qak/M7O+mZk//Dv+Wln+2Zj+5GP9TYu+9XU/8HB/dXU7lxY9cTD+pSS/ujp+MTE/qal9JWU9YqJ/5OS94qJ94uI+ba0/+Xj+AAA95WS95WU/l9c9be2/8zK/O7u/ry79bSz9VdR/8vL+bm4+2pn821q87Gx9a6s77W0966t+a2t9G5r8amp9Kip+cPC9Kmp+7Ow8lxa9KCf9aKh+ISE921o88bF98G9+5+e////027FcQAAAQB0Uk5T////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////AFP3ByUAAALzSURBVHjajJN3PJVRGMev3HuzL5fixqVwzUsRJffahIxkVVYys4uQkJKyykqb9tLSoL0pLWkoDe2d9t6/zos/6iM+zh/nOc/zPt/n/N5zzkND74axL5qrING0n3JoPSQWGgPNxB4eCNTWzFph1ZJKX5kc3B3kmFLaUFA0OOvEsS3+ehWJLxcd1dNZrqzzSqkWftKF7VBh/iFtbVSVDpSrX+YCJMya8U7FVPf4Gq5q4r6QGs/Wf+pp1Qxth6RGMELOLzG0eO9Gaxwp/npnbuUnN4VuRYuJUpC/iowlffjaltHALnY3maMAWflv/pnmeDBzM4ESOM+7P4vqLCCaZb3dLAFWtgzlrenQ0nQkkJROl7JKG3dTNnIwVg0zR5wD36gImPO94+tCOQI1GZIV++0vEp/NV2vLlQfD4KHdExL8CrgbCcjCk0MmKxbT63QEcL0PgYIyQrHeQq9S7QUEVqHwMUpzsYC6KXDqCjxpS1m1QIEmgWSGaGhITwNC9hCo+QMgiATiGoPuOwAmvGpE43a8IVznYZ61UiDBd6h9JGIDOuT5Dei83HMyGCPkwIan7D7EB3AFAuJhnQ6+rapmvBQO2JYDd+nm4+WZRIAHBRUDUbxAu7zVOMnNCefFAAaTgHA6C5/jPQBLHglMBmK/CM34JN3FnEDaqcVgCxbUkw19hKRgKmBUA4y/44UJT0nQOw/o+9fZKogQaL7NTTAD230NFvVOgBJPYu8B0/93dXPVqZ2YTvhNn0j53tm9aJJ1mQRKuiGGXo9+V510GQTKvybdUxqRwM5hijndcjUrKxvbpq+4l+on54aFXTJD2ShofaMR3lbCzR3U315FUTGaaeMQl22StulZR+eG6U/s6JQTEd79oBWbwf0x01WHw1GlCc4aMjZsCw0bleIo6jtu/kHnzpoEkjObs/iyX56q/aXk5Ck/pyhUCE3iBsg+DpaskhD11YZzV8nUi/DWg/hUkZjyqIsXJB8dqas7Y5yU79zTf/4RYADJyTiAyjAxYAAAAABJRU5ErkJggg=="
    gLogoDD="data:image/gif;base64,R0lGODlhgACAALMPAPT09FKMXx5QKFJWUpqfnA83GUF3S5zEn3uwiy1lOGqYbcPExHl9etfX17Gysv///yH/C1hNUCBEYXRhWE1QPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS4zLWMwMTEgNjYuMTQ1NjYxLCAyMDEyLzAyLzA2LTE0OjU2OjI3ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdFJlZj0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlUmVmIyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ1M2IChNYWNpbnRvc2gpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjdGMTQ2OEUzRUJDRTExRTFCN0E3RTI5QzQ5NTBDMjA2IiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjdGMTQ2OEU0RUJDRTExRTFCN0E3RTI5QzQ5NTBDMjA2Ij4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6N0YxNDY4RTFFQkNFMTFFMUI3QTdFMjlDNDk1MEMyMDYiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6N0YxNDY4RTJFQkNFMTFFMUI3QTdFMjlDNDk1MEMyMDYiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz4B//79/Pv6+fj39vX08/Lx8O/u7ezr6uno5+bl5OPi4eDf3t3c29rZ2NfW1dTT0tHQz87NzMvKycjHxsXEw8LBwL++vby7urm4t7a1tLOysbCvrq2sq6qpqKempaSjoqGgn56dnJuamZiXlpWUk5KRkI+OjYyLiomIh4aFhIOCgYB/fn18e3p5eHd2dXRzcnFwb25tbGtqaWhnZmVkY2JhYF9eXVxbWllYV1ZVVFNSUVBPTk1MS0pJSEdGRURDQkFAPz49PDs6OTg3NjU0MzIxMC8uLSwrKikoJyYlJCMiISAfHh0cGxoZGBcWFRQTEhEQDw4NDAsKCQgHBgUEAwIBAAAh+QQBAAAPACwAAAAAgACAAAAE//DJSau9OOvNu/9gKI5kaZ5oqq5s675wLM90bd8boO987//AoHBI7OEkvEdxyWw6k0kar+EgMAwDrDbL3Xq72etgTC6bz+i0mswgLIwugHLnYCQMAcVhz+/7/3wLB4IICoWGComKiYeNjI+IkYWTiJOHAQkFAgxvOi1ydAkCAQiDgKeofQirrK2rB66xsrO0paUHCqIDnaAooAANAwWksAoBx8h4yMvMzc7LBtHSz9TV1YywBpsNnnIlvw4CCavG1ubnyKUNDYTo13nwxuXLhqsCu90kvwTDsMfl8+IJlKcoz6KDieAhWFelzQJ2BBFKrCQJEkVKeg4EENBJiYh9Bf9KWVx0aKLJkwoeEhBWoOUmB1QMInRUUpGjkSSxKRDgYMcIHfwMKXNHtJmBhwzCHBPTpgGCotQCVjugjZsnEDoWDHsKtWu6BlaOSRvKAKbUqP8MCownb2AejQmseuugI9g4r17xxBwbYGw0TguG4kVXadNVD0AFFDLXtvEimRIFEmjA4NzkpxNrar5IqXOlY4UKdKQLLAEplAUTPo7oti08Bw6cVWbGicDA1LhVH4RMEN4yBAkYcEMMIOjgvAsI+F0+1gHV41ATcTysAViWecqyi90OPdoCBdH6isdDXiwBB+Whu0NgeG6GrALOqjdnoIrpaeX92k8235oBBFgMl0P/cYrpdpJMt6GWiDIJVFEeeOEZYAx5DgAoHjT9PbPTaO8BYAdXjaUVYm/yUVMIeSlFk8AC6I3nVHgLjJcefxdqd2F0BRBA3QXW/ccWW6zhRgp94i2IR3KmrYMJJgoAEFh96M3IXYbM7DSZexbUNUBravmm2o8B5ccMHkZyEkBPVCBAQErcJLLAFfjduJ1gc05ZzVC5CIdlBXWZNiKYrTEypJzjFWqkAyyywyJsCzyEqHJUOvMnKQboWZ2TW7oWIpeODSnmQeRJGMAVbsBGwHmnMnrFbCIq6CpqlQqIQVbXrfUnQGqtRmMrE/Y1FgNlVWFFqnXASac1mt6mrGNCDSAr/4/AjIKrb9QGCuhQjoSqYhtjODAAsN/yM4BtoiY4EYK68RbRbuBZ2uECmXopolt9ffkYV3hg5Kuv9Vkx7krdJlWWbVcUNe2myCSrUIB7UgBMA9KmJW8z5UjIbFsSknMiv8GB5e+p5wl8XoyC3ZprpxefPFCsDU9QV8QUzxseePUag1mrRo21IovDCjxuGyNDemyGuKrG8KXwSjlmWsrQbDGgE/IlTQIKKFpFHS2Ne3Wjbyb86tcmAejurJiKKl/FvpG5L8rUamtAg1bDNoA4LyHaKFhDy1s0tSTSWzQWO/K5jgBuS91r2nk8CDW/UwfAjqJvzi3APW48tE4D00R6zf/RHUKstFjRGAnPzL7aG6JfDT7sKAOTz/2t5esUV26yJqMc5LqUjg0tvGihCHrUo6sNnr0cO345OyuJkwUWk13uZJx5zxdeAs62jASm9zGXuNqkzzwN7cEnoGPs7LAuTjRhWBU7q2uN6j6ytiaIR8fWKzF4uVWSKU3UonYv/LzbSdTlVpKAAlbmLzDhhqLuoDPyAMtYy2Gc1CIUOppR71lZso5pGMgXmiWDf8CDkP40Nb9SuYEKDNDE5LYQnDckByZ2GNWawnKm5NApPP+oUNEeY7H56S6DCyDcM/S3vezg0Hvec00AzoMosDSqCmoCmRRHBht2CEuBkDPVFJ2DKk7/AMM103hKDzFRPaRlQUb7+4f+QsevCflpbRLSXxe3mCpUXQ1VIGuDsGBTBZ7VgYmmCmRZUNi03lRwfgMInMPut6+heTBzkAzd9+IoFj6+6VSSE0UBN9k6kDlxJUCzwgOBdQcOYiI8blDO9/jXPzJikE898mCh6GHEWoowjkmMRvNEWQdxbPKXnDwVsJrXl6S87S/fOubbRqWiUd2ygoxbECZ+CMsguq1egqHkKRl0REkysF1HseKwNOlLYNLtZ2VRCd0KyIXl/XJ+y5Sgn1jZq3u80mHYa+T+8MedY4rlDqDD5R1y0Txx2qGcBUTd5Ab2kIdoY5MqYmApTWOHZR5Q/6JqGUs9qYnPpBVKmbKcpT/5dYxvquhIx6vCGB6aUGNUxg66qJzlwqHJLVGvLwkFaCmTocynTS0RGyzju85XSm5KSUKm8VVSGfhP8hQQdgyBaUQBmgxyAmYd6tzkRjb4zlwU0H1v22lCNLqkbdSvLgWI6EhNCo1clBSHCW1qXxJ4ueQM4A5nbOkyfjkuRQ3Ql8YqKlUj1E8IzUOErjwr9o6Z04DKCalyxWmo7gC7hgYGr/uiahHv2sK6OkqTU32nzjjIHNRthKMuc5IQ3Za9geJQRjhdqk6rxrXaAqyZ0zupTtkpU7/GiLQfDZVIkcU5snk0czvFxFfTI9xmKrdBT/+srQ1NWSkGTVSwd2iidClD2tJ697unvWdq4dVancZzp8xt5HLrsyhLRo561FXvdelGOenejQDAhOhEGavMok7tmPZUbBCXd0rZ3ieuhG1uAat2Rz5aQRTnk9qFrstJTaZzu5flb07VKtipMja8ioVYUQs8v68+t5Hi0Wkq7Qgb870NsM2dcFjzq8nzQM5yyk1wWAkr2aRWdSNCNa47pxdXiJ6YsFTLbnJA1uIXr/CXAdiSJDP7Tn5JblwN9St+5SVWgoy4N3cwa3XWUYAkI7jIRV4mklMirKBlMpNTha1wqzy1yS1Uu4+LTcKeO7seh8g0Ab5UMFarVSMber2h4xn/sVinjcmVMsIIhl6JAToWOyd0kFyDSFWPiasdewnAqEUCmQtN6t2aWkUrrmMmzmfnOM+YcUsiMjMK6GgCy7SJ8pjx04wxUbYAOMjQGvRDn8vVr0JU148i1txorTxae/jVpszeNiNK31++JLpgAeZyjj1abYR6DloBJrHHfewCatENMBVFo4mqbl2zVIJ8qTCtIWxnAZS5VIxiD433re1Av2vZmpRoTksdDS22mHD3UDeEr/tsbpfWnPSut53TySgCIJTf+fW2eK/XgDKTc+DG1q84tIikhGvjxS8WuEQj7MsGxnvevpR4vQfg4AXoG+M0TqwZy7lOD79TfC/spbP1/ztRwoXV6KB9Nep0FnNHR1ziK7b5xWdMYzyI+d8p13bAsx518yWccFnotbOVi3RIJ7RxpJ332aVR71JGfUl7pbHRtQFsIBZgS+t0dNkfHYAXvgnhjtawbkWO9LNrMsq6He3hy0NvieKRZHE3p9XprkiXreOu1FY71b3TxxQ2PeEcxOjWIRyNlrvb5SryZUDpjT5dXq1F1tX8jgvwbbSGnaV5TzlPkvMmZiO83aEv/dEfbWyzbzDxy9TqUOjrFyynciiS17W/hTyKnOY9wsOgAov0HnjS95SBhFv40VO/crwif79M18WM72FJpcJ8qoSj/cbBHXgAf/zJdoOXpcVPt/+ThtbJRUdt5LdN/kVh5CRzkzMMLJIceQd8UHZBArZs4Ud89VYAtMVdbSd+8yZ4Cgdaowd85zNkEuVkeneAUMc1C+eAh5cn80crzGd9eTcZ20dfRBV468ROBUh1mGB2hUdat2d9C4eACXgUD7ET3qd29QKBY9ZxYdeBJCgOXON5nweA61aA5dRomvBiHneDTvdOIkiDT2dnOeIoPfdx2yF/ITY3BvFknDQ5jsMid7V/rcZ6/GcAUlRABMAKb1MPazIKeWgbwyAsudBf69ZzjDWEd+OB65RiBnB3LUhmQrSDv4eFlcMPEUeCzFZ0d/UtDzQGo+SJnRgcosQ6o5QUt3f/iK3GdHbWRIxWgqESf7VnHZ/XdI02CG+iCb7newB4DK4zBvdQBr/oi2dwd2VAjGRgcqgYYamXgCeEXyUIOuRUd9V0d09XiE9FBau2hU43hyvEOmvwjeBIBoTofXWWgJxABdU2Pf13ddTHduLQF/VGhOGQgZZWeuF3TmhgiqbIBmewj/tYjPClW8pIgmkFE/N4PrFlZwGAhjtHJppkDGK4C2CRgPbGfX5CeglojKDYifooMhsJLv9YBgnVhA8lhHdnkKloj9gnjR2lCcvTfW2nThWpCdqokhAWjjjpiWhAkwJXiBRpb9mFjnP3cQ/FkP8mhBXIEXizahU5iyUoDDkZ/5Vm4HTrF4Zlxn4TWY5PFn8sOV4SCHMfBzfeko1i+GiWpjwaGZIg6TNpEJJkcHdZyFlPR5PicHfqtIxbWZe1R2YPF1ZzRQUsQZMq9I6SCGEaOS6gGC6gKErfEi6j6C9moEJh5ntCeI6D2Hhg6Yhp2IQdtlzCcYv2NpitlguSeZiNWQbgEi7A4i0eWSzcEplZGHBIqQmAcXRyaGlGOSuj9l+69ZJIEZp0eZYSB5VlAJljMIo+AzDHyYlt4JZ2JpdhmI195QAFNJiUWZddyXFzw1L3Z5iTsRIuIZriWWtSWZ5j4BJqJ3PZWB+UIXHXSTd72XEUOZ7hyRG3WJ8qFJzhGf+OblmeuCib7lmRpSKGNFiBdNeCsghQBCpz8geeSGmY9taPzMktAgMuozihwzSMuBiHEXeVLdEUjViRYRh4ubk7dxceTTmiu8c6ksl99NUSh+mPa+mPnPiRqRmZMcds1llf/ICLPpmAm6SZZiSaeieYMGqXWNOUEuehpoma5pkG6BmEBCoKwSKi8KiemlSiGSSfM1mXSwqctQFw+kWQT2qe/3mAoplOwgCUTiaaolBmQnqUjZefoQmc9lYb3JlfLkmcZQqOcEmNjjaYtOkGIaqfZWmYmRCL+peUdNmoMCoAqMISXRqkxHikf8oSUAmXmZqpl2qpcGmRYkh7brCmjfr/k9UJpHFqXICao3l3pIE6MJJKj50amJ5aq7YKo5j6p5lIl3pEqvjpaFeKqrHYcZ1JYaYamgPDohukQrnqqc0amM/aqVmDqy1KN4OKHoI5k3Q5P42aCdkJbpLzoLkInHd3Ho2oIi4RmsLAZFAZSilEe3WANeUqTFCZR7Qah3VpgVUAlL+aovTGk1paTaRqpxkpcq5qb1bApLUKEw/BEgxLGS0hg2DxoXmWNY+jFY/KoMDyqG9qp9n6q6lqoh9rdF2Kro4ano9aq2/ADe86Ph7yocBQHDDLDQ6QNQ/Tca76r0aKnl1aqo6aqI84aNpqrcBZnRmbriJKrke6sgDgsDHb/7Ix26MMELM1e3cxi7EwOqe2+qLz2bMz+a1oZaRKu7Pp6hK7mAkLyzUsARj3yQkwlDVc06O78ESWeg8EurUQ6rMzCbRpGJxIyaAtgQWpOLYRy0dry3try0fvGizySnN8dLC4WauhKVGO6rUBi0/BcJU/ebdNCbkVeKsSyxISu7iP867OohJw+0S0aq3ZmLLpSh7ZilAzOayed6u2i7aharvs+qFXk7jngalXY7p3VJ9LSrZF+6Z0+U7AeSWC1qN/+7eCGpu22pzgWa7ckjU9g73NCaPZm60L56piC75R2oYtARMhVrPPm751uqy1OjDVOzDewrvClDXCIrwgQ7wUaf+Y4ouygmlOEcoh0IIpRKq+n1uk09u78tu4wUu/IYO9qHKiSpqF0fCx/GunwESTelI/cwCxBKy+/HukgJS4csO7LUa/pmLCVZCFQCmG0mC7hDuf5WsVA8IOa9rBNlynkAovIHyfH8rDtPd36sqA+cmTTFmntku2+/kQlZdaTiKFm/vEXwrFJ8sJlroLVazDjwqaoQmaR4q7aLu1rmu75qvBHIfFR3zGZ0xzV+ypZly+70qTSXqw44vGdZvEMswBO5ActwpoGdt2DXh95sgPGanGrhoOllq9NJmwQ2ytadUXHzzAffy/d0waTWyr3IqLspue92dpnjc3tCmeLAqm2kr/ewOLw2z6xTn7Sxl7BxHLC1gBDPJqwY2IyY13fZs8c0Raw8/Zon8KnOHauZiMxFkbcF2Mtie0xGQDDD6Msn4spd3pokq6oNK8QuSakVGctYTLs7R2tGMoFx9RF7E8rkGoyX9coDdMPXUartVawKVkq9ZmpFjmzT9RF3Y1zCp6w/i8pGE2xB1asBMsuZ+LvUqMzHhMz/I6vjiX0Aq9b61TxCJqbcyGhUNbq1ojF2Rc0AadFHS80Rzd0R5dxelk0SowBQxRB3160sV4nm+pBpW6qXyqNXcTBSxA0hfrYIH0ejjNRHa00w3G0z7NRzd90yyG00DtXo8DBy/gA8ez1EzdLtRO/dRQHdVS3dQxi9Qy8ARYndVaPQRHcD1b/dVgHQRdPdZkXdZmfdZondZkHQEAOw=="
    gLogoML="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA2hpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo4NUEzQThDMDBDMjA2ODExODA4Mzg2QjgyQkZCREI0NSIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDo0NTNCNUIxQUVCMTAxMUUxQjRCREVDMkE1MTc4QTBBNiIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDo0NTNCNUIxOUVCMTAxMUUxQjRCREVDMkE1MTc4QTBBNiIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ1M2IChNYWNpbnRvc2gpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6ODhBM0E4QzAwQzIwNjgxMTgwODM4NkI4MkJGQkRCNDUiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6ODVBM0E4QzAwQzIwNjgxMTgwODM4NkI4MkJGQkRCNDUiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz7bEKZ9AAAKsUlEQVR42qRXeYyU9Rl+5r6Pb45ldnZ2d/aS3ZVdROi6aPEK2FaqQVCjqKmNjYmk2jRUm6apQIxNk/oXKUnrgUWbHoipGvkHXRCEXVdQzgUWFpZlr9ndue/rm+nz+zhCrLUYJ3kz8813vO/v/T3P8z6fCtf/UTHMDD8jePnbdvn/DGOacZ4xxUgzqtf70Ou5pkOtVj/c0tJiXrFihX/p0qXBpqamOovFYhXn8/l8Znx8fLq/v3+0r69v6tSpU+lyufxvnjvGqHyXAhZotdqH1qxZU/fcc8/d7fP5morFIlQqFTQaDarVqvJbBBMqxzqdDrFYbPLVV1/d/fbbb19gcR/wOV/8r46ovqGwexcvXrz8T1u2PCBJUmNFlsEVw2a3Q88kKpUGaq2aj730XJnnSywulUohnU4rBWaz2ZkXXnhhB7sSrlQqm76uCM3XJeeqNz6zbt3tr7zyx6d1Or3T4XSittYHK5NrtLrLq66iwlXLpQKqlSoT6qDV6WGxWiDxetGNSrVqfWDVqh6n5Ijt33+gk0UMiFq/qQNK8hc3bOhedd+9qwY/2YmWtnb03vkjqHVGFLJpxEJjmBo9jbnJMUSnLqCYicNqtcPhb0Zz960IzF8InV4PvUGP8PQkPu37EIHmdhw5Pvwxt7GfW7jpWlx8tYCVzz777NqfPfnY2onhLyFJVhw/dhRaowOt87twYnAPRr/ci5mJUSRSWeh59zyXg6s2IZ/JoGpxYvHyB9F+ywoUyyWc+LwPHp73N3XC09iB7Tvee2/jiy8evXY7ri2g6+abF/30b2/99Zd7/vUXpKMhLLn7B6jyip3vfYBoNIZSMoRKLgOb1cwwwuFwwGyyw2ozo1zMYWRkBJFUHq5AG1Q6Azrbm7H8x2uIFQNGTg2jvmMJ1v/6t3/euXPn35nv02sxoNbr9eve3fHu2tGThxyzI8dwbvQCLk7Poam5mftNhJdzMGu1MJnM8M9zwetxwWC2QGc0Qa/VwOZ0wGSXkM6WuAU6dHR0YklvL5KpDE4dPAA5No1MoYSHnnjqhm3btoW5FftEF64UcOPq1avvuX/VqrtUlRIBJMNgs6OtaxFqvB6EJy4gPDkOFUEfDNbDJTmhJRirAniCCWo1QaiH0eqETGAm43GYzSZ03LQYMlNMnzsNd6ABRqkGdslnIGBn+vsPTDDvuChARZFZ99prb6x2e2uc8wIBJBOzBJYZeo0KY+fO4sgXhxCPJ5hYgt9fp4DOaDIxWYH0A0wWG4zshtmq6BKi4SimQ1PKcduCbviDLdAajAh29kImfdvnz/dv3bo1Quru0wp5bW5uNrudtsbo2Emo5DzykWmMnDkLMg2zUxMoF3JKwkCgDhWtEdFcAV6nBYXQRaBUgrehHpEcK1HpUdvQiHQygZnQDIYJYMkhweGyQ/LWs3AHZZO0lWWpp6dH2r9/vyQ60PTwI4/e55QjXQf+8QrGhz5nB6KoavWoyEVoqnnU+QPoWrgAjS0tGJ+j0ORymMetkQscAXIJkr8ByXwV2ZIKC7oXobWthYmtPJ+Fmqso5jNw1c2H1V0HLQUqx/sLhUJ49+7dR0UHgr29tzRNnvwI0dkpGF210FX0aO3kSuJRCoMdnrp6OMnzeCJNxNtZWBmxVBoOp4SCyYJMvkyFNHMrPJgJJ2Aw6uGq9aOUSfDxJbg9TZBqg6hU5EsKSsx0dXWJgRYUBdQ1Bvz+wwfTBIkPCa5ErSpCXSkim2In5CrGjp1BeGAYdqqcQL/TqkeKmDBLNugsZlTUGtTVBRBJ5LF33wHMhudQ77FjSasblVIeAtgq9RXGV5UCKO9OHjgJYVj1eoO1UCygDDVmIjG2J4tEeBZzBBKXi7b5N8Bud6BArR+fmMLEREgB5eTMHLejQC0wkX5lDHx2CJFomGB1Y357p6ITci6NfDIs9h0KjUQJlGmDgagkfrWX9JBVkePlSgUyw2pQcaAk2bIq9GYjWht8CNQ3IZYuMMnnOHTkBG5sq0c2nWLCBAqlMgsfZlfSWNrTy27UwmvTIBU6DTCDTqOGipTl0OB8gDJLqpeHmCgpm8vlsxZSxkgN9xA8FrMBRgrMPFKuLKsRmpyEw2ZCc7CB58zIsDhOOogJWc7nEJud4WwYR2PAh+6FXfD7PMoCyiotahpaYK9tVNRQruDqQCyVSkV+FUQHpicnQyHJ46+PTJ2Hg61W8UYHlc3q8nJVSWQ4hJJMqMrmUM6EYTZoqAEl6K0GZRaoOZ4z/G0gYypFmiGtWdl3X7CVgmQh0Wu5bM3lDlwqgJ5BIDQpOnB+4LPB85I/yDlvpKTaUWZLNUYDPB4vlcvKMavB5IXznIIjSMXmKDVqJNM5fgtAqUgrClKF/5KSmVgIcxNnYDLrIXl80OotMDr9vFK0vXJpTHObjx8/PsbcF0QBk3v29E1461upZkby18IqK2xRmUWrlY7YXW4eF3Bx9Czy+RLiTG4j1ez0B2pulSTZaUbKpGMBiZmLXIgBjR03UdTKgNHNwWS5alyEcxKxa9euczw8JwpInz1zJp0ua6at7gBRX1bQGpnj9OMDVAYrZ7sR8VQBB48OIxJLIZUg8AjqRnI74PQhHCtgNhpnxDD45RASBRUKZRVkUw20tjrmViurF+CjAAnXlB4YGIgwd0QUUGVLPnhj67aPbuhdoVCRHOVDkxibmGULTaiqtQjNRTEVyeO2ZbfjkbVrMZ2oEDwzyMbi+OL0BBbddhduvf1OKmUGJ86OYyZWRlEtcZyLvZeV5MJPinjnnXc+ZiF9wpioL6vDEf45prXVzvqauoh0I1weCWPnz+MiGWBzelBLRggB0dLp/OTpZ/C7l/+AaUpv/9gsnvrFr/Dkz3+DhpZ22jYJTTQvvoZW6I1Grrx8FfkiOU1qYcuWLUM8PHCtH6BOyOnh4TPax598umf87FFSrMABZEOCbdXr1JRTj8IIIUi3fP8O1FD/J0g/ldGCH65cCY/Xh7EzRxWx6lm2nCxyK9suVq6mUjKxEhs3bnzr8OHDHzLnyFdNKek42WN3eWLL7rqnY+rcENFP+01mVEk5A8XJV1sDLwUpXahgoH8AQ0MnKddJxY7JxIvd6ULbjQvhdPsV0yfEVyQXKxd7//7773+0efPmITLhza91xTyxd/Czwc6OriWl7922rDk0xiKrJXbCwm0hnUx6TkcaFpoPs8VBcXKigf6htr6Bl2W4ahekmgal4YKiV/ZdJN+3b9/g+vXr95IBL1/rjP/LlrOIgd27+4IeX0P8nvsfas8mY8jEZ8kEg4IBiBcTOQu320Wj2kbL1gSHRY9qOkRH5ILO7LzKd9FyUcCOHTs+fv755/eykM1MkbquFxMm23DHHXfO27Rpw8Pl5JRr5sIxGKgLwu/JFBzwt4n7b3O4FeOio1jNa+uFhiO5RAMjxCYej2dfeumlf7L1E8TY74X0fptXM3Gu12w23/vY40+0rX30wbvtRq23mI2iwDlfosnQqGT6AA+qlGLhju21beytjm5oOrF9+/Y9r7/++lAymRR0++Tbvpp99e1pMd/5VnZ3d0vsSnDRopuCXq/bSbqaiHG6rHw+zLF47NjQ2N69n4wePHgwwtbv4n2DiiP5jm/HVz5CMyRGo7BxwkyIeX75GTkxWBhC30cZ4f/3Vnzl8x8BBgDPWNgE0rbJTwAAAABJRU5ErkJggg=="
    gLogoLion="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA2hpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo4NUEzQThDMDBDMjA2ODExODA4Mzg2QjgyQkZCREI0NSIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDozOTJCMEE3RkVCMTAxMUUxQjRCREVDMkE1MTc4QTBBNiIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDozOTJCMEE3RUVCMTAxMUUxQjRCREVDMkE1MTc4QTBBNiIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ1M2IChNYWNpbnRvc2gpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6ODhBM0E4QzAwQzIwNjgxMTgwODM4NkI4MkJGQkRCNDUiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6ODVBM0E4QzAwQzIwNjgxMTgwODM4NkI4MkJGQkRCNDUiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz45/jkcAAAKdElEQVR42qRXaWwc9RX/zbmzs7Ozh/dwdtfH+ojtxInDkQtCUEMQbZGKyqWKqgJVFa2oqqr91C+VUNsvVT/wAalqpfKpolXbD1RACwWaQgkhhECMc2LH9zq2975mZ3fOvllslEYFInWk55FHO++9ee/3fr/353HzF0Mmk6XIBrfuwa3nGtk62QLZNbImmXszTvmbDDzBMHg0qUryZFpO+U17MKIIadEnKpzAM22jo9U1c72oWYvzJf3aZtNq2o77Ar03Q+Z8kfPPuyZZBo/cMRpO3zWRPHZ5tpjdM5ZAJqHA7w9gJd/A1YV19IR8SIYliCy9YehIZkJrf5szT/z5jY+XDNN+kZ5+8FkV4T4nsfsjPvbh25P+b/SK7pd4vxrxBRVsbNQxPNoHw7YgSGHoLo+NUhO5XB4+ypZ32hgfSar33j0+9cDRkfGFdU3MbdYPkL+3bjYBqjaezgSFo8MR/5OiKITHJkawb2ocO7NJ9O4I49ZDB1GqNSGIIo4dP4yh8TE0TRbnLswjEfIjERYQ7++DT+SVe47edaAtpioXLl7Z5bruu+Tf/rwEGIr+9JHhyN49KfVR2S9hMBWGIroIB3iwnAvbcpDpT8MvuDh98n2EFQGTu/oxdftemC6Hix98hP37+uFTJEihBBrCAJTYyEQkmjAvXJgZdF3n39e348YE7p+IiXdnIsoj4XAQ2VQQEs/BJ4mwTR2qKsOoa5j+4CxCERW5a1VcOD8PH2NCDVjYtXsMxUITYZXD1J3HUKwxmK36sVl20BOLDwk8V5mfnxu/vh3XJ7AnofAPHhiIPtkTCWBiKAqRE+CXJSQjEkzLhuIXUbiWQzLdD5ZgUio1kC/VIfsAVXSQ7JEwuf8I3nrtHaihEMbvuBfLOQ2Lq2W0OxaSid7x9fXclUqlXKN4K9cnwHIs89TXdvc8lk2HQ/2JEASOQaPZRCiqYHahgDc/XAPNGgI+AYm+HpRLBYyNTyCS6EF/uhdKSARDSb5zbhWHjhzEtdmPkB0ZhCQLuDS3gUqtjXa7g1QqvfPixemi43zSCnYrgV07e4T0eF+ovzfsB+N2UCy3YVguTp5dwhszeYwTEE9draEjMFhbKgFCHEoijqPH78Hh+x+CrPbin+/O4fkXTsEht9lb9mJjcQ4hPwOZN1CvV1Gt1tBqmerwMKEWOLhNRB7wHr5vb+9x3udDx7DRIYjUdBN+iUE2rsAVZbA+HnVGxJqh4vCRXciXLbSoIs2eOqKIY2TPYUyvOfhWei86jTwkNgCfzEJgDUoIaDQ0EABhWRbS6ezx2dlLl+n/014F5IgsyBKHgVpNR7mhY7PaQcN0wHfrYyNMTnaPZfHrX/0ELo3b5SvLUIMcOloFzWoBq7Pn4TIuvvngfRjdIaHZbKG8sQY+IHWrmYn56VkDGj3X9TYl4UaCQTVCziNeBdI7E3LaZlhUabZF0Y+aSePmMKizHDiOQyqdgkMvNnILuG0yiQ/PfIxWo4HJ3aNwNBOaSeWtbUIkywz1EzhVrH70NvEEuXcZYk0brm1Cb1uEtk+GMBKODVFbsl4CgxOZYJblfLBtg7IzoMoq9A451lpQw2FY9HXNVgPNBQ1mp41wSEKlUofW0ghYBlEvzXuxQOPKUbAQovEwMDIMrVpEICahXG2iSb5IH7r9ZgngfjngCdpgtwJRmU85toOAX+iWMhgKQrFMKjcDx2rBbAngFblLYY7NwCUyMjrA5nrBe0AjaoF3Dfh9HMygjlA8TTQd2FIhjsDs0Ne34MVo073d0VGtlChLhL0ElGKhpgxn+6mvPhQr1H+tgVhURSqWRbW8AR+B0+djkK806As8RuTot0RKeocqokEJx7CwtAZFsMBwQdxyZ4IS02kE07DYIM7NXMXS4iwF9irc2RJIVqI/fnZbeXRdhyjwiKh+6JUabMOkktkYGptAPJ2ERYFYpwOjpYOlKskSiw6VP9CTBEQJV1ZsXN4gcrIU5KoiJDUKJRjF9JVNvPSP96gF1a3gHguzn7KxV4EWKwqt1WuVnrZWRzabgmn3EKXWIDAdKMT1/oCCaCKKaFLAmTMXqFV+ZDMxSOEQnv/XKhbWzoKWAAynIqQbyzBfPodnf/4YeJ+EgGxApAp+8pnbEuDdHYP+dLxU1puOsMGzPAzqeXGzjCCxl20aKNRo0bEJwQQ8VaUdQCRs9UcxNhSHpASoKg4O3zqKatsl3q9gcW6BOs7h8ccfQjTAQquVEFU4ZHqjW0H/a/3w6LjuJbCwUjEWMr0B8DyNnuZgM19GXzpG2t/CpYUigc9FrbRJhOJgx8AAxEgCvJxE2zAwELbx3DM/xfef+g4BNYzv/egH+PZ3n0C9qaO4vtwdxWg08L92n2WyJa8FufmCvnow7Uc8Eev2J18qo6U34Tgsri5uYvfEELUhAE7wQ2u3UWtUqUptMD4ZDh+FSRz/0NcfQCYzguzOXWg2DERSO8F2Qpil1hSKletK727r/jztB/NeBbRiTdPyTWO9SbNfIXoNqWGPrUjdVGqVg3zdQbB3qNtTlre74+awPvjjfZASabCBKEpVnVCuwfb4hKP1TOmBFBlAxxKwvJrf7vt2Et7SWiQreRWgRNwXr1S5AYktPhGLx+GnZcIgUmJpMgb7B1Ct22hYDI1bAmKnAWJ3wosJmZITfArJ7Tqe/9NLmJ+9iP1TuzGaVggJLuEkRICmdzX9xvK/QTFPeBltb8XnZhbXVyZ3ZPOhSCRBiw1sl0ZJMuknFo1enbDI45U3p1HMrUDlLbAEyFilDW2+gvNXVghwBQQDPlQ35ghaREIeeF0BDOsQO0okUM3t4B2WZc+THJ+8fi13bdt5+e2FRiibjv/Q0Imzidl6IhEU6zp8JCiG3kCnkkehbqDv8AHMLRVIJ1KIxxK459gQRALwLfsmMUq7AsMRYZFrg1iPdji4jvnpp1Pw32/tAvaN54L3l9byiTMrvakhsfVIUPWRKtaIAUNdKp2d/hBxScfRh7+MsSPHqUVMV/e1VgeariESDGHv1B5a4Rho+csUtA29UUB+baVLaFvAe52C/9VrwWcdTP726qkZfPXQuDIhu19xSP8tnoSnnIdYoTXc1TF96kRXsicP3UFLJ+GF9EOWgpCJJARSUoYXCCEuLKNBdweXr+YoQaJohj1NZfW24te/aC2fn8sVK4FogusP85NVrY0WmU3jaUFErXINl85fIoaUkNiRpt4Z3cV1R/9Qd+atZh52a5OIrIGT713CL3/zAnTDecXbhgl4z24d2z43AW9O5hbWCnquyWzQhjzCmK2ASaj3NqW2I6BJuh4OiqiXKjBKi5A5nbAQA2MQWFs0XW4Lc1dX8Ytn/tBa3mz+ttPp/JF8PufR/s2ejLxrrtZoVmeW81UuGJ9Nx9QdeqMWDAYDJFgypm67jbIpIchR/2MK9blGlUD3sLKyUa38+Ge/+8vp6at/NwzjFfL12mcdzZibPJzuI9sfUYPZsWwqvWu0Lzu1e2dMsmuKxFmM0ptplTSjdHZmZfnVE+8t59Y2dcd1vaCn/9/D6Y2XJ2sZsiyZx9uBLW31judlj9u39n39Zo/n/xFgAPVMzBNETn3RAAAAAElFTkSuQmCC"
    gLogoSL="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA2hpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo4NUEzQThDMDBDMjA2ODExODA4Mzg2QjgyQkZCREI0NSIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDozOTJCMEE3QkVCMTAxMUUxQjRCREVDMkE1MTc4QTBBNiIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDozOTJCMEE3QUVCMTAxMUUxQjRCREVDMkE1MTc4QTBBNiIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ1M2IChNYWNpbnRvc2gpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6ODhBM0E4QzAwQzIwNjgxMTgwODM4NkI4MkJGQkRCNDUiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6ODVBM0E4QzAwQzIwNjgxMTgwODM4NkI4MkJGQkRCNDUiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz7Tw361AAAKfklEQVR42qRXWWxc5Rk9s++bPeNlbCd2HDtOQogMiQu0IUpK0ogUlaYUGhoQfUklEFV46BO0oqjLS9UitbxVqkRUoQICCog6pGnsJDQbWRzH+3i8zWLP2J59vVvPPwlqBKRE4sqfxpo79/+/e77vnPP9Otz5pWPYGUFG+81P183vC4w4I8yIMfIM7U4XvZPfbNTr9Y93dXXZ9+/fH9y5c2f7hg0bWrxer1PHK5fLFUKhUPzkyZMz/f39sZGRkbwsy+/yuWsMFV/justoNP7q0KFDfxkbGwurqqrdSczMzESee+65161W6ytcY9sdvugX3nr/9u3b/zg5OTl7u43EJT5udz8Wiy3u3bv3z0Tv5dslYfiyzfnWLx85cuTBt99++3B9fb331ryI+I0Q2KoK9PxHp9P/7/tbIpGMOzs6W/pMZmPq+vDoJuZ7lo8p/y+B2uYvHHn+7qefeerxckWCy+mAXm+oLahpVVSrVRSkClYzeaSyaUTi0Vpk+X+hWECuUOZnEdeGL+PTT8/B43Ojb3vfxqamJunC+YvtiqKcurVBP5/A/oNPHNj52Pd2/zC1Esf83BRGxseQqxqRyeeYhIZURUNkpYJ0QUVeBiowo1TV4/3+kxidnofd5cHxwQFcGhrDutYGeJnA8nIKG3s2rOvsXJ8aHDjVQyQGvyyBLb29vQdeevH5w7KkwGWzwet2YXQqjP98Oo5cWYHB6oFiMCGXq6BUyMNitsDjccBkNkNWdFhZzcJgcSC9mkSwwQuplIPdZoWqKQgGW/GDAz/quXLlyvjExESG+83fmoDebDY/23/sn0/q1JInlylg+OJlrCSWEIkuwefzYCGWgCSr5JQR+WwWZosFRqMJqlSFzapDW1sQnV1diMcWa7/duu0+WCw2XLt0ufY7F5FZu7YD+/bt637ttdeWWcpaKT5LYPPBgwf3/vTw4V3lcgHJpQg+OXMBiXwZ6zf3Ip6TYHV6YdYpDBmZzCpKuTTMRgOisQgURYUiyyiVsvB5XWhtDqJSqaKxrZXouNHY3AYDUfDXeeH2eC2VSmVpcHAwwn0XRAI60uTZN99664C/3u9NJlYxHhpDnnVt7+xEqlBBpiRjYmQMMpPLZFdR7/Uhm0nDYrVgcmoa7R0dcLsoipqGSrGEWGQOK8vLaG5thcNpxtTEJIx6Pa6MTTHpKnbv2hN89dVXV0RDigQcXd3de1785S8eFlB43B4U8iswGFUEuUC6qMHPDR/o7WHNAYtRh1a/B8VyCfl8nklVoMlFbmSD0WRBZHoCumqmBmuuUCAiPvbEEjz+AK5OzmNsMgqP12cbH7l6bX5u/rxIoOPpZ37yyEN7HtqikR0mk4kdYUIsugCDwcGGy7HPFcyEJ2G3m+CwWtFQ58ZSdB4NgXrYHB6YCG9obAhyJceemUW+UMLI8ChamhpRLOSI0BpIeid8/haYDBbMRRNwOCzLZ08PDhmFsXxrx4MdsqxxQz34gcZAAN3r2zExMUcmWBAOR/m9CpPdhcnJMExWEzbevZVvqJCCOtQ3+uFmoy7G5hAKz2Dzpruwbds9mArPw1VXxzWc+HDgJKKLK/j5Cz9DtVyGTi0LQ2sXCbSs7+4OKtxYZTPpVR2hNsPAhgPfbGwsBA8X6Vq7HorOCKXTwPIYiUwJkkJsKEyR+CLWtLTCYi/imzv2weW4wQ693UdBGsGaoB+tvC+QmZ+NIBDwkVl1QmG9IgGn1eV0ysK0NCGrgJlIiCTShF8qVbCOFPN4PbBabdjQ04PzF88jl0myUlaY7Q4Y9EaksxnkSiV0NBMNuxWFQhGqUV9D0G6zQ5HSyKSTTFpCKZ8lXSNW7m3Ti2ahc5BKCrVdveEYqgGB+mZo1Tw6O5pZGg2rqWVU+LYThDiRzKDM5rOYTdArVZQowZmM+I4yzMYrlyjZ5SryqViNpqupDJvRD6vRgfGxESwml6DqbwoQo5jJZYtic3HJTET0QZ2/AZVyEU6XAz6PEzazEVeHhkmxGDu/jGQyIfiLclUkrgmbok9ItSRWszmKj4Z1a/24Z0s3kqSk22VHd/d6NPqbMDRCpoB8pJKLEsSnQ9OLrW1r2gQLDDQegYiqSmhsakI7mzHY3EyzKaCqGUl1HRwGym7KVJPioiQqp8FMdlgYGpOxO91M2k72FLBhTSNCCRmp9ArqyZ4FItIQaKY8y4KrWYFA+MzAqbDMB6WbZVCoduVqEa2tfqysJAhvFk528oauduqAHjYb5bhUxOt/exMK79nYvO//4wMUsgnwFlVPg4PSG0+uEk0jZEmtrcvuJUJF0rWIS+fOzHHvWZFA9N8f90dURVTfBInFUckEt28tNm/ejNGrVxCenGAz5uGmNev0KqxmPQ4+th9ta5oxNTKOmckQnB4T9j20A9VKASajgtwqE6c5Zcpcy+OCXq4AUhmtje6aOU2PXpvmhtMigfzk+Fh+MR6Jc7bhTbU2ZIj28Hrb8P2HdyEZC6G//xjLI27IQrzZtBL+8PvfoLEziIV0BL9+5SWUqP/lTA755SRytG+WlaUxw+m007Bo2+kUm7OCpaVYfvjqxWUutlIzI/pzVqpWAru/s2ernp7voNyqUom0KrMZfVQ/E3y0ZkHN6+MzSKeLpCupx/IMD52CVFiE01GHXDqHs/0fIRkNo/f++1GsqKRnig1pgMISVFmKoevDmLo+9NFsaPINUYLP3HBpfHS094mnntlYT5ydzDYem0eFfu7y1KNYrCBFKkmShLaO9bC761hjN5LxBc4NbnS2byIoBppPEA63A1aPj/W2EvEipsdD8JJFFrMBn5w7h7n5cOX84Mn36J5HbxD+xqUpipwfHR4yHvrxk30Wkw4pGojwATGKWcn3TK5IRKqoDzTQpNpr05Hdbkdj6xpGC5qDLVQ3N72E8yGbTXiHVMwj0NgMOxEUjTgbjSF8/frrkYWFD7ln6PMTUTy6sNDHCSa1bdvWjYkkB4uFBeqCCjMNykm7tTvsnA+NMNscZAKnoTof63tjInKzRPH5MIeVFGlop2paMTcXJVJ2DiMuipkFJ46fOH5mcGCEe/31S2dCMaudPn16U1NTg+Sr86xb4kTkDzTxYaH/+lpz8v0YMvTsZBE6gxmaVCQF0zSYSo3KQpRMJiPee/8Yh5Qyo4Qrly6d//sbbwyQjr+9dTL+wljOH5w9fuxEu9vpTPfd29sj01ScDr4ld9c49egpOnomJIYPRa6yuSTWT2Iyak1FVU2qJZxIJGG1kNJyGUeP/v1fJ04MDFDu/yTGhK86Fyg8awxeuHCpZ3Z2fvyBvrvXGYxWm44JGFhfPTtaSLA4I2i14Vqr/Qmh4XGMGiAGVBkixwafu/jOu/1HrwyNXuf9331+8686G4p799nttoefeOy7XY8++sjuno2bAkaTWnNMTePbEUgh3TIRkGXOBhXCTReMRiKZN9965+Sxj0+P5AvFE1xn4HaH1Ts5swmU7mVN92/dssm369s72r/R19seCDR4DQaTjQ2qK5aK5Vg8kbl46fLcRx/0z4RCs8vk/XE+d+6Gcn290/Fnl8CdBMdaMcaJYUL4+c01SsJYGELfZxjLd3oq/q8AAwBpW2dY6oRolAAAAABJRU5ErkJggg=="
    gLogoLeo="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA2hpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo4NUEzQThDMDBDMjA2ODExODA4Mzg2QjgyQkZCREI0NSIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDozOTJCMEE3N0VCMTAxMUUxQjRCREVDMkE1MTc4QTBBNiIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDozOTJCMEE3NkVCMTAxMUUxQjRCREVDMkE1MTc4QTBBNiIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ1M2IChNYWNpbnRvc2gpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6ODhBM0E4QzAwQzIwNjgxMTgwODM4NkI4MkJGQkRCNDUiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6ODVBM0E4QzAwQzIwNjgxMTgwODM4NkI4MkJGQkRCNDUiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz4KRC+gAAAJ4UlEQVR42qRXWWxc5RX+7jr3zp3V43HiGZvY8RLHUAhLxSKhSlXUBVQJKPQBnlu1Up/7UhXBS5/60rdK7Ut5QZUqqChUBCJKozQJZAHC4jh2vMV7PONZ7tyZu/f7r20pQgVS9Vpn5vrO///nnO98Z7kq7vySKGlKhTKy/53df96hbFAWKOsUmxLfyaHqHSo+TvmJqqppRVUqmqaNlEql6ksvvZzp9hzpN79+seO6vY0gCBZ931+PosiO4/h17rlKif4fA+6RJOm5QiFXHRwc+G6p3D86P7eMIIhRGazi+Reew8dXP4GVzZSiOLqLBj48PFKFZaXXVlfWRuu13aUoit/gOZe/ChHpa7x+ggednBgfeTqdNo+Ih1Ymj+3tHazcXIOqyLj/weMwzQwuX74Kp+NCT2mYmj4K3+1CilV0u+7W7OzcX227s8PtL/83I6SvUP7S0NDg2LHJsRdkVYamKYhjGa7rQ6bia5/No+t2EIQSNNWEZVr8zcbYVBUD5RJ2Gw1sbTTQaLT43IUk4fV6rf4pw/Jbnu1+nQGJcnp+793Tk0+Nj1UQRSpSuo4oltDzPOi6Aq8WYWFmDZ7sIog1mEoOpaKKvqk05uZuYG1lG71uD7Kscr2OcrkPy8srp9tt+xwxePl2XnyZAwL28UzGemp1bQtTx46imM8BssTDJMTcRhLCHLKgN7No9HrQZAOZ1CG0rev499lLaDXbUGQZqqbSeCBfyKHVajFUxklBzo7tvHh7OJTblH+L1j5TLOZ/RrzprQ+PCk5MjMBMm8iks8hkLeTyeWRLWZTKA9hY2ELa92CUQlxcvgS7aSOV0mmvlEBpZUzyQkez0RZhgGGkppgp14IgbPLnFaFU3lfOPdKz5f7Sj4XyOAyhyxHqq7vYuLqMQT9GQYrRZ1ExEakU+lAYUjFaLeGh+76DTW818VLXNQjVqqJCUiQM9g0icMgThiJ5RiuKpcLzsix/78D5gxBMm6ZZpeq7ZCoyNAsGcgikAs7PexgvrKB6uA+S04FvqDi7soNTH1zEY5MPYjCzg08XZ6CGMTy/S+MjxFR0qL+MCe0EAsygIxEB6oviHhEyc9Vq5djNm6sPU+85dZ94zxaLhZMiLBLZrkkWQqmISKugFzj4cMnHT0c1rO428MezF/HZ2jY0Rcf7zgWcv/Yhuo6DiAb4foAwChGGHqZLT0EP+qAl1I6TgAsjfNcjN6KTRGOGWXFBGJBmZaOoRzzPRRxIaMcdSKELU23C0tNw/XGcnqnj1LWLmFndhk4ieoGLzVsOFUZMRU0cmsQ5oAGV3CHovo/F5mWua0IO+VwKGN0wWRPLUZE6i57nFQUHqpZlVRMbeQj3Iwy4OOoixxw/OjCF4fwAXDuLHosLq13iy55CKSFcGETJ/wG5I+L9o2OPQY+7jC+NA4kYG5AjJVmXiBcxFNpRHjQqThsxzNQoA5dAJMl6klpFOY2R4igGB8YxWi5j2uogWw7wu7deo2KZ3sSCr/vVI07i6PZcPPnoI3jm8cdx7pMFuNEWIodnxinseG2E2CZiPYYoEIaLhjYiDKgahlFRmBARmRpzsS5lUKH3pkLIog6mBu7D1BEFE8Oj+NfN6zh/6SMoiranW0DKAsHUwvjUJH71i19C/mID/UTDYia0qUxSDqOhpuleF2BGhVHAAhYVuL0gQpDRNS0jEjKOWOnouRT6yKrCIxudrWVcufQaLl05g9rKCh49cfceoZIEFihISTYLr07c/yCOTD6AZqfN4mQix7T0em2sdT5Hy71BI7tCMTMjOcHghynveSElXsQ81Q1bjH0aE7mHSAYJQ9WHcHhgkqRSsLmwgXdPnxGFEZGIJb1kYUnir1HZe++8jQ/Ov4fJ+x/AE8/9HEPZQWTMCVbFKteKFGX/CHpJ+MTeg0LkkDxOyDSKaFgvbDDFJDQIaU/Oo91uoNcLoaQy+HBzBQu1LZZlmYQLkkOE50FC2hhsv/jza6/C0vK4tb6N9W6MGhFyIx+6kk5qREB0xT4a4QnaCA5seK6/KUnK8EEqNYMabjiL0IzDbF0udl2HfEjj0q01mCkDPcdPvDggoAiFcEBWFJyd+QJ/u3AGWmsQG0StIznMHIdhDeFLflKk4ijpRaIctwQCC7ZtLwSBKBChYBSRD+EaDhxll6nXg8EW+5m8ic1ajfqUBCkRtr3wKcl9Ivxrtjv4+/XzmAk62AoaUEzCrDNUcGiglqStoiRVeJmyJBBY7XTsVVHHBQJiAZQYXalDyxW0whr8YgnXFucYGpmb9zojVAn5VGpPqdtL5gVBSAHIldkryOaH4KMFicUsVn2obEqaaKf7E4Btt+f5dUMg0PE83+botCFQVZiKmqnSasYYbWilACs2B5CmwzgqsHhQlkLb8D0y/ul7HqH3MVswkOIzlfyw2z1s1GfQX/Y5FdXYEVl40ioMU2dbTokiZJM7Nequyft9+Q2OTe8IcqXolWGlIKforS6j/64C1rfX6T2h53STJ1ID2TSm+4dQVAeQYzofLw0SORm6RuN07ucssLG+hkwRVM4UpQqVv6WMVNIxOSWdprPvicHkoB1/1O06y1S+zaJE6HX4TLPRo1UubnC7YLHEAsWezhDlDR2PjH8frtSPna6JyfwYypZB9muw2C0toohexF5RwxCHVJvNKgz20o7xd5vN1qe8PXv7PCBQeLNe332VbVlUes55KQxXDifDZjFbQDHNBm3qSQ0Yzk4hqxzHzq0FdDmyuUEBY32H2JQUGqomIpMPu7U68kSrr1BMUlVcHGpfYQad4W345YlonYsUEk9nc5q+9767CRctpOc5TkQmSSexW4p27XklNG0HdtAiAXdQ79YJMQcR3aMxSMibomRNg0bJnJ7K2K7X0W51TtXr9Veo69RXzYRvra1toFgoZIaHDv2g3a6LexKOHY/jlUF4nfkart/agiQ4RFb7NKLLlhv1AhwupWl0mCDRlzWRz6d5HyOdYapG4bnNzc0Ltyv/MgIH18L2rZ06S7MyNT52j0YYUiSQwQJkMBQXPr4Ou2uzunXRDVkrOLD4HECc5D5Cf5FjW18eh4YG2T2LSJHQX8wuvfnJ1RkR89+LyvtNBgg+zC0tr3avzS1uTk2OTTC10lbawqWrs5i9sZCQ0qPiXtJifaZ2lKSiz7KsEvaxsRHkijk2LMX5x7tn//D5zPxfeOafKN07fTM6uB5mhfvh1ORk5fixySdnZq9Xup6T1HKf03DSUJJuKO3NB/vteeTIcK3Var85P7+0zOL2Ph//8+tePO/k5fQE5duchkY5WldYSEbZ5MvMiEy8p93mPFAjiZd6PXc1EH0XeJvywTe9JUv43y5j/7V8lNIvZon9VBav46KyLVLW9qG+o9fz/wgwAABSmLJsFoI9AAAAAElFTkSuQmCC"

    gCollapseDivId=0
    gPageNavLinks=""
    gBootloadersTextbuildString=""
    gVERS="$passedVersion"
    gtheprog="$passedAppName"
    gMasterDumpFolder="$passedDirToRead"
    
    gTMPDir=/tmp
    gSMDir="$gMasterDumpFolder"/DMIDump
    gDEVDir="$gMasterDumpFolder"/DevPropsDump
    gACPIDir="$gMasterDumpFolder"/ACPIDump
    gAMLDir="$gACPIDir"/AML
    gDSLDir="$gACPIDir"/DSL
    gMiscDir="$gMasterDumpFolder"/Misc
    gScriptDir="$gMiscDir"/Scripts
    gSMCDir="$gMasterDumpFolder"/SMCDump
    gSYSinfoDir="$gMasterDumpFolder"/SystemInfo
    gIOregDir="$gMasterDumpFolder"/IORegDump
    gBootSectDir="$gMasterDumpFolder"/BootSectDump
    gBootConfigDir="$gMasterDumpFolder"/BootloaderConfigFiles
    gRTCDir="$gMasterDumpFolder"/RTCDump
    gBiosROMDir="$gMasterDumpFolder"/BiosROMDump
    gEDIDDir="$gMasterDumpFolder"/EDIDDump
    gHtmlDumpFile="$gMasterDumpFolder"/DarwinDump.htm
    gCssDumpFile="$gMasterDumpFolder"/CssDumpFile.htm
    gLogFile="$gMasterDumpFolder"/DarwinDumper_log.txt
}

# ---------------------------------------------------------------------------------------
CheckRoot()
{
    if [ "`whoami`" != "root" ]; then
        echo "Running this requires you to be root."
        sudo "$0"
        exit 0
    fi
}

# ---------------------------------------------------------------------------------------
CheckOsVersion()
{
    local osVer=`uname -r`
    local osVer=${osVer%%.*}
    local rootSystem=""
    
    if [ "$osVer" == "8" ]; then
	    rootSystem="Tiger"
    elif [ "$osVer" == "9" ]; then
	    rootSystem="LEO"
    elif [ "$osVer" == "10" ]; then
	    rootSystem="SL"
    elif [ "$osVer" == "11" ]; then
	    rootSystem="Lion"
    elif [ "$osVer" == "12" ]; then
	    rootSystem="ML"
	else 
	    rootSystem="Unknown"
    fi
    echo "$rootSystem"  # This line acts as a return to the caller.
}

#
# =======================================================================================
# WRITE HTML, CSS, JAVASCRIPT & RELATED CODE ROUTINES
# =======================================================================================
#

# ---------------------------------------------------------------------------------------
CloseHtmlFile()
{
    echo "Closing HTML"
    WriteHtmlFooterToFile
    WriteHtmlCloseBodyDivToFile
    WriteHtmlCloseSectionCollapseExpandDivToFile
}

# ---------------------------------------------------------------------------------------
CloseCssFile()
{
    echo "Closing CSS"
    echo "</style>" >> "$gCssDumpFile"
}

# ---------------------------------------------------------------------------------------
CombineCssAndHtmlFiles()
{
    echo "Combining CSS and HTML"
    cat "$gHtmlDumpFile" >> "$gCssDumpFile"
    rm "$gHtmlDumpFile"
    mv "$gCssDumpFile" "$gHtmlDumpFile" 
}

# ---------------------------------------------------------------------------------------
WriteHtmlHeaderToFile()
{
    local passedDirToRead="$1"
    
    echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">
<html xmlns=\"http://www.w3.org/1999/xhtml\">
<head>
<meta name=\"description\" content=\"DarwinDumper Report of OS X System\" />
<meta name=\"author\" content=\"Trauma, JrCs, sonotone, phcoder, STLVNUB, blackosx\" />
<meta name=\"keywords\" content=\"osx, system dump, acpi tables, device properties, disk util, bootloaders, memory map, ioreg, kernel dmesg log, kexts, lspic, rtc, smbios, smc, systemprofiler\" />
<meta name=\"copyright\" content=\"Copyright 2010-2012 org.darwinx86.app. All rights reserved.\">
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />
<title>$passedDirToRead</title>" >> "$gCssDumpFile"
}

# ---------------------------------------------------------------------------------------
WriteCssToFile()
{
    echo "<link rel=\"stylesheet\" href=\"IORegDump/IORegViewer/Resources/jquery_ui_themes/smoothness/jquery-ui-1.10.0.custom.css\" />
    <style type=\"text/css\">
#container { width: $gMasterFrameWidth; padding: 40px; margin:0 auto; background: #FFF; }
#overview_frame_outer { width: 980; height: 148px; margin-top: 0; margin-right: auto; margin-bottom: 0; margin-left: auto; padding: 10px; border: thin solid #CCC; background-color: #F1F1F1; }
#overview_panel_logo{ width: 148px; float: left; background-repeat: no-repeat; background-position: center center; height: 148px; background-image: url($gLogoDD); }
#overview_panel_title{ width: 660px; float: left; height: 36px; margin: 10px; }
#overview_panel_info{ width: 300px; float: left; height: 64px; margin: 10px; border-right-width: 1px; border-right-style: solid; border-right-color: #999; }
#overview_panel_details{ width: 305px; float: left; height: 64px; margin: 10px; border-right-width: 1px; border-right-style: solid; border-right-color: #999; }
#overview_panel_osver{ width: 160px; float: right; margin: 10px; height: 64px; margin-top: 10px; margin-right: 10px; margin-bottom: 10px; margin-left: 5px; }
#overview_logo_ml{ width: 32px; float: left; height: 32px; margin: 10px; background-image: url($gLogoML); }
#overview_logo_lion{ width: 32px; float: left; height: 32px; margin: 10px; background-image: url($gLogoLion); }
#overview_logo_sl{ width: 32px; float: left; height: 32px; margin: 10px; background-image: url($gLogoSL); }
#overview_logo_leo{ width: 32px; float: left; height: 32px; margin: 10px; background-image: url($gLogoLeo); }
#clear_Line { clear: both; height: 40px; background-color: #FFF; width: auto; } 
#dump_section_outer_header { background-color: #76a24b; width: auto; padding-left: 10px; padding-top: 5px; margin-top: 6px; border-top-width: 1px; border-top-style: solid; border-top-color: #638047; padding-bottom: 5px; border-right-width: 1px; border-left-width: 1px; border-right-style: solid; border-left-style: solid; border-right-color: #638047; border-left-color: #638047; }
#dump_section_outer_header2 { background-color: #76a24b; width: auto; height: 30px; border-top-width: 1px; border-top-style: solid; border-top-color: #638047; border-right-width: 1px; border-left-width: 1px; border-right-style: solid; border-left-style: solid; border-right-color: #638047; border-left-color: #638047; }
#dump_section_outer_header2 a:hover { color: #FFF; background-color: #92CB5E; }
#dump_section_outer_header_warning { background-color: #E60023; width: auto; padding-left: 10px; padding-top: 5px; margin-top: 10px; border-top-width: 1px; border-top-style: solid; border-top-color: #C20019; padding-bottom: 5px; border-right-width: 1px; border-left-width: 1px; border-right-style: solid; border-left-style: solid; border-right-color: #C20019; border-left-color: #C20019; }
#dump_section_inner_table_header { background-color: #666; width: auto; padding-left: 10px; padding-top: 5px; border-top-width: 1px; border-top-style: solid; border-top-color: #555; padding-bottom: 5px; border-right-width: 1px; border-left-width: 1px; border-right-style: solid; border-left-style: solid; border-right-color: #555; border-left-color: #555; }
#dump_section_inner_table_header2 { background-color: #666; width: auto; height: 26px; border-top-width: 1px; border-top-style: solid; border-top-color: #555; border-right-width: 1px; border-left-width: 1px; border-right-style: solid; border-left-style: solid; border-right-color: #555; border-left-color: #555; }
#dump_section_inner_table_header2 a:hover { color: #FFF; background-color: #999999; }
#dump_section_inner_table_subheader_info { background-color: #CCC; width: auto; padding-left: 10px; padding-top: 3px; padding-bottom: 3px; border-right-width: 1px; border-left-width: 1px; border-right-style: solid; border-left-style: solid; border-right-color: #666; border-left-color: #666; }
#dump_section_inner_table_content_container { background-color: #EEE; width: auto; padding-left: 10px; padding-bottom: 5px; margin-bottom: 4px; padding-top: 5px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-right-color: #7B7B7B; border-bottom-color: #7B7B7B; border-left-color: #7B7B7B; }
#dump_section_inner_table_content_container_scroll { background-color: #EEE; width: auto; padding-left: 10px; padding-bottom: 5px; margin-bottom: 4px; padding-top: 5px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-right-color: #7B7B7B; border-bottom-color: #7B7B7B; border-left-color: #7B7B7B; height: 400px; overflow: auto; }
#footer { background-color: #E7E7E7; width: auto; padding-left: 10px; padding-top: 5px; margin-top: 10px; padding-bottom: 5px; text-align: center; }
#nav ul { height: 20px; background-color: #a6d0ed; margin-top: 8px; margin-bottom: 8px; padding: 0; list-style-type: none; text-align: center; }
#nav li { display: inline; line-height: 20px; font-family: Tahoma, Geneva, sans-serif; font-size: 10px; }
#nav ul li a { text-decoration: none; color: #666; border-right-width: 1px; border-left-width: 1px; border-right-style: solid; border-left-style: solid; border-right-color: #FFF; border-left-color: #FFF; padding-top: 4px; padding-right: 5px; padding-bottom: 4px; padding-left: 5px; }
#nav ul li a:hover { color: #FFF; background-color: #2765CB; border-right-width: 1; border-left-width: 1; border-right-style: solid; border-left-style: solid; border-right-color: #FFF; border-left-color: #FFF; }
#nav_acpi ul { height: 18px; background-color: #BFD5D1; margin-top: 4px; margin-bottom: 5px; padding: 0; list-style-type: none; text-align: center; }
#nav_acpi li { display: inline; height: 18px; line-height: 18px; font-family: Tahoma, Geneva, sans-serif; font-size: 9px; }
#nav_acpi ul li a { text-decoration:none; color: #000; border-right-width: 1px; border-left-width: 1px; border-right-style: solid; border-left-style: solid; border-right-color: #FFF; border-left-color: #FFF; padding-right: 5px; padding-left: 5px; }
#nav_acpi ul li a:hover { color: #FFF; background-color: #2765CB; border-right-width: 1; border-left-width: 1; border-right-style: solid; border-left-style: solid; border-right-color: #FFF; border-left-color: #FFF; }
/* ioreg items */
body { font-family: Tahoma, Lucida Grande, Lucida Sans Unicode; font-size: 11px; background-color: #666; }  
#ioregistry_container { width: 1000px; height: 600px; background-color: #555; margin-top: 0; margin-right: auto; margin-bottom: 0; margin-left: auto;}
#ioregistry_header { height:60px; background-image: url(IORegDump/IORegViewer/Resources/assets/ioregwebviewertitle.png); background-repeat: no-repeat; background-position: right top; margin-right: 8px; }
.user_drop_down_choice select { background-color: #666; width: 290px; margin-left: 12px; margin-top: 15px; font-size: 12px; height: 20px; border: 0; color: #FFF;  }
#class_placeholder { margin-left: 12px; margin-top: 6px; }
.class_info { color: #FFF; }
#ioregistry_user_select_search { position:absolute;  margin-left:8px;}
input { height: 16px; width: 150px; background-color: #666; font-size:12px; margin-left: 0px; margin-top: 4px; margin-right: 4px; border: 1px; border: 1px solid #CCC; color: #FFF; }
.user_search_button { background-color: #7a8d68; color: #FFF; } 
.user_clear_button { background-color: #7a8d68; color: #FFF; } 
#leftPaneTreeHeader { width:290px; height: 30px; margin-left: 12px; background:#76a24b; }
#leftPaneTree { position:absolute; width:290px; height: 500px; margin-left: 12px; background:#F1F1F1; overflow:auto; }
#rightPaneTreeHeader { position:absolute; float: right; margin-top: -30px; margin-left:312px; width:678px; height: 30px; background:#76a24b; }
#titleProperty { float: left; margin-left:19px; margin-top:10px; }
#titleType { float: left; margin-left:185px; margin-top:10px; }
#titleValue { float: left; margin-left:60px; margin-top:10px; }
.titleText { color: #FFF; font-size: 10px; font-weight: bold; }
#rightPaneTree {  position:absolute; float:right; margin-left:312px; height:500px; background:#F1F1F1; overflow:scroll; }
/* end ioreg items*/
a:link { color: #248EFF; }
a:hover { color: #900; }
a:visited { color: #739958; }
.text_large_section_outer_title { font-size: 14px; font-weight: bold; color: #FFF; position: relative; left: 10px; top: 5px; }
.text_medium_section_inner_title { font-size: 12px; font-weight: bold; color: #FFF; position: relative; left: 10px; top: 5px; }
.text_small_section_inner_title { font-size: 12px; font-weight: normal; color: #000; }
.text_medium_show_hide { font-size: 12px; font-weight: bold; }
.text_overview_heading { font-size: 20px; font-weight: bold; color: #069; }
.text_overview_body { font-size: 12px; line-height: 18px; }
.text_table_heading { font-family: Menlo, Monaco, Courier New; font-size: 10px; font-weight: bold; }
.text_table { font-family: Menlo, Monaco, Courier New; font-size: 10px; }
.navlinks { font-family: Tahoma, Geneva, sans-serif; font-size: 10px; }
.state { display: $gTableState; }
a.make_div_clickable { display: block; height: 100%; width: 100%; }" >> "$gCssDumpFile"
}

# ---------------------------------------------------------------------------------------
WriteJavaScriptToFile()
{
    echo "<script src=\"IORegDump/IORegViewer/Resources/scripts/jquery-1.9.0.min.js\"></script>
<script src=\"IORegDump/IORegViewer/Resources/scripts/jquery.jstree.js\"></script>
<script src=\"IORegDump/IORegViewer/Resources/scripts/jstreegrid_dd.js\"></script>
<script src=\"IORegDump/IORegViewer/Resources/scripts/jquery.hotkeys.js\"></script>
<script src=\"IORegDump/IORegViewer/Resources/scripts/ioregviewer_dd.js\"></script>
<script src=\"IORegDump/IORegViewer/Resources/scripts/jquery-ui-1.10.0.custom.min.js\"></script>
<script type=\"text/javascript\">
function navShowHeaderBar(divID, state)
{
    var table = document.getElementById(divID);
    table.style.display = 'block';
}
function headerBarToggleShowHide(divID, state)
{
    var table = document.getElementById(divID);
    if (table.style.display == 'block') {
        table.style.display = 'none';
    } else {
        table.style.display = 'block';
    }
}
</script>" >> "$gHtmlDumpFile"
}

# ---------------------------------------------------------------------------------------
WriteHtmlFooterToFile()
{
    echo "<div id=footer> <span class=\"navlinks\">The DarwinDumper scripts and tools are enclosed in a <a href=\"http://sveinbjorn.org/platypus/\">Platypus</a> application wrapper and uses <a href=\"https://github.com/maccman/macgap\">macgap</a> for it's user interface for gathering user input.</span></div>" >> "$gHtmlDumpFile"
}

# ---------------------------------------------------------------------------------------
CalculateTableWidths()
{
    local passedOutputType="$1"
    
    # This uses the gMasterFrameWidth set at the head of this file.
    local wgContainerWidth=${gMasterFrameWidth%px*}
    gTableBoxWidth=$((wgContainerWidth-20))
    gTableTextBoxWidth=$((gTableBoxWidth-6))

    # Calculate percentage widths of table columns, then add 100.
    if [ "$passedOutputType" == "DiskDump" ]; then
        # Original design pixel widths were 53, 66, 142, 181, 58, 146, 90, 204
        # New design pixel widths are 35, 60, 165, 162, 47, 130, 186, 161
        # To fit UEFI revisions, let's try widths of 30, 57, 160, 157, 45, 125, 180, 180
        # Latest squeeze to fit better, let's try widths of 7, 56, 139, 163, 50, 120, 214, 205
        local gColOnePcToUse=$(bc <<< 'scale=3; 7 / '$gTableTextBoxWidth' * 100 + 100')
        local wgCoTwoPcToUse=$(bc <<< 'scale=3; 56 / '$gTableTextBoxWidth' * 100 + 100')
        local gColThreePcToUse=$(bc <<< 'scale=3; 139 / '$gTableTextBoxWidth' * 100 + 100')
        local gColFourPcToUse=$(bc <<< 'scale=3; 163 / '$gTableTextBoxWidth' * 100 + 100')
        local gColFivePcToUse=$(bc <<< 'scale=3; 50 / '$gTableTextBoxWidth' * 100 + 100')
        local gColSixPcToUse=$(bc <<< 'scale=3; 120 / '$gTableTextBoxWidth' * 100 + 100')
        local gColSevenPcToUse=$(bc <<< 'scale=3; 214 / '$gTableTextBoxWidth' * 100 + 100')
        local gColEightPcToUse=$(bc <<< 'scale=3; 205 / '$gTableTextBoxWidth' * 100 + 100')
    fi
    
    if [ "$passedOutputType" == "KextDump" ]; then
        # Original design pixel widths were 34, 34, 108, 68, 68, 341, 89, 170
        local gColOnePcToUse=$(bc <<< 'scale=3; 34 / '$gTableTextBoxWidth' * 100 + 100')
        local wgCoTwoPcToUse=$(bc <<< 'scale=3; 34 / '$gTableTextBoxWidth' * 100 + 100')
        local gColThreePcToUse=$(bc <<< 'scale=3; 108 / '$gTableTextBoxWidth' * 100 + 100')
        local gColFourPcToUse=$(bc <<< 'scale=3; 68 / '$gTableTextBoxWidth' * 100 + 100')
        local gColFivePcToUse=$(bc <<< 'scale=3; 68 / '$gTableTextBoxWidth' * 100 + 100')
        local gColSixPcToUse=$(bc <<< 'scale=3; 341 / '$gTableTextBoxWidth' * 100 + 100')
        local gColSevenPcToUse=$(bc <<< 'scale=3; 89 / '$gTableTextBoxWidth' * 100 + 100')
        local gColEightPcToUse=$(bc <<< 'scale=3; 170 / '$gTableTextBoxWidth' * 100 + 100')
    fi

    # Calculate pixel width to use based on percentage of total width.
    gColOne=$(bc <<< 'scale=3; '$gTableTextBoxWidth' / 100 * '$gColOnePcToUse' - '$gTableTextBoxWidth' ')
    gColTwo=$(bc <<< 'scale=3; '$gTableTextBoxWidth' / 100 * '$wgCoTwoPcToUse' - '$gTableTextBoxWidth' ')
    gColThree=$(bc <<< 'scale=3; '$gTableTextBoxWidth' / 100 * '$gColThreePcToUse' - '$gTableTextBoxWidth' ')
    gColFour=$(bc <<< 'scale=3; '$gTableTextBoxWidth' / 100 * '$gColFourPcToUse' - '$gTableTextBoxWidth' ')
    gColFive=$(bc <<< 'scale=3; '$gTableTextBoxWidth' / 100 * '$gColFivePcToUse' - '$gTableTextBoxWidth' ')
    gColSix=$(bc <<< 'scale=3; '$gTableTextBoxWidth' / 100 * '$gColSixPcToUse' - '$gTableTextBoxWidth' ')
    gColSeven=$(bc <<< 'scale=3; '$gTableTextBoxWidth' / 100 * '$gColSevenPcToUse' - '$gTableTextBoxWidth' ')
    gColEight=$(bc <<< 'scale=3; '$gTableTextBoxWidth' / 100 * '$gColEightPcToUse' - '$gTableTextBoxWidth' ')
}

# ---------------------------------------------------------------------------------------
BuildHtmlPageNavLinks()
{    
    local checkFileExistence=""
       
    gPageNavLinks="<div id=\"nav\">
    <ul>"
    
    # This is removed for now
    #<li><a href=\"#aTop\">Top</a></li>"
    
    checkFileExistence=`find "$gDSLDir" -type f ! -name .DS_Store -print 2>/dev/null`
    if [ ! "$checkFileExistence" == "" ]; then
        gPageNavLinks="$gPageNavLinks<li><a style=\"cursor:pointer;\" onClick=\"javascript:navShowHeaderBar('collapseID_ACPI', this)\" href=\"#aACPI\">ACPI</a></li>"
    fi
    
    if [ -f "$gSYSinfoDir/AudioDumpVoodoo.txt" ]; then
        gPageNavLinks="$gPageNavLinks<li><a style=\"cursor:pointer;\" onClick=\"javascript:navShowHeaderBar('collapseID_Audio', this)\" href=\"#aAudio\">Audio</a></li>"
    fi

    if [ -d "$gBootConfigDir" ]; then
        gPageNavLinks="$gPageNavLinks<li><a style=\"cursor:pointer;\" onClick=\"javascript:navShowHeaderBar('collapseID_BootConfigPlist', this)\" href=\"#aBootConfigPlist\">Loader Config</a></li>"
    fi

    if [ -f "$gDEVDir/device-properties.plist" ]; then
        gPageNavLinks="$gPageNavLinks<li><a style=\"cursor:pointer;\" onClick=\"javascript:navShowHeaderBar('collapseID_DevProps', this)\" href=\"#aDeviceProps\">Dev Props</a></li>"
    fi
    
    checkFileExistence=`find "$gBootSectDir" -type f -name *PartitionTableInfo.txt -print 2>/dev/null`
    if [ ! "$checkFileExistence" == "" ]; then
        gPageNavLinks="$gPageNavLinks<li><a style=\"cursor:pointer;\" onClick=\"javascript:navShowHeaderBar('collapseID_PartInfo', this)\" href=\"#aPartitionInfo\">Partitions</a></li>"
    fi
    
    if [ -f "/tmp/diskutilLoaderInfo.txt" ]; then
        gPageNavLinks="$gPageNavLinks<li><a style=\"cursor:pointer;\" onClick=\"javascript:navShowHeaderBar('collapseID_DULoaders', this)\" href=\"#aDiskUtilLoaders\">DiskUtil</a></li>"
    fi
    
    if [ -f "$gBootSectDir/UIDs.txt" ]; then
        gPageNavLinks="$gPageNavLinks<li><a style=\"cursor:pointer;\" onClick=\"javascript:navShowHeaderBar('collapseID_UIDs', this)\" href=\"#aUIDs\">UIDs</a></li>"
    fi
    
    if [ -f "$gEDIDDir/EDID.txt" ]; then
        gPageNavLinks="$gPageNavLinks<li><a style=\"cursor:pointer;\" onClick=\"javascript:navShowHeaderBar('collapseID_EDID', this)\" href=\"#aEDID\">EDID</a></li>"
    fi
    
    if [ `find "$gIOregDir" -type f -name *_BootLog.txt -print 2>/dev/null` ]; then
        gPageNavLinks="$gPageNavLinks<li><a style=\"cursor:pointer;\" onClick=\"javascript:navShowHeaderBar('collapseID_FirmLog', this)\" href=\"#aFirmwareLog\">Firmware Log</a></li>"
    fi
    
    if [ -f "$gSYSinfoDir/FirmwareMemoryMap.txt" ]; then
        gPageNavLinks="$gPageNavLinks<li><a style=\"cursor:pointer;\" onClick=\"javascript:navShowHeaderBar('CollapseID_FirmMemMap', this)\" href=\"#aFirmwareMemoryMap\">Mem Map</a></li>"
    fi
    
    if [ -d "$gIOregDir/IORegViewer/Resources/dataFiles" ]; then
        gPageNavLinks="$gPageNavLinks<li><a style=\"cursor:pointer;\" onClick=\"javascript:navShowHeaderBar('collapseID_Ioreg', this)\" href=\"#aIOREG\">IOreg</a></li>"
    fi
    
    if [ -f "$gSYSinfoDir/Boot-Messages.txt" ]; then
        gPageNavLinks="$gPageNavLinks<li><a style=\"cursor:pointer;\" onClick=\"javascript:navShowHeaderBar('collapseID_KernBootMess', this)\" href=\"#aKernelBootMessages\">dmesg</a></li>" 
    fi
    
    if [ -f "$gSYSinfoDir/Kernel-Info.txt" ]; then
        gPageNavLinks="$gPageNavLinks<li><a style=\"cursor:pointer;\" onClick=\"javascript:navShowHeaderBar('collapseID_KernInfo', this)\" href=\"#aKernelInfo\">Kernel Info</a></li>"
    fi
    
    if [ -f "$gSYSinfoDir/AppleKexts.txt" ] || [ -f "gSYSinfoDir/NonAppleKexts.txt" ]; then
        gPageNavLinks="$gPageNavLinks<li><a style=\"cursor:pointer;\" onClick=\"javascript:navShowHeaderBar('collapseID_Kexts', this)\" href=\"#aKexts\">Kexts</a></li>"
    fi
    
    if [ -f "$gSYSinfoDir/lspci.txt" ] || [ -f "gSYSinfoDir/lspci_detailed.txt" ] || [ -f "gSYSinfoDir/lspcitree.txt" ]; then
        gPageNavLinks="$gPageNavLinks<li><a style=\"cursor:pointer;\" onClick=\"javascript:navShowHeaderBar('collapseID_Lspci', this)\" href=\"#aLSPCI\">LPSCI</a></li>"
    fi
    
    if [ -f "$gMiscDir/gEfiAppleNvramGuid_Vars.txt" ] || [ -f "$gScriptDir/rc.local" ] || [ -f "$gScriptDir/rc.shutdown.local" ]; then
        gPageNavLinks="$gPageNavLinks<li><a style=\"cursor:pointer;\" onClick=\"javascript:navShowHeaderBar('collapseID_Misc', this)\" href=\"#aMisc\">Misc</a></li>"
    fi
    
    if [ -f "$gSYSinfoDir/nvram.plist" ]; then
        gPageNavLinks="$gPageNavLinks<li><a style=\"cursor:pointer;\" onClick=\"javascript:navShowHeaderBar('collapseID_NVRAM', this)\" href=\"#aNVRAM\">NVRAM</a></li>"
    fi
    
    if [ -f "$gSYSinfoDir/openCLinfo.txt" ]; then
        gPageNavLinks="$gPageNavLinks<li><a style=\"cursor:pointer;\" onClick=\"javascript:navShowHeaderBar('collapseID_OpenCL', this)\" href=\"#aOpenCL\">OpenCL</a></li>"
    fi
    
    if [ -f "$gRTCDir/RTCDump.txt" ]; then
        gPageNavLinks="$gPageNavLinks<li><a style=\"cursor:pointer;\" onClick=\"javascript:navShowHeaderBar('collapseID_RTC', this)\" href=\"#aRTC\">RTC</a></li>"
    fi
    
    if [ -f "$gSMDir/SMBIOS.txt" ]; then
        gPageNavLinks="$gPageNavLinks<li><a style=\"cursor:pointer;\" onClick=\"javascript:navShowHeaderBar('collapseID_SMBIOS', this)\" href=\"#aSMBIOS\">SMBIOS</a></li>"
    fi
    
    checkFileExistence=`find "$gSMCDir" -type f ! -name .DS_Store -print 2>/dev/null`
    if [ ! "$checkFileExistence" == "" ]; then
        gPageNavLinks="$gPageNavLinks<li><a style=\"cursor:pointer;\" onClick=\"javascript:navShowHeaderBar('collapseID_SMC', this)\" href=\"#aSMC\">SMC</a></li>"
    fi
    
    if [ -f "$gSYSinfoDir/System-Profiler.spx" ]; then
        gPageNavLinks="$gPageNavLinks<li><a style=\"cursor:pointer;\" onClick=\"javascript:navShowHeaderBar('collapseID_SysProf', this)\" href=\"#aSystemProfiler\">Sys Prof</a></li>"
    fi
    
    gPageNavLinks="$gPageNavLinks</ul></div>"
}

# ---------------------------------------------------------------------------------------
WriteHtmlPageNavLinks()
{
    echo "$gPageNavLinks" >> "$gHtmlDumpFile"
}

# ---------------------------------------------------------------------------------------
WriteHtmlCloseHeadToFile()
{
    echo "</head>" >> "$gHtmlDumpFile"
}

# ---------------------------------------------------------------------------------------
WriteHtmlOpenBodyOpenDivToFile()
{
    if [ -d "$gIOregDir/IORegViewer/Resources/dataFiles" ]; then
        echo "<body bgcolor=\"#666\" onload=\"Initiate('IOService')\">
<div id=\"container\">" >> "$gHtmlDumpFile"
    else
        echo "<body bgcolor=\"#666\">
<div id=\"container\">" >> "$gHtmlDumpFile"
    fi
}

# ---------------------------------------------------------------------------------------
WriteHtmlCloseBodyDivToFile()
{
    echo "</div> <!-- End container -->
</body>
</html>" >> "$gHtmlDumpFile"
}

# ---------------------------------------------------------------------------------------
WriteHtmlSectionAnchorToFile()
{
    local passedAnchor="$1"
    
    echo "<a name=\"$passedAnchor\"></a>" >> "$gHtmlDumpFile"
}

# ---------------------------------------------------------------------------------------
WriteHtmlSectionHeadingToFile()
{
    local passedSectionHeading="$1"
    
    echo "<span class=\"text_large_section_outer_title\">$passedSectionHeading</span>" >> "$gHtmlDumpFile"
}

# ---------------------------------------------------------------------------------------
WriteHtmlAnchorAndSectionOuterToFile()
{
    local passeOuterHeading="$1" # Used for the table title.
    local passedOuterAnchor="$2" # Used for the html anchor.
    local passedWarning="$3"
    local passedCollapseDivId="$4"
    #local divToUse="dump_section_outer_header"
    local divToUse="dump_section_outer_header2"
    local whichArrow=$(SelectArrow)
    
    if [[ "$passedWarning" == Warning* ]]; then
        divToUse="dump_section_outer_header_warning"
        passedWarning="    ($passedWarning)" # Make it better for printing to html
    fi

    echo "<a name=\"$passedOuterAnchor\"></a>
<div id=\"$divToUse\">
<a class=\"make_div_clickable\" style=\"cursor:pointer;\" onClick=\"javascript:headerBarToggleShowHide('$passedCollapseDivId', this)\"> <span class=\"text_large_section_outer_title\"> $passeOuterHeading $passedWarning</span></a>
</div> <!-- End dump_section_outer_header -->
<div id=\"$passedCollapseDivId\">" >> "$gHtmlDumpFile"

    echo "#$passedCollapseDivId { display: $gTableState; }" >> "$gCssDumpFile"
}

# ---------------------------------------------------------------------------------------
WriteHtmlCloseSectionOuterDivToFile()
{    
    echo "</div> <!-- End sectionname -->" >> "$gHtmlDumpFile"
}

# ---------------------------------------------------------------------------------------
WriteHtmlCloseSectionCollapseExpandDivToFile()
{    
    echo "</div> <!-- End Outer Section Collapse/Expand div-->" >> "$gHtmlDumpFile"
}

# ---------------------------------------------------------------------------------------
WriteHtmlTableHeaderToFile()
{
    local passedTableHeading="$1"
    
    echo "<div id=\"dump_section_inner_table_header2\">
  <span class=\"text_medium_section_inner_title\">$passedTableHeading</span>
</div>" >> "$gHtmlDumpFile"
}

# ---------------------------------------------------------------------------------------
WriteHtmlTableHeaderWithCollapseToFile()
{
    local passedTableHeading="$1"
    local passedCollapseDivId="$2"
    local whichArrow=$(SelectArrow)
    
    if [ "$passedCollapseDivId" == "" ]; then
        passedCollapseDivId=collapseID_$gCollapseDivId
    fi
    
    echo "<div id=\"dump_section_inner_table_header2\"> 
<a class="make_div_clickable" style=\"cursor:pointer;\" onClick=\"javascript:headerBarToggleShowHide('$passedCollapseDivId', this)\"> <span class=\"text_medium_section_inner_title\"> $passedTableHeading</span></a></td></tr></table>
</div> <!-- End dump_section_inner_table_header2 -->
<div id=\"$passedCollapseDivId\">" >> "$gHtmlDumpFile"

    echo "#$passedCollapseDivId { display: $gTableState; }" >> "$gCssDumpFile"
    ((gCollapseDivId++))
}

# ---------------------------------------------------------------------------------------
WriteHtmlTableSubHeaderToFile()
{
    local passedType="$1"
    local passedDevice="$2"
    local passedSize="$3"
    local passedContent="$4"
    local passedMbrBootCode="$5"
    local finalDestination="$6"
    
    if [ "$passedType" == "Disk" ]; then
        if [ "$passedMbrBootCode" == "" ] || [ "$passedMbrBootCode" == " " ]; then
            passedMbrBootCode=""
        else
            passedMbrBootCode="| MBR boot code detected: $passedMbrBootCode"
        fi
        echo "<div id=\"dump_section_inner_table_subheader_info\">
<table width=\"$gTableBoxWidth\" border=\"0\"><tr><td width=\"$gTableTextBoxWidth\" class=\"text_small_section_inner_title\">$passedDevice | $passedSize | $passedContent $passedMbrBootCode | <a href=\"$finalDestination\" target=\"_blank\">View Disk Sectors</a></td></tr></table>
</div>" >> "$gHtmlDumpFile"
    else
        echo "<div id=\"dump_section_inner_table_subheader_info\">
<table width=\"$gTableBoxWidth\" border=\"0\"><tr><td width=\"$gTableTextBoxWidth\" class=\"text_small_section_inner_title\">$passedDevice</td></tr></table>
</div>" >> "$gHtmlDumpFile"
    fi
}

# ---------------------------------------------------------------------------------------
WriteHtmlTableTextHeadingToFile()
{   
    local tableType="$1"
    # These tables have text headings
    if [ "$tableType" == "diskutil" ]; then
        echo "<div id=\"dump_section_inner_table_content_container\">
<table style=\"table-layout: fixed; width: 100%\" width=\"$gTableBoxWidth\" border=\"0\">
  <tr class=\"text_table_heading\"><td width=\"$gColOne\"></td><td width=\"$gColTwo\">DEVICE</td><td width=\"$gColThree\">TYPE</td><td width=\"$gColFour\">NAME</td><td width=\"$gColFive\">SIZE</td><td width=\"$gColSix\">PBR (Stage1)</td><td width=\"$gColSeven\">BootFile (Stage 2)</td><td width=\"$gColEight\">UEFI BootFile</td></tr>" >> "$gHtmlDumpFile"
    elif [ "$tableType" == "NonAppleKexts" ]; then
        echo "<div id=\"dump_section_inner_table_content_container\">
<table style=\"table-layout: fixed; width: 100%\" width=\"$gTableBoxWidth\" border=\"0\">
  <tr class=\"text_table_heading\"><td width=\"$gColOne\">IDX</td><td width=\"$gColTwo\">REFS</td><td width=\"$gColThree\">ADDRESS</td><td width=\"$gColFour\">SIZE</td><td width=\"$gColFive\">WIRED</td><td width=\"$gColSix\">NAME</td><td width=\"$gColSeven\">VERSION</td><td width=\"$gColEight\">LINKED AGAINST</td></tr>" >> "$gHtmlDumpFile"
    elif [ "$tableType" == "AppleKexts" ]; then
        echo "<div id=\"dump_section_inner_table_content_container_scroll\">
<table style=\"table-layout: fixed; width: 100%\" width=\"$gTableBoxWidth\" border=\"0\">
  <tr class=\"text_table_heading\"><td width=\"$gColOne\">IDX</td><td width=\"$gColTwo\">REFS</td><td width=\"$gColThree\">ADDRESS</td><td width=\"$gColFour\">SIZE</td><td width=\"$gColFive\">WIRED</td><td width=\"$gColSix\">NAME</td><td width=\"$gColSeven\">VERSION</td><td width=\"$gColEight\">LINKED AGAINST</td></tr>" >> "$gHtmlDumpFile"
    
    # Don't print a text table header for the others.
    # These tables don't use scrollable boxes
    elif [ "$tableType" == "IOreg" ] || [ "$tableType" == "LSPCI_detailed" ] || [ "$tableType" == "SMCFans" ] || [ "$tableType" == "RTC" ] \
              || [ "$tableType" == "config_Chameleon" ] || [ "$tableType" == "config_Apple" ]|| [ "$tableType" == "UIDs" ] \
              || [ "$tableType" == "gEfiAppleNvramGuidVars" ] || [ "$tableType" == "rcLocal" ] || [ "$tableType" == "rcShutdownLocal" ] \
              || [ "$tableType" == "PartitionInfo" ]; then
        echo "<div id=\"dump_section_inner_table_content_container\">
<table style=\"table-layout: fixed; width: 100%\" width=\"$gTableBoxWidth\" border=\"0\">" >> "$gHtmlDumpFile"

    # These tables use scrollable boxes
    else 
        echo "<div id=\"dump_section_inner_table_content_container_scroll\">
<table style=\"table-layout: fixed; width: 100%\" width=\"$gTableBoxWidth\" border=\"0\">" >> "$gHtmlDumpFile"
    fi
}

# ---------------------------------------------------------------------------------------
WriteHtmlOverviewToFile()
{
    local passedDirToRead="$1"
    local passedVersion="$2"
    local passedTimeStamp="$3"
    local passedSystemVersion="$4"
    local passedBuildVersion="$5"
    local passedMacModel="$6"
    local passedCpu="$7"
    local passedGraphics="$8"
    local passedCodecID="$9"
    
    local buildFile=""
    local osVersion=""
    local osLogo=""

    case "${passedSystemVersion}" in
        "LEO")  osVersion="Leopard" 
                osLogo="overview_logo_leo" ;;
        "SL")   osVersion="Snow Leopard"
                osLogo="overview_logo_sl" ;;
        "Lion") osVersion="Lion"
                osLogo="overview_logo_lion" ;;
        "ML")   osVersion="Mountain Lion"
                osLogo="overview_logo_ml" ;;
    esac
     
    buildFile="<div id=\"overview_frame_outer\">
  <div id=\"overview_panel_logo\"><div id=\"ddlogo\"></div></div>"
    if [ "$gPrivateState" == "Private" ]; then
  buildFile="$buildFile
  <div id=\"overview_panel_title\"><p><span class=\"text_overview_heading\">$passedDirToRead Report&nbsp;<img alt=\"\" width=\"52\" height=\"22\" align=\"top\" src=\"${privateStamp}\"/></span><span class=\"text_overview_body\">&nbsp;&nbsp;Version: ${passedVersion}</span></p></div>"
    else
  buildFile="$buildFile
  <div id=\"overview_panel_title\"><p><span class=\"text_overview_heading\">$passedDirToRead Report</span><span class=\"text_overview_body\">&nbsp;&nbsp;Version: ${passedVersion}</span></p></div>"
    fi
    buildFile="$buildFile
    <div id=\"overview_panel_info\"><span class=\"text_overview_body\">Development location: <a href=\"http://www.projectosx.com/forum/index.php?showtopic=2447\" target=\"_blank\">http://www.projectosx.com</a><br />
Date: ${passedTimeStamp}</br >Mac Model: <a href=\"http://www.everymac.com/ultimate-mac-lookup/?search_keywords=${passedMacModel}\" target=\"_blank\">${passedMacModel}</a></span></div>
  <div id=\"overview_panel_details\"><span class=\"text_overview_body\">CPU: ${passedCpu}<br />Audio: ${passedCodecID}<br />Graphics: ${passedGraphics}</span></div>
  <div id=\"overview_panel_osver\"><div id=\"${osLogo}\"></div><span class=\"text_overview_body\">Operating System<br /><strong>${osVersion}</strong><br />Build: ${passedBuildVersion}</span></div>
</div> <!-- End overview_frame_outer -->
<div id=\"clear_Line\"></div>"
    echo "${buildFile}" >> "$gHtmlDumpFile"
}

# ---------------------------------------------------------------------------------------
WriteHtmlTableTextToFile()
{
    local passedFieldOne="$1"
    local passedFieldTwo="$2"
    local passedFieldThree="$3"
    local passedFieldFour="$4"
    local passedFieldFive="$5"
    local passedFieldSix="$6"
    local passedFieldSeven="$7"
    local passedFieldEight="$8"
    
    if [ "$passedFieldOne" = "" ]; then
        passedActive="&nbsp;"
    fi
    if [ "$passedFieldTwo" = "" ]; then
        passedDevice="&nbsp;"
    fi
    if [ "$passedFieldThree" = "" ]; then
        passedType="&nbsp;"
    fi
    if [ "$passedFieldFour" = "" ]; then
        passedName="&nbsp;"
    fi
    if [ "$passedFieldFive" = "" ]; then
        passedSize="&nbsp;"
    fi
    if [ "$passedFieldSix" = "" ]; then
        passedPbr="&nbsp;"
    fi
    if [ "$passedFieldSeven" = "" ]; then
        passedBoot="&nbsp;"
    fi
    if [ "$passedFieldEight" = "" ]; then
        passedLoader="&nbsp;"
    fi
    
    case "$#" in
        1) echo "<tr class=\"text_table\"><td style=\"word-wrap: break-word\">$passedFieldOne</td></tr>" >> "$gHtmlDumpFile" ;;
        2) echo "<tr class=\"text_table\"><td style=\"word-wrap: break-word\">$passedFieldOne</td><td style=\"word-wrap: break-word\">$passedFieldTwo</td></tr>" >> "$gHtmlDumpFile" ;;
        3) echo "<tr class=\"text_table\"><td style=\"word-wrap: break-word\">$passedFieldOne</td><td style=\"word-wrap: break-word\">$passedFieldTwo</td><td> style=\"word-wrap: break-word\"$passedFieldThree</td></tr>" >> "$gHtmlDumpFile" ;;
        4) echo "<tr class=\"text_table\"><td style=\"word-wrap: break-word\">$passedFieldOne</td><td style=\"word-wrap: break-word\">$passedFieldTwo</td><td style=\"word-wrap: break-word\">$passedFieldThree</td><td style=\"word-wrap: break-word\">$passedFieldFour</td></tr>" >> "$gHtmlDumpFile" ;;
        5) echo "<tr class=\"text_table\"><td style=\"word-wrap: break-word\">$passedFieldOne</td><td style=\"word-wrap: break-word\">$passedFieldTwo</td><td style=\"word-wrap: break-word\">$passedFieldThree</td><td style=\"word-wrap: break-word\">$passedFieldFour</td><td style=\"word-wrap: break-word\">$passedFieldFive</td</tr>" >> "$gHtmlDumpFile" ;;
        6) echo "<tr class=\"text_table\"><td style=\"word-wrap: break-word\">$passedFieldOne</td><td style=\"word-wrap: break-word\">$passedFieldTwo</td><td style=\"word-wrap: break-word\">$passedFieldThree</td><td style=\"word-wrap: break-word\">$passedFieldFour</td><td style=\"word-wrap: break-word\">$passedFieldFive</td><td style=\"word-wrap: break-word\">$passedFieldSix</td></tr>" >> "$gHtmlDumpFile" ;;
        7) echo "<tr class=\"text_table\"><td style=\"word-wrap: break-word\">$passedFieldOne</td><td style=\"word-wrap: break-word\">$passedFieldTwo</td><td style=\"word-wrap: break-word\">$passedFieldThree</td><td style=\"word-wrap: break-word\">$passedFieldFour</td><td style=\"word-wrap: break-word\">$passedFieldFive</td><td style=\"word-wrap: break-word\">$passedFieldSix</td><td style=\"word-wrap: break-word\">$passedFieldSeven</td></tr>" >> "$gHtmlDumpFile" ;;
        8) echo "<tr class=\"text_table\"><td style=\"word-wrap: break-word\">$passedFieldOne</td><td style=\"word-wrap: break-word\">$passedFieldTwo</td><td style=\"word-wrap: break-word\">$passedFieldThree</td><td style=\"word-wrap: break-word\">$passedFieldFour</td><td style=\"word-wrap: break-word\">$passedFieldFive</td><td style=\"word-wrap: break-word\">$passedFieldSix</td><td style=\"word-wrap: break-word\">$passedFieldSeven</td><td style=\"word-wrap: break-word\">$passedFieldEight</td></tr>" >> "$gHtmlDumpFile" ;;
    esac
}

# ---------------------------------------------------------------------------------------
WriteHtmlTableTextEndingToFile()
{
    echo "</table>
</div> <!-- End table_container ( also closes End table_container_scroll ) -->" >> "$gHtmlDumpFile"
}

# ---------------------------------------------------------------------------------------
InsertInternalSeparatorHTMLToFile()
{
    local passedTitle="$1"
    
    echo "" >> "$gHtmlDumpFile"
    echo "<!-- ====================================================================================================================================================== -->" >> "$gHtmlDumpFile"
    echo "<!--                                                     SECTION FOR: $passedTitle                                        -->" >> "$gHtmlDumpFile"
    echo "<!-- ====================================================================================================================================================== -->" >> "$gHtmlDumpFile"
    echo "" >> "$gHtmlDumpFile"
}

# ---------------------------------------------------------------------------------------
SelectArrow()
{
    local whichArrow=""
    if [ "$gTableState" == "block" ]; then
        whichArrow="${gArrowClosed}"
    else
        whichArrow="${gArrowOpen}"
    fi
    echo "$whichArrow" # This line acts as a return to the caller.
}    
    
# ---------------------------------------------------------------------------------------
SetHtmlNonBreakingSpace()
{
    local passedFile="$1"
    
    expand "$passedFile" > "$passedFile_spaces.txt" # Convert tabs to spaces
    sed -i.bak 's/ /\&nbsp\;/g' "$passedFile_spaces.txt" # Convert spaces to html non-breaking space &nbsp
    
    echo "$passedFile_spaces.txt" # This line acts as a return to the caller.
}

# ---------------------------------------------------------------------------------------
FixHtmlLessThanGreaterThan()
{
    local passedFile="$1"
    
    sed -i.bak 's/</\&lt\;/g' "$passedFile" # Convert < to &lt
    sed -i.bak 's/>/\&gt\;/g' "$passedFile" # Convert > to &gt
    
    echo "$passedFile" # This line acts as a return to the caller.
}

# ---------------------------------------------------------------------------------------
RemoveHtmlNonBreakingSpaceFiles()
{
    local passedFile="$1"
    
    rm "$passedFile_spaces.txt"
    rm "$passedFile_spaces.txt.bak"
}

# ---------------------------------------------------------------------------------------
ReadFileAndWriteCompleteSectionToHtml()
{
    local passedFile="$1"
    local passedSectionHeading="$2"
    local passedTableHeading="$3"
    local passedSubHeader="$4"
    local passedTextHeading="$5"
    local passedAnchor="$6"
    local passedWarning="$7"
    local passedColllapseDivId="$8"
    local lineRead
    
    WriteHtmlAnchorAndSectionOuterToFile "$passedSectionHeading" "$passedAnchor" "$passedWarning" "$passedColllapseDivId"
    WriteHtmlTableHeaderToFile "$passedTableHeading"
    WriteHtmlTableSubHeaderToFile "" "$passedSubHeader"
    WriteHtmlTableTextHeadingToFile "$passedTextHeading"
    
    local fixedFile=$(SetHtmlNonBreakingSpace "$passedFile")
    local fixedFile=$(FixHtmlLessThanGreaterThan "$fixedFile")
    
    while read -r lineRead
    do
        WriteHtmlTableTextToFile "$lineRead"
    done < "$fixedFile"
    #RemoveHtmlNonBreakingSpaceFiles "$passedFile"
    
    WriteHtmlTableTextEndingToFile   
    WriteHtmlPageNavLinks
    WriteHtmlCloseSectionOuterDivToFile     
}

# ---------------------------------------------------------------------------------------
ReadFileAndWriteSubSectionToHtml()
{
    local passedFile="$1"
    local passedTableHeading="$2"
    local passedSubHeader="$3"
    local passedTextHeading="$4"
    local passedAnchor="$5"	
    local passedCollapseOption="$6" # Will be either ID Value or N
    local passedCollapseDivId="$7"
    local lineRead
    
    if [ ! "$passedAnchor" == "" ]; then
        echo "<a name=\"$passedAnchor\"></a>" >> "$gHtmlDumpFile"
    fi
    if [ $passedCollapseOption == "N" ]; then
        WriteHtmlTableHeaderToFile "$passedTableHeading"
    else
        WriteHtmlTableHeaderWithCollapseToFile "$passedTableHeading" "$passedCollapseDivId"
    fi
    WriteHtmlTableSubHeaderToFile "" "$passedSubHeader"
    WriteHtmlTableTextHeadingToFile "$passedTextHeading"
    
    local fixedFile=$(SetHtmlNonBreakingSpace "$passedFile")
    local fixedFile=$(FixHtmlLessThanGreaterThan "$fixedFile")

    while read -r lineRead
    do
        WriteHtmlTableTextToFile "$lineRead"
    done < "$fixedFile"
    #RemoveHtmlNonBreakingSpaceFiles "$passedFile"
    
    WriteHtmlTableTextEndingToFile    
}

# ---------------------------------------------------------------------------------------
CreateAndInitialiseHtmlFile()
{
    echo "Creating HTML report..." >> "${gLogFile}"
    echo "Creating HTML report"
    WriteHtmlHeaderToFile "$gtheprog"
    WriteCssToFile
    WriteJavaScriptToFile
    WriteHtmlCloseHeadToFile
    WriteHtmlOpenBodyOpenDivToFile
    DumpSystemOverview
    BuildHtmlPageNavLinks
    WriteHtmlPageNavLinks
}

#
# =======================================================================================
# READ DUMP FILES & CALL HTML WRITE ROUTINES 
# =======================================================================================
#

# ---------------------------------------------------------------------------------------
DumpSystemOverview()
{
    local macGraphics=""
    local macModel=""
    local macCpu=""
    local systemVersion=$(CheckOsVersion)
    
    macGraphics=`/usr/sbin/system_profiler SPDisplaysDataType | grep "Chipset Model:"`
    macGraphics="${macGraphics##*: }"
    macModel=`/usr/sbin/system_profiler SPHardwareDataType | grep "Model Identifier:"`
    macModel="${macModel##*: }"
    
    if [ "${systemVersion}" == "ML" ] || [ "${systemVersion}" == "Lion" ] ||[ "${systemVersion}" == "SL" ]; then
        macCpu=`sysctl -a | grep "cpu.brand_string"`
    else
        if [ -f "$gSYSinfoDir/System-Profiler.txt" ]; then
            macCpu=`fgrep "Processor Name:" "$gSYSinfoDir/System-Profiler.txt"`
        else
            macCpu=`sysctl -a | grep "cpu.brand_string"`
        fi
    fi
    macCpu="${macCpu##*: }"
    
    local buildVersion=`ioreg -lw0 | grep "OS Build Version"`
    buildVersion="${buildVersion##*= \"}"
    buildVersion="${buildVersion%%\"*}"
    local timeStamp=`date`

    # Sometimes the AudioCodec can report more than one line.
    # For Example:
    # Cirrus Logic CS4206
    # ATI R6xx HDMI
    #
    # But there's only space for one line in the report header.
    # So, remove the line breaks and add a slash to separate them.
    gCodecID=$( echo "$gCodecID" | tr "\n" "/"  | sed 's/.$//' )

    WriteHtmlSectionAnchorToFile "aTop"
    WriteHtmlOverviewToFile "$gtheprog" "$gVERS" "$timeStamp" "$systemVersion" "$buildVersion" "$macModel" "$macCpu" "$macGraphics" "$gCodecID"
}

# ---------------------------------------------------------------------------------------
DumpHtmlAcpiTables()
{
    local finalDestination=""
    local acpiFileName=()
    local acpiFileNameExtensionRemoved=()
    local count=0
    local n
    local acpiNavLinks=""
    
    local checkFileExistence=`find "$gDSLDir" -type f -name *.dsl -print 2>/dev/null`
    if [ ! "$checkFileExistence" == "" ]; then
    
        echo "    adding ACPI tables" >> "${gLogFile}"
        InsertInternalSeparatorHTMLToFile "ACPI Tables"
        
        # Build ACPI table html nav links
        acpiNavLinks="<div id=\"nav_acpi\">
<ul>"  
        for file in "$gDSLDir"/*
        do
            acpiFileName+=("${file##*/}")
            acpiFileNameExtensionRemoved+=("${acpiFileName[$count]%.dsl*}")
            #acpiNavLinks="${acpiNavLinks}<li><a href=\"#a${acpiFileNameExtensionRemoved[$count]}\">${acpiFileNameExtensionRemoved[$count]}</a></li>"
            acpiNavLinks="${acpiNavLinks}<li><a style=\"cursor:pointer;\" onClick=\"javascript:navShowHeaderBar('collapseID_${acpiFileNameExtensionRemoved[$count]}', this)\" href=\"#a${acpiFileNameExtensionRemoved[$count]}\">${acpiFileNameExtensionRemoved[$count]}</a></li>"
            ((count++))
        done
        acpiNavLinks="${acpiNavLinks}</ul>
</div> <!-- End nav_acpi div section -->"

        # Write html tables.
        WriteHtmlAnchorAndSectionOuterToFile "ACPI Tables" "aACPI" "" "collapseID_ACPI"
        finalDestination="ACPIDump/DSL"
        for (( n=0; n<$count; n++ ))
        do
            ReadFileAndWriteSubSectionToHtml "$gDSLDir/${acpiFileName[$n]}" "${acpiFileNameExtensionRemoved[$n]}" "<a href=\"$finalDestination/${acpiFileName[$n]}\" target=\"_blank\">View File ${acpiFileName[$n]}</a>" "ACPI" "a${acpiFileNameExtensionRemoved[$n]}" "${acpiFileName[$n]}" "collapseID_${acpiFileNameExtensionRemoved[$n]}"
            echo "${acpiNavLinks}" >> "$gHtmlDumpFile"
            echo "</div> <!-- End div section for device id & set state -->" >> "$gHtmlDumpFile"
        done

        WriteHtmlPageNavLinks
        WriteHtmlCloseSectionOuterDivToFile
    fi
}

# ---------------------------------------------------------------------------------------
DumpHtmlAudio()
{
    local finalDestination="SystemInfo"
    if [ -f "$gSYSinfoDir/AudioDumpVoodoo.txt" ]; then
        echo "    adding AudioDumpVoodoo.txt" >> "${gLogFile}"
        InsertInternalSeparatorHTMLToFile "Audio Voodoo Dump"
        ReadFileAndWriteCompleteSectionToHtml "$gSYSinfoDir/AudioDumpVoodoo.txt" "Audio" "Dumped using <a href=\"http://www.projectosx.com/forum/index.php?showtopic=355\" target=\"_blank\">VoodooHDA's getdump tool</a>" "<a href=\"$finalDestination/AudioDumpVoodoo.txt\" target=\"_blank\">View AudioDumpVoodoo.txt File</a>" "Audio" "aAudio" "" "collapseID_Audio"
    fi
}

# ---------------------------------------------------------------------------------------
DumpHtmlDeviceProperties()
{
    local finalDestination="DevPropsDump"
    if [ -f "$gDEVDir/device-properties.plist" ]; then
        echo "    adding device properties" >> "${gLogFile}"
        InsertInternalSeparatorHTMLToFile "Device Properties"
        ReadFileAndWriteCompleteSectionToHtml "$gDEVDir/device-properties.plist" "Device Properties" "Dumped using gfxutil v0.71b by McMatrix from 2007" "<a href=\"$finalDestination/device-properties.plist\" target=\"_blank\">View device-properties.plist File</a>" "DeviceProperties" "aDeviceProps" "" "collapseID_DevProps"
    fi
}

# ---------------------------------------------------------------------------------------
DumpHtmlDiskutilAndLoader()
{
    local finalDestination=""
    local fileToRead="/tmp/diskutilLoaderInfo.txt" # Created in the gatherDiskUtilLoaderinfo.sh script

    if [ -f "$fileToRead" ]; then
        echo "    adding diskutil & loader info" >> "${gLogFile}"
        InsertInternalSeparatorHTMLToFile "Diskutil & Bootloaders"
        WriteHtmlAnchorAndSectionOuterToFile "Diskutil & Bootloaders" "aDiskUtilLoaders" "" "collapseID_DULoaders"
        CalculateTableWidths "DiskDump"
    
        while read -r lineRead
        do
            if [ "${lineRead:0:1}" == "=" ]; then
                WriteHtmlTableTextEndingToFile
                echo "</div> <!-- End div section for device id & set state -->" >> "$gHtmlDumpFile"
            else
                codeRead="${lineRead%%:*}"
                detailsRead="${lineRead#*:}"
                if [ "$detailsRead" == "" ]; then
                    detailsRead=" "
                fi 
        
                case "$codeRead" in
                    "WD") diskIdentifier="${detailsRead}"
                          WriteHtmlTableHeaderWithCollapseToFile "${diskIdentifier}" ;;
                    "DN") diskName="${detailsRead}" ;;
                    "DS") diskSize="${detailsRead}" ;;
                    "DT") diskType="${detailsRead}" ;;
                    "S0") stageZero="${detailsRead}" 
                          finalDestination="BootSectDump/${diskIdentifier##*/}-${diskName}-${diskSize}.txt"
                          WriteHtmlTableSubHeaderToFile "Disk" "${diskName}" "${diskSize}" "${diskType}" "$stageZero" "$finalDestination"
                          WriteHtmlTableTextHeadingToFile "diskutil" ;;
                    "VA") volumeActive="${detailsRead}" ;;
                    "VD") volumeDevice="${detailsRead}" ;;
                    "VT") volumeType="${detailsRead}" ;;
                    "VN") volumeName="${detailsRead}" ;;
                    "VS") volumeSize="${detailsRead}" ;;
                    "S1") stageOne="${detailsRead}"
                          WriteHtmlTableTextToFile "$volumeActive" "${volumeDevice}" "${volumeType}" "${volumeName}" "${volumeSize}" "${stageOne}" "" "" ;;
                    "BF") bootFile="${detailsRead}" ;;
                    "S2") if [ "${detailsRead}" == "" ] || [[ "${detailsRead}" =~ ^\ +$ ]] ;then # if blank or only whitespace
                              stageTwo=""
                          else
                              stageTwo="(${detailsRead})"
                          fi
                          WriteHtmlTableTextToFile "" "" "" "" "" "" "<b>${bootFile}</b>${stageTwo}" ;;
                    "UF") uefiFile="${detailsRead}" ;;
                    "U2") if [ "${detailsRead}" == "" ] || [[ "${detailsRead}" =~ ^\ +$ ]] ;then # if blank or only whitespace
                              uefiFileVersion=""
                          else
                              uefiFileVersion="(${detailsRead})"
                          fi
                          WriteHtmlTableTextToFile "" "" "" "" "" "" "" "<b>${uefiFile}</b>${uefiFileVersion}";;
                esac 
            fi
        done < "$fileToRead"
        WriteHtmlPageNavLinks
        WriteHtmlCloseSectionOuterDivToFile 
    fi
}

# ---------------------------------------------------------------------------------------
DumpHtmlDiskUUIDs()
{
    local finalDestination="BootSectDump"
    if [ -f "$gBootSectDir/UIDs.txt" ]; then
        echo "    adding disk & volume UIDs" >> "${gLogFile}"
        InsertInternalSeparatorHTMLToFile "Disk & Volume UIDs"
        ReadFileAndWriteCompleteSectionToHtml "$gBootSectDir/UIDs.txt" "Disk & Volume UIDs" "UUID's grabbed from diskutil info. Unique partition GUID's dumped from IOreg." "<a href=\"$finalDestination/UIDs.txt\" target=\"_blank\">View UIDs.txt File</a>" "UIDs" "aUIDs" "" "collapseID_UIDs"
    fi
}

# ---------------------------------------------------------------------------------------
DumpHtmlDiskPartitionTableInfo()
{
    local finalDestination="BootSectDump"
    local checkFileExistence=`find "$gBootSectDir" -type f -name *PartitionTableInfo.txt -print 2>/dev/null`
    if [ ! "$checkFileExistence" == "" ]; then
        echo "    adding partition table info" >> "${gLogFile}"
        InsertInternalSeparatorHTMLToFile "Disk Partition Table Info"
        
        WriteHtmlAnchorAndSectionOuterToFile "Disk Partition Table Info" "aPartitionInfo" "" "collapseID_PartInfo"
        for file in "$gBootSectDir"/*PartitionTableInfo.txt
        do
            local fileFound="${file##*/}"
            ReadFileAndWriteSubSectionToHtml "$gBootSectDir/$fileFound" "/dev/${fileFound%-*}" "Dumped using fdisk440 /dev/diskX & gpt -r show /dev/diskX&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"$finalDestination/$fileFound\" target=\"_blank\">View $fileFound File</a>" "PartitionInfo" "" "partition_table"
    	    echo "</div> <!-- End div section for device id & set state -->" >> "$gHtmlDumpFile"
        done
    	WriteHtmlPageNavLinks
    	WriteHtmlCloseSectionOuterDivToFile
    fi
}

# ---------------------------------------------------------------------------------------
DumpHtmlBootloaderConfigs()
{
    # Note - the config files are dumped by the diskutil and loader routine.
    
    local plistFiles=()
    local plistName=""
    local finalDestination="${gBootConfigDir##*/}"
    local fileLocation=""
    local fileType=""
    local oIFS="$IFS"
    
    # ---------------------------------------------------------------------------------------
    getConfigType()
    {
        local passedTextLine="$1"
        local fileType=""
        
        if [ ! "$passedTextLine" == "" ]; then
            case "${passedTextLine##*/}" in
                "org.chameleon.Boot.plist") fileType="Chameleon" ;;
                "com.apple.Boot.plist") fileType="Apple" ;;
                "config.plist") fileType="Clover" ;;
                "settings.plist") fileType="XPC" ;;
            esac
            echo "$fileType" # This line acts as a return to the caller.
        fi
    }
    
    if [ -d "$gBootConfigDir" ]; then
        echo "    adding Bootloader config files" >> "${gLogFile}"
        InsertInternalSeparatorHTMLToFile "Bootloader Config .plist files"
        IFS=$'\n'
        plistFiles=( $(find "$gBootConfigDir" -type f -name "*.plist") )
        if [ ${#plistFiles[@]} -eq 1 ]; then
            fileLocation="${plistFiles[0]##*$gBootConfigDir/}"
            fileType=$(getConfigType "${plistFiles[0]}")
            ReadFileAndWriteCompleteSectionToHtml "${plistFiles[0]}" "Bootloader Config files" "/$fileLocation : $fileType" "<a href=\"$finalDestination/$fileLocation\" target=\"_blank\">View ${plistFiles[0]##*/}</a>" "config_$fileType" "aBootConfigPlist" "" "collapseID_BootConfigPlist"
        elif [ ${#plistFiles[@]} -gt 1 ]; then
            WriteHtmlAnchorAndSectionOuterToFile "Bootloader Config .plist files" "aBootConfigPlist" "" "collapseID_BootConfigPlist"
            for (( p=0; p<${#plistFiles[@]}; p++ ))
            do
                if [ -f "${plistFiles[$p]}" ]; then
                    fileLocation="${plistFiles[$p]##*$gBootConfigDir/}"
                    fileType=$(getConfigType "${plistFiles[$p]}")
                    ReadFileAndWriteSubSectionToHtml "${plistFiles[$p]}" "/$fileLocation : $fileType" "<a href=\"$finalDestination/$fileLocation\" target=\"_blank\">View ${plistFiles[$p]##*/}</a>" "config_$fileType" "aBootConfigPlist" "${plistFiles[$p]}"
                    echo "</div> <!-- End div section for device id & set state -->" >> "$gHtmlDumpFile"
                fi
            done
            WriteHtmlPageNavLinks
            WriteHtmlCloseSectionOuterDivToFile
        fi
        IFS="$oIFS"
    fi
}

# ---------------------------------------------------------------------------------------
DumpHtmlFirmwareLog()
{
    local fileName=()
    local finalDestination="${gIOregDir##*/}"
    
    if [ `find "$gIOregDir" -type f -name *BootLog.txt -print 2>/dev/null` ]; then   
        echo "    adding firmware log" >> "${gLogFile}"
        InsertInternalSeparatorHTMLToFile "Firmware Log"
        for file in "$gIOregDir"/*
        do
            fileName+=("${file##*/}")
            if [[ "${fileName}" =~ "BootLog.txt" ]]; then
                if [[ "${fileName}" =~ "Chameleon" ]]; then
                    ReadFileAndWriteCompleteSectionToHtml "$gIOregDir/${fileName}" "Firmware Log: Chameleon" "Dumped using Kabyl's bdmesg Unix binary" "<a href=\"$finalDestination/Chameleon_BootLog.txt\" target=\"_blank\">View Chameleon_BootLog.txt File</a>" "FirmwareLog" "aFirmwareLog" "" "collapseID_FirmLog"
                else # Here I presume it's a Clover log. It could be named with the UEFI BIOS and not 'Clover'.
                    ReadFileAndWriteCompleteSectionToHtml "$gIOregDir/${gTheLoader}${fileName}" "Firmware Log: Clover" "Dumped using: ioreg -lw0 -pIODeviceTree | grep boot-log" "<a href=\"$finalDestination/${gTheLoader}_BootLog.txt\" target=\"_blank\">View ${gTheLoader}_BootLog.txt File</a>" "FirmwareLog" "aFirmwareLog" "" "collapseID_FirmLog"
                fi
                break
            fi
        done
    fi
}

# ---------------------------------------------------------------------------------------
DumpHtmlFirmwareMemoryMap()
{
    local finalDestination="SystemInfo"
    if [ -f "$gSYSinfoDir/FirmwareMemoryMap.txt" ]; then
        echo "    adding firmware memory map" >> "${gLogFile}"
        InsertInternalSeparatorHTMLToFile "Firmware Memory Map"
        ReadFileAndWriteCompleteSectionToHtml "$gSYSinfoDir/FirmwareMemoryMap.txt" "Firmware Memory Map" "Script: FirmwareMemoryMap (formerly showbootermemorymap) by Amit Singh. Revised by bcc9, then by dmazar." "<a href=\"$finalDestination/FirmwareMemoryMap.txt\" target=\"_blank\">View FirmwareMemoryMap.txt File</a>" "FirmwareMemoryMap" "aFirmwareMemoryMap" "" "CollapseID_FirmMemMap"
    fi
}

# ---------------------------------------------------------------------------------------
DumpHtmlIoreg()
{
    local finalDestination="IORegDump"
    if [ -d "$gIOregDir/IORegViewer/Resources/dataFiles" ]; then
        echo "    adding IORegistry Viewer" >> "${gLogFile}"
        
        InsertInternalSeparatorHTMLToFile "I/O Kit Registry"
        
        WriteHtmlAnchorAndSectionOuterToFile "I/O Kit Registry" "aIOREG" "" "collapseID_Ioreg"
        
        # Uncomment these lines to include IOreg dumps in the html file.
        #ReadFileAndWriteSubSectionToHtml "$gIOregDir/IOReg.txt" "I/O Kit Registry - Dumped using OS X's BSD ioreg binary" "<a href=\"$finalDestination/IOReg.txt\" target=\"_blank\">View IOReg.txt File</a>" "IOREG" "" "N"
        #ReadFileAndWriteSubSectionToHtml "$gIOregDir/IORegDT.txt" "I/O Kit Registry - Device Tree - Dumped using OS X's BSD ioreg binary" "<a href=\"$finalDestination/IORegDT.txt\" target=\"_blank\">View IORegDT.txt File</a>" "IOREG_DeviceTree" "" "N"
        
        # These lines add the sub tables and a note that the files are too large.
        WriteHtmlTableHeaderToFile "Dumped using blackosx's amended version of Apple's ioreg command line tool and viewed using <a href=\"http://www.projectosx.com/forum/index.php?showtopic=2549\" target=\"_blank\">IORegistry Web Viewer</a>"

        echo "<div id=\"dialog\" title=\"Inspector\"></div>
  <div id=\"ioregistry_container\">
     <div id=\"ioregistry_header\">
        <div id=\"user_select_drop_down\">
            <form name=\"form\" id=\"form\">
            <label class=\"user_drop_down_choice\">
                <select name=\"plane_select_menu\" onchange=\"RefreshLeftTree(this.form.plane_select_menu)\">
                    <option>IOService</option>
                    <option>IOACPIPlane</option>
                    <option>IODeviceTree</option>
                    <option>IOPower</option>
                    <option>IOUSB</option>
                </select>
            </label>
            </form>
        </div>
        <div class=\"class_info\" id=\"class_placeholder\"></div>
    </div> <!-- End ioregistry_header -->

    <div id=\"leftPaneTreeHeader\">
        <div id=\"ioregistry_user_select_search\">
            <input type=\"text\" id=\"user_search_string\"/>  <button class=\"user_search_button\">Search</button>  <button class=\"user_clear_button\">Clear</button>  
        </div>
    </div> <!-- End leftPaneTreeHeader -->
    
    <div id=\"leftPaneTree\"></div>
    <div id=\"rightPaneTreeHeader\">
      <div id=\"titleProperty\" class=\"titleText\">Property</div><div id=\"titleType\" class=\"titleText\">Type</div><div id=\"titleValue\" class=\"titleText\">Value</div>
    </div> <!-- End rightPaneTreeHeader -->
    <div id=\"rightPaneTree\"></div>

</div> <!-- End ioregistry_container -->" >> "$gHtmlDumpFile"
        
        # Needed to close the section
        WriteHtmlPageNavLinks
        WriteHtmlCloseSectionOuterDivToFile
    fi
}

# ---------------------------------------------------------------------------------------
DumpHtmlKernelBootMessages()
{
    local finalDestination="SystemInfo"
    if [ -f "$gSYSinfoDir/Boot-Messages.txt" ]; then
        echo "    adding boot messages" >> "${gLogFile}"
        InsertInternalSeparatorHTMLToFile "Kernel Boot Messages"
        ReadFileAndWriteCompleteSectionToHtml "$gSYSinfoDir/Boot-Messages.txt" "Kernel Boot Messages" "Dumped using OS X's BSD dmesg binary" "<a href=\"$finalDestination/Boot-Messages.txt\" target=\"_blank\">View Boot-Messages.txt File</a>" "KernelBootMessages" "aKernelBootMessages" "" "collapseID_KernBootMess"
    fi
}

# ---------------------------------------------------------------------------------------
DumpHtmlKernelInfo()
{
    local finalDestination="SystemInfo"
    if [ -f "$gSYSinfoDir/Kernel-Info.txt" ]; then
        echo "    adding kernel info" >> "${gLogFile}"
        InsertInternalSeparatorHTMLToFile "Kernel Info"
        ReadFileAndWriteCompleteSectionToHtml "$gSYSinfoDir/Kernel-Info.txt" "Kernel Info" "Dumped using: uname -v, sysctl -a | grep cpu, sysctl -a | grep hw" "<a href=\"$finalDestination/Kernel-Info.txt\" target=\"_blank\">View Kernel-Info.txt File</a>" "KernelInfo" "aKernelInfo" "" "collapseID_KernInfo"
    fi
}

# ---------------------------------------------------------------------------------------
DumpHtmlKextLists()
{
    local finalDestination="SystemInfo"
    
    # Only run if the text files exist
    if [ -f "$gSYSinfoDir/NonAppleKexts.txt" ] || [ -f "$gSYSinfoDir/AppleKexts.txt" ]; then
        echo "    adding kext dumps" >> "${gLogFile}"
        InsertInternalSeparatorHTMLToFile "Kext Dumps"

        # For ref: Kextstat returns 8 output fields. Index, Refs, Address, Size, Wired, Name, Version, Linked Against   
        declare -a ksIndex
        declare -a ksRefs
        declare -a ksAddress
        declare -a ksSize
        declare -a ksWired
        declare -a ksName
        declare -a ksVer
        declare -a ksLinked

        # ---------------------------------------------------------------------------------------
        WriteHtml()
        {
            local passedAnchor="$1"
            local passedHeading="$2"
            local passedCount="$3"
            local passedSubHeader="$4"
            local passedTableTextHeading="$5"
        
            CalculateTableWidths "KextDump"
            WriteHtmlTableHeaderToFile "$passedHeading : $passedCount"
            WriteHtmlTableSubHeaderToFile "" "Terminal command issued: $passedSubHeader"
            WriteHtmlTableTextHeadingToFile "$passedTableTextHeading"
        }
    
        # ---------------------------------------------------------------------------------------
        readKextInfoInToStrings()
        {
            local fileToRead="$1"
            local kextCount=0
            ksIndex=(); ksRefs=(); ksAddress=(); ksSize=(); ksWired=(); ksName=(); ksVer=(); ksLinked=()
            firstLinked=0
            if [ -f "$fileToRead" ]; then
                oIFS="$IFS"; IFS=$'\n' 
                inFile=( `cat "$fileToRead"` )
                for (( n=0; n<${#inFile[@]}; n++ ))
                do
                    (( kextCount++ ))
                    ksIndex+=(`echo "${inFile[$n]}" | awk '{print $1}'`)
                    ksRefs+=(`echo "${inFile[$n]}" | awk '{print $2}'`)
                    ksAddress+=(`echo "${inFile[$n]}" | awk '{print $3}'`)
                    ksSize+=(`echo "${inFile[$n]}" | awk '{print $4}'`)
                    ksWired+=(`echo "$lin{inFile[$n]}eRead" | awk '{print $5}'`)
                    ksName+=(`echo "${inFile[$n]}" | awk '{print $6}'`)
                    ksVer+=(`echo "${inFile[$n]}" | awk '{print $7}'`)
                    ksLinked+=(`echo "${inFile[$n]}" | awk 'BEGIN { FS = "<" } ; {print $2}'`)
                    if [[ "${inFile[$n]}" =~ "<" ]] && [ $firstLinked -eq 0 ]; then
                        firstLinked=$kextCount
                    fi
                done
                IFS="$oIFS"
            fi
        }
    
        WriteHtmlAnchorAndSectionOuterToFile "Kexts" "aKexts" "" "collapseID_Kexts"
        
        readKextInfoInToStrings "$gSYSinfoDir/NonAppleKexts.txt"
        local totalCount=${#ksIndex[@]}
        WriteHtml "aNonAppleKexts" "Non Apple Kexts" "$totalCount" "kextstat -l | egrep -v \"com.apple\"" "NonAppleKexts"
        for (( n=0; n<$totalCount; n++ ))
        do
            WriteHtmlTableTextToFile "${ksIndex[$n]}" "${ksRefs[$n]}" "${ksAddress[$n]}" "${ksSize[$n]}" "${ksWired[$n]}" "${ksName[$n]}" "${ksVer[$n]}" "<${ksLinked[$n]}"
        done
        WriteHtmlTableTextEndingToFile
        
        readKextInfoInToStrings "$gSYSinfoDir/AppleKexts.txt"
        local totalCount=${#ksIndex[@]}
        # Note: some kexts at beginning of list aren't linked. 
        (( firstLinked-- )) # adjust for zero based array.
        WriteHtml "aAppleKexts" "Apple Kexts" "$totalCount" "kextstat -l | egrep \"com.apple\"" "AppleKexts"
        for (( n=0; n<$firstLinked; n++ )) # print first lines which are not linked
        do
            WriteHtmlTableTextToFile "${ksIndex[$n]}" "${ksRefs[$n]}" "${ksAddress[$n]}" "${ksSize[$n]}" "${ksWired[$n]}" "${ksName[$n]}" "${ksVer[$n]}"
        done
        for (( n=$firstLinked; n<$totalCount; n++ )) # print remaining lines which are linked
        do
            WriteHtmlTableTextToFile "${ksIndex[$n]}" "${ksRefs[$n]}" "${ksAddress[$n]}" "${ksSize[$n]}" "${ksWired[$n]}" "${ksName[$n]}" "${ksVer[$n]}" "<${ksLinked[$n-$firstLinked]}"
        done
        
        WriteHtmlTableTextEndingToFile
        WriteHtmlPageNavLinks
        WriteHtmlCloseSectionOuterDivToFile
    fi
}

# ---------------------------------------------------------------------------------------
DumpHtmlLspci()
{
    local finalDestination="SystemInfo"
    if [ -f "$gSYSinfoDir/lspcitree.txt" ] && [ -f "$gSYSinfoDir/lspci.txt" ]; then
        echo "    adding LSPCI dumps" >> "${gLogFile}"
        InsertInternalSeparatorHTMLToFile "LSPCI"
    	WriteHtmlAnchorAndSectionOuterToFile "LSPCI (PCI vendor & device codes)" "aLSPCI" "" "collapseID_Lspci"
    	ReadFileAndWriteSubSectionToHtml "$gSYSinfoDir/lspcitree.txt" "-nnvvt (Tree) - Dumped using pciutils v3.1.9 by Martin Mares. OS X port by THe KiNG." "<a href=\"$finalDestination/lspcitree.txt\" target=\"_blank\">View lspcitree.txt File</a>" "LSPCI_Tree" "" "lspcitree"
    	echo "</div> <!-- End div section for device id & set state -->" >> "$gHtmlDumpFile"
    	ReadFileAndWriteSubSectionToHtml "$gSYSinfoDir/lspci_map.txt" "-M (Map) - Dumped using pciutils v3.1.9 by Martin Mares. OS X port by THe KiNG." "<a href=\"$finalDestination/lspci_map.txt\" target=\"_blank\">View lspci_map.txt File</a>" "LSPCI_Map" "" "lspci_map"
    	echo "</div> <!-- End div section for device id & set state -->" >> "$gHtmlDumpFile"
    	ReadFileAndWriteSubSectionToHtml "$gSYSinfoDir/lspci.txt" "-nnvv - Dumped using pciutils v3.1.9 by Martin Mares. OS X port by THe KiNG." "<a href=\"$finalDestination/lspci.txt\" target=\"_blank\">View lspci.txt File</a>" "LSPCI" "" "lspci"
    	echo "</div> <!-- End div section for device id & set state -->" >> "$gHtmlDumpFile"
    	ReadFileAndWriteSubSectionToHtml "$gSYSinfoDir/lspci_detailed.txt" "-nnvvbxxxx (Bus centric view - Extended hex dump) - Dumped using pciutils v3.1.9 by Martin Mares. OS X port by THe KiNG." "<a href=\"$finalDestination/lspci_detailed.txt\" target=\"_blank\">View lspci.txt File</a>" "LSPCI_Detailed" "" "lspci_detailed"
    	echo "</div> <!-- End div section for device id & set state -->" >> "$gHtmlDumpFile"
    	
    	# These lines add the sub table and a note that the next file is too large.
        #WriteHtmlTableHeaderToFile "-nnvvbxxxx (PCI vendor & device codes - Bus centric view - Extended hex dump). Dumped using pciutils v3.1.9 by Martin Mares. OS X port by THe KiNG."
        #WriteHtmlTableSubHeaderToFile "" "The dump is very large and deemed not sensible to include here - click the below link to view the file."
        #WriteHtmlTableTextHeadingToFile "LSPCI_detailed"
        #WriteHtmlTableTextToFile "<a href=\"$finalDestination/lspci_detailed.txt\" target=\"_blank\">View lspci_detailed.txt File</a>"
        #WriteHtmlTableTextEndingToFile
        
    	WriteHtmlPageNavLinks
    	WriteHtmlCloseSectionOuterDivToFile
    fi
}

# ---------------------------------------------------------------------------------------
DumpHtmlOpenCL()
{
    local finalDestination="SystemInfo"
    if [ -f "$gSYSinfoDir/openCLinfo.txt" ]; then
        echo "    adding OpenCL dump" >> "${gLogFile}"
        InsertInternalSeparatorHTMLToFile "OpenCL"
        ReadFileAndWriteCompleteSectionToHtml "$gSYSinfoDir/openCLinfo.txt" "OpenCL" "Dumped using opencl by cmf from 2009" "<a href=\"$finalDestination/openCLinfo.txt\" target=\"_blank\">View openCLinfo.txt File</a>" "OpenCL" "aOpenCL" "" "collapseID_OpenCL"
    fi
}

# ---------------------------------------------------------------------------------------
DumpHtmlRtc()
{
    local finalDestination="RTCDump"
    if [ -f "$gRTCDir/RTCDump${rtclength}.txt" ]; then
        echo "    adding RTC dump" >> "${gLogFile}"
        InsertInternalSeparatorHTMLToFile "RTC"
        ReadFileAndWriteCompleteSectionToHtml "$gRTCDir/RTCDump${rtclength}.txt" "RTC" "Dumped using cmosDumperForOsx by rafirafi, revised extensively by STLVNUB" "<a href=\"$finalDestination/RTCDump${rtclength}.txt\" target=\"_blank\">View RTCDump${rtclength}.txt File</a>" "RTC" "aRTC" "" "collapseID_RTC"
    fi
}

# ---------------------------------------------------------------------------------------
DumpHtmlDmiTables()
{
    local warningMessage=()
    local checkMessage=""
    local finalDestination="DMIDump"
       
    warningMessage[0]="Wrong DMI structures"
    warningMessage[1]="DMI table is broken"

    if [ -f "$gSMDir/SMBIOS.txt" ]; then
        echo "    adding SMBIOS dump" >> "${gLogFile}"
        InsertInternalSeparatorHTMLToFile "SMBIOS"
        
        # Check for a couple of warnings
        for (( n=0; n<${#warningMessage[@]}; n++ ))
        do
            checkMessage=`fgrep "${warningMessage[$n]}" "$gSMDir/SMBIOS.txt"`
            if [ ! "$checkMessage" == "" ]; then
                ReadFileAndWriteCompleteSectionToHtml "$gSMDir/SMBIOS.txt" "SMBIOS" "Dumped using smbios-reader & <a href=\"http://www.nongnu.org/dmidecode/\">dmidecode</a> v2.11b. dmidecode <a href=\"http://www.projectosx.com/forum/index.php?showtopic=2208\">compiled for OS X</a> by Slice." "<a href=\"$finalDestination/SMBIOS.txt\" target=\"_blank\">View SMBIOS.txt File</a>" "SMBIOS" "aSMBIOS" "Warning: $checkMessage" "collapseID_SMBIOS"
                break
            fi
        done
        
        if [ "$checkMessage" == "" ]; then
            ReadFileAndWriteCompleteSectionToHtml "$gSMDir/SMBIOS.txt" "SMBIOS" "Dumped using smbios-reader & <a href=\"http://www.nongnu.org/dmidecode/\">dmidecode</a> v2.11b. dmidecode <a href=\"http://www.projectosx.com/forum/index.php?showtopic=2208\">compiled for OS X</a> by Slice." "<a href=\"$finalDestination/SMBIOS.txt\" target=\"_blank\">View SMBIOS.txt File</a>" "SMBIOS" "aSMBIOS" "" "collapseID_SMBIOS"
        fi
    fi
}

# ---------------------------------------------------------------------------------------
DumpHtmlSmcKeys()
{
    local finalDestination="SMCDump"
    if [ -f "$gSMCDir/SMC-keys.txt" ] && [ -f "$gSMCDir/SMC-fans.txt" ]; then
        echo "    adding SMC dumps" >> "${gLogFile}"
        InsertInternalSeparatorHTMLToFile "SMC"
        WriteHtmlAnchorAndSectionOuterToFile "SMC" "aSMC" "" "collapseID_SMC"
        ReadFileAndWriteSubSectionToHtml "$gSMCDir/SMC-keys.txt" "SMC Keys. Dumped using SMC_util2 (Former Apple System Management Control (SMC) tool 0.01) by usr-sse2." "<a href=\"$finalDestination/SMC-keys.txt\" target=\"_blank\">View SMC-keys.txt File</a>" "SMCKeys" "" "N"
        ReadFileAndWriteSubSectionToHtml "$gSMCDir/SMC-fans.txt" "SMC Fans. Dumped using SMC_util2 (Former Apple System Management Control (SMC) tool 0.01) by usr-sse2." "<a href=\"$finalDestination/SMC-fans.txt\" target=\"_blank\">View SMC-fans.txt File</a>" "SMCFans" "" "N"
        WriteHtmlPageNavLinks
        WriteHtmlCloseSectionOuterDivToFile
    fi
}

# ---------------------------------------------------------------------------------------
DumpHtmlSytemProfiler()
{
    local finalDestination="SystemInfo"
    if [ -f "$gSYSinfoDir/System-Profiler.txt" ]; then
        echo "    adding System Profiler dump" >> "${gLogFile}"
        InsertInternalSeparatorHTMLToFile "System Profiler"
        ReadFileAndWriteCompleteSectionToHtml "$gSYSinfoDir/System-Profiler.txt" "System Profiler" "Dumped using /usr/sbin/system_profiler -detailLevel mini" "<a href=\"$finalDestination/System-Profiler.txt\" target=\"_blank\">View System-Profiler.txt File</a>" "SystemProfiler" "aSystemProfiler" "" "collapseID_SysProf"
    fi
}

# ---------------------------------------------------------------------------------------
DumpHtmlMisc()
{
    local scriptExists=0
    local finalDestination="Misc"
    
    if [ -d "$gScriptDir" ]; then
        scriptExists=1
    fi
    if [ -f "$gMiscDir/gEfiAppleNvramGuid_Vars.txt" ] || [ $scriptExists -eq 1 ]; then
        echo "    adding Misc" >> "${gLogFile}"
        InsertInternalSeparatorHTMLToFile "Misc"
        WriteHtmlAnchorAndSectionOuterToFile "Misc" "aMisc" "" "collapseID_Misc"
        if [ -f "$gMiscDir/gEfiAppleNvramGuid_Vars.txt" ]; then
          ReadFileAndWriteSubSectionToHtml "$gMiscDir/gEfiAppleNvramGuid_Vars.txt" "EfiAppleNvramGuid Vars" "<a href=\"$finalDestination/gEfiAppleNvramGuid_Vars.txt\" target=\"_blank\">View gEfiAppleNvramGuid_Vars.txt File</a>" "gEfiAppleNvramGuidVars" "" "N"
        fi
        if [ -f "$gScriptDir/rc.local" ]; then
          ReadFileAndWriteSubSectionToHtml "$gScriptDir/rc.local" "Startup script: /etc/rc.local" "" "rcLocal" "" "N"
        fi
        if [ -f "$gScriptDir/rc.shutdown.local" ]; then
          ReadFileAndWriteSubSectionToHtml "$gScriptDir/rc.shutdown.local" "Shutdown script: /etc/rc.local.shutdown" "" "rcShutdownLocal" "" "N"
        fi
        WriteHtmlPageNavLinks
        WriteHtmlCloseSectionOuterDivToFile
    fi
}

# ---------------------------------------------------------------------------------------
DumpHtmlNvram()
{
    local finalDestination="SystemInfo"
    if [ -f "$gSYSinfoDir/nvram.plist" ]; then
        echo "    adding nvram.plist" >> "${gLogFile}"
        InsertInternalSeparatorHTMLToFile "NVRAM"
        ReadFileAndWriteCompleteSectionToHtml "$gSYSinfoDir/nvram.plist" "NVRAM" "Dumped using nvram -x -p" "<a href=\"$finalDestination/nvram.plist\" target=\"_blank\">View nvram.plist File</a>" "NVRAM" "aNVRAM" "" "collapseID_NVRAM"
    fi
}

# ---------------------------------------------------------------------------------------
DumpHtmlEdid()
{
    local finalDestination="EDIDDump"
    
    # Find how many files there are to read
    local checkNumFiles=`find "$gEDIDDir" -type f -name *.txt -print 2>/dev/null | wc -l | tr -d ' '`
    if [ $checkNumFiles -gt 1 ]; then
        InsertInternalSeparatorHTMLToFile "EDID"
        WriteHtmlAnchorAndSectionOuterToFile "EDID" "aEDID" "" "collapseID_Edid"
        for file in "$gEDIDDir"/*.txt
        do
            local edidFileName="${file##*/}"
            echo "    adding $edidFileName" >> "${gLogFile}"
            local edidFileNameExtensionRemoved="${edidFileName%.txt*}"
            ReadFileAndWriteSubSectionToHtml "$gEDIDDir/${edidFileName}" "${edidFileNameExtensionRemoved} - Dumped IODisplayEDID from ioreg and decoded using <a href=\"http://cgit.freedesktop.org/xorg/app/edid-decode/\" target=\"_blank\">edid-decode</a>  by Adam Jackson." "<a href=\"$finalDestination/${edidFileName}\" target=\"_blank\">View ${edidFileName} File</a>" "${edidFileName}" "" "collapseID_${edidFileNameExtensionRemoved}"
            echo "</div> <!-- End div section for device id & set state -->" >> "$gHtmlDumpFile"
        done
        WriteHtmlPageNavLinks
    	WriteHtmlCloseSectionOuterDivToFile
    else
        # Only one file to read
        if [ -f "$gEDIDDir/EDID.txt" ]; then
            echo "    adding EDID" >> "${gLogFile}"
            InsertInternalSeparatorHTMLToFile "EDID"
            ReadFileAndWriteCompleteSectionToHtml "$gEDIDDir/EDID.txt" "EDID" "Dumped IODisplayEDID from ioreg and decoded using <a href=\"http://cgit.freedesktop.org/xorg/app/edid-decode/\">edid-decode</a> by Adam Jackson." "<a href=\"$finalDestination/EDID.txt\" target=\"_blank\">View EDID.txt File</a>" "EDID" "aEDID" "" "collapseID_EDID"
        fi
    fi
}

#
# =======================================================================================
# MAIN
# =======================================================================================
#


#CheckRoot
Initialise "$1" "$2" "$3" "$4" "$5" "$6"
CreateAndInitialiseHtmlFile
DumpHtmlAcpiTables
DumpHtmlAudio
DumpHtmlBootloaderConfigs
DumpHtmlDeviceProperties
DumpHtmlDiskPartitionTableInfo
DumpHtmlDiskutilAndLoader
DumpHtmlDiskUUIDs
DumpHtmlEdid
DumpHtmlFirmwareLog
DumpHtmlFirmwareMemoryMap
DumpHtmlIoreg
DumpHtmlKernelBootMessages
DumpHtmlKernelInfo
DumpHtmlKextLists
DumpHtmlLspci
DumpHtmlMisc
DumpHtmlNvram
DumpHtmlOpenCL
DumpHtmlRtc
DumpHtmlDmiTables
DumpHtmlSmcKeys
DumpHtmlSytemProfiler
CloseCssFile
CloseHtmlFile
CombineCssAndHtmlFiles
