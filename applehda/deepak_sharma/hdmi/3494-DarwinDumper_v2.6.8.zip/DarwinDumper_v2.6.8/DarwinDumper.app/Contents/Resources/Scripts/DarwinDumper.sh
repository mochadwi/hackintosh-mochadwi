#!/bin/sh

# This is a revised version of DarwinDumper.sh
# Originally by Trauma on 12/08/09.
# Copyright 2010 org.darwinx86.app. All rights reserved.
# Many thanks to JrCs, sonotone, phcoder.
# Additions and revisions since by STLVNUB and blackosx.
#
# Re-structured and further developed by blackosx 02/07/12 -> 08/03/13.
# Incorporating original DarwinDumper ideas and code.
#
# Thanks to Slice, dmazar, STLVNUB, !Xabbu, THe KiNG, Trauma, JrCs & Kynnder. 
# for providing testing/feedback, additional tools, suggestions and help.
#

#set -x
#set -u

# =======================================================================================
# INITIALISATION & NON-SPECIFIC ROUTINES
# =======================================================================================

# ---------------------------------------------------------------------------------------
InitialiseBeforeUI()
{   
    VERS="2.6.8"
    local cdir="$( cd -P "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
    cd "$cdir"; cd ..; cd ..
    local resourcesDir="$( pwd )"/Resources
    if [ -d "$resourcesDir" ]; then
        local dumpDirs=""
        local theprogdir=`pwd`
        local gRefitVers=""
        local dataDir="$resourcesDir"/Data
        local driversDir="$resourcesDir"/Drivers
        local imagesDir="$resourcesDir"/Images
        local toolsDir="$resourcesDir"/Tools
        local scriptsDir="$resourcesDir"/Scripts
        
        # Global Vars
        ioregViewerDir="$resourcesDir"/IOregViewer
        gTheLoader=""
        gtheprog="DarwinDumper"
        gtheVersion="$VERS"
        gScriptRunTime=0
        gLoadedVoodooHda=0
        gRootPriv=0
        gUserPrefsFileName="org.tom.DarwinDumper.plist"
        gUserPrefsFile="$HOME/Library/Preferences/$gUserPrefsFileName"
        gAppReportsFolder="DarwinDumperReports"
        gMyFolder="$dataDir/$gAppReportsFolder"

        # Global vars for holding which dumps are wanted.
        gCheckBox_acpi=0
        gCheckBox_codecid=0
        gCheckBox_bios=0
        gCheckBox_devprop=0
        gCheckBox_diskLoaderConfigs=0
        gCheckBox_diskUtilLoaders=0
        gCheckBox_diskVolumeXuid=0
        gCheckBox_diskPartitionInfo=0
        gCheckBox_edid=0
        gCheckBox_firmlog=0
        gCheckBox_firmmemmap=0
        gCheckBox_ioreg=0
        gCheckBox_kerneldmesg=0
        gCheckBox_kernelinfo=0
        gCheckBox_kexts=0
        gCheckBox_lspci=0
        gCheckBox_opencl=0
        gCheckBox_rtc=0
        gCheckBox_dmi=0
        gCheckBox_smc=0
        gCheckBox_sysprof=0
        gCheckBox_misc=0
        gCheckBox_nvram=0
        gCheckBox_enablehtml=0
        gCheckBox_collapsetables=0
        gButton_cancel=0
        gButton_runAll=0
        gButton_runSelected=0
        gRadio_privacy=""
        gNoShow=0

        # Resources - Data
        pciids="$dataDir/pci.ids.gz"
        
        # Resources - Drivers
        pciutildrv="$driversDir/DirectHW.kext"
        pciutildrvLeo="$driversDir/Leo/DirectHW.kext"
        voodoohda="$driversDir/VoodooHDA.kext"
        voodoohdaPreML="$driversDir/PreML/VoodooHDA.kext"
        
        # Resources - Scripts
        gatherDiskUtilLoaderinfo="$scriptsDir/gatherDiskUtilLoaderinfo.sh"
        generateHTMLreport="$scriptsDir/generateHTMLreport.sh"
        processIoregDumps="$scriptsDir/processIoregDumps.sh"
        makePrivate="$scriptsDir/privacy.pl"
        
        # Resources - Tools
        bdmesg="$toolsDir/bdmesg"
        smbiosreader="$toolsDir/smbios-reader"
        dmidecode="$toolsDir/dmidecode"
        gfxutil="$toolsDir/gfxutil"
        iasl="$toolsDir/iasl"
        smcutil="$toolsDir/SMC_util3"
        lspci="$toolsDir/lspci"
        sbmm="$toolsDir/FirmwareMemoryMap"
        rtcdumper="$toolsDir/cmosDumperForOsx"
        flashrom="$toolsDir/flashrom"
        lzma="$toolsDir/lzma"
        oclinfo="$toolsDir/oclinfo"
        ediddecode="$toolsDir/edid-decode"
        ioregwv="$toolsDir/ioregwv"
        getcodecid="$toolsDir/getcodecid"
        getdump="$toolsDir/getdump"
          
        # UI
        macgap="$resourcesDir/MacGap.app/Contents/MacOS/MacGap"
    else
        echo "DEBUG: DarwinDumper quit because it couldn't find the Resources folder." >> "${gLogFile}"
        exit 1
    fi
}

# ---------------------------------------------------------------------------------------
InitialiseAfterUI()
{
    local rootSystem=$(CheckOsVersion)
    local theBoss=`id -unr`
    
    # Navigate to app containing folder.
    cd ..; cd ..; 
    gDumpDir="$( pwd )"

    # Make sure we have a Reports folder
    if [ ! -d "$gDumpDir"/"$gAppReportsFolder" ]; then
        echo "Copying empty DarwinDumperReports folder with icon to $gDumpDir"
        cp -R "$gMyFolder" "$gDumpDir"
    fi

    # find sequence number from latest directory in the Reports folder.
    local latestDumpDirName=`ls -d "${gDumpDir}/${gAppReportsFolder}"/[0-9][0-9][0-9]* 2>/dev/null | tail -n 1`
    if [ -z "$latestDumpDirName" ] || [ "$latestDumpDirName" == "" ]; then
        local lastSequenceNumber="000"
    else
        # Strip all before last forward slash
        lastSequenceNumber="${latestDumpDirName##*/}"
        # Remove all after and including first underscore
        lastSequenceNumber="${lastSequenceNumber%%_*}"
        # Remove any preceding zeros by converting to an actual number
        lastSequenceNumber="$[10#${lastSequenceNumber}]"
        # If user has 999 dumps, then reset to 0 (can't see this ever happening).
        if [ $lastSequenceNumber -eq 999 ]; then
            lastSequenceNumber="000"
        else
            # increment sequence number
            ((lastSequenceNumber++)) 
        fi
    fi
    #Pad as a string length of 3. For example: 006
    lastSequenceNumber=$( printf %03d $lastSequenceNumber )
    
    # Find Mac Model to add to the folder name.
    local macModel=`/usr/sbin/system_profiler SPHardwareDataType | grep "Model Identifier:"`
    macModel="${macModel##*: }"
    
    # Create indexed, time stamped folder to hold this dump.
    local timeStamp=`date "+%F_%H-%M-%S"`
    gThisIndexedDumpFolder="${gDumpDir}/${gAppReportsFolder}/${lastSequenceNumber}_${timeStamp}_${macModel}" 
    mkdir "${gThisIndexedDumpFolder}"

    # Discover current architecture
    local efi=`ioreg -l -p IODeviceTree | grep firmware-abi | awk '{print $5}'`
    local efiBITS="${efi:5:2}"
    if [ "${efiBITS}" == "32" ]; then
    	efiBITS="IA32"
    elif [ "${efiBITS}" == "64" ]; then
       	efiBITS="X64"
    else
    	efiBITS="WhoKnows"   	
    fi
    
    # Discover current bootloader and associated version.
    gTheLoader=$(ioreg -l -pIODeviceTree | grep firmware-vendor | awk '{print $5}' | sed 's/_/ /g' | tr -d "<\">" | xxd -r -p)
    case "$gTheLoader" in
            "CLOVER")              gRefitVers=$(ioreg -lw0 -pIODeviceTree | grep boot-log | tr -d "    |       "boot-log" = <\">" | LANG=C sed -e 's/.*72454649742072657620//' -e 's/206f6e20.*//' | xxd -r -p | sed 's/:/ /g' )
	                               gTheLoader="Clover_${efiBITS}_${gRefitVers}" ;;
            "American Megatrends") gRefitVers=$(ioreg -lw0 -pIODeviceTree | grep boot-log | tr -d "    |       "boot-log" = <\">" | LANG=C sed -e 's/.*72454649742072657620//' -e 's/206f6e20.*//' | xxd -r -p | sed 's/:/ /g' )
	                               gTheLoader="AMI_${efiBITS}_${gRefitVers}" ;;
            "")                    gTheLoader="Unknown_${efiBITS}" ;;
            "Apple")               gTheLoader="${gTheLoader}_${efiBITS}" ;;
	esac
    gTheLoader=`echo "${gTheLoader}" | tr ' ' '_' ` # check for spaces in firmware name, now global variable
    	
    # Create dump folder name.
    gFolderName="${gtheprog}_${gtheVersion}_${gTheLoader}_${rootSystem}_${theBoss}"
        
    # SetMasterDumpFolder
    gMasterDumpFolder="${gThisIndexedDumpFolder}/${gFolderName}"
        
    gTMPDir=/tmp
    gSMDir="$gMasterDumpFolder"/DMIDump
    gDEVDir="$gMasterDumpFolder"/DevPropsDump
    gACPIDir="$gMasterDumpFolder"/ACPIDump
    gAMLDir="$gACPIDir"/AML
    gDSLDir="$gACPIDir"/DSL
    gMiscDir="$gMasterDumpFolder"/Misc
    gScriptDir="$gMiscDir"/Scripts
    gSMCDir="$gMasterDumpFolder"/SMCDump
    gSYSinfoDir="$gMasterDumpFolder"/SystemInfo
    gIOregDir="$gMasterDumpFolder"/IORegDump
    gBootSectDir="$gMasterDumpFolder"/BootSectDump
    gBootConfigDir="$gMasterDumpFolder"/BootloaderConfigFiles
    gRTCDir="$gMasterDumpFolder"/RTCDump
    gBiosROMDir="$gMasterDumpFolder"/BiosROMDump
    gEDIDDir="$gMasterDumpFolder"/EDIDDump
    gLogFile="$gMasterDumpFolder"/DarwinDumper_log.txt

    # Create / Clean temp directory
    if [ -d "$gTMPDir"/DirectHW.kext ];then
       rm -Rf "$gTMPDir"/DirectHW.kext
    fi
}

# ---------------------------------------------------------------------------------------
getFeedbackFromUI()
{        
    # Wait until temporary file exists and is greater than zero in size.
    while [ ! -s "/tmp/dd_ui_return" ];
    do
        sleep 1
    done
    
    # Read the temp file then remove it.
    oIFS="$IFS"; IFS=$','
    uiReturnArray=( $(cat /tmp/dd_ui_return) )
    IFS="$oIFS"

    # If the user did not cancel the UI then remove all keys
    # from prefs file as we will re-write with latest options.
    if [[ ! "${uiReturnArray[@]}" = *user_quit* ]]; then
        if [ -f "$gUserPrefsFile" ]; then
            defaults delete "$gUserPrefsFile"
        fi
    fi
        
    # Loop through each option
    for (( x=0; x<${#uiReturnArray[@]}; x++ ))
    do
        # Remove unwanted characters and parse results.
        case "${uiReturnArray[$x]##*:}" in
                    "enablehtml")        gCheckBox_enablehtml=1
                                         defaults write "$gUserPrefsFile" enablehtml True
                                         ;;
                    "collapsetables")    gCheckBox_collapsetables=1
                                         defaults write "$gUserPrefsFile" collapsetables True
                                         ;;
                    "privacy")           gRadio_privacy="Private"
                                         defaults write "$gUserPrefsFile" privacy True
                                         ;;
                    "ArchiveZip")        gRadio_archiveType="Archive.zip"
                                         defaults write "$gUserPrefsFile" ArchiveZip True
                                         ;;
                    "ArchiveLzma")       gRadio_archiveType="Archive.lzma"
                                         defaults write "$gUserPrefsFile" ArchiveLzma True
                                         ;;
                    "ArchiveNone")       gRadio_archiveType="Archive_None"
                                         defaults write "$gUserPrefsFile" ArchiveNone True
                                         ;;
                    "acpi")              gCheckBox_acpi=1
                                         defaults write "$gUserPrefsFile" acpi True
                                         ;;
                    "codecid")           gCheckBox_codecid=1
                                         defaults write "$gUserPrefsFile" codecid True
                                         ;;
                    "bios")              gCheckBox_bios=1
                                         defaults write "$gUserPrefsFile" bios True
                                         ;;
                    "devprop")           gCheckBox_devprop=1
                                         defaults write "$gUserPrefsFile" devprop True
                                         ;;
                    "diskLoaderConfigs") gCheckBox_diskLoaderConfigs=1
                                         defaults write "$gUserPrefsFile" diskLoaderConfigs True
                                         ;;
                    "diskUtilLoaders")   gCheckBox_diskUtilLoaders=1
                                         defaults write "$gUserPrefsFile" diskUtilLoaders True
                                         ;;
                    "diskVolumeXuid")    gCheckBox_diskVolumeXuid=1
                                         defaults write "$gUserPrefsFile" diskVolumeXuid True
                                         ;;
                    "diskPartitionInfo") gCheckBox_diskPartitionInfo=1
                                         defaults write "$gUserPrefsFile" diskPartitionInfo True
                                         ;;
                    "dmi")               gCheckBox_dmi=1
                                         defaults write "$gUserPrefsFile" dmi True
                                         ;;
                    "edid")              gCheckBox_edid=1
                                         defaults write "$gUserPrefsFile" edid True
                                         ;;
                    "firmlog")           gCheckBox_firmlog=1
                                         defaults write "$gUserPrefsFile" firmlog True
                                         ;;
                    "firmmemmap")        gCheckBox_firmmemmap=1
                                         defaults write "$gUserPrefsFile" firmmemmap True
                                         ;;
                    "ioreg")             gCheckBox_ioreg=1
                                         defaults write "$gUserPrefsFile" ioreg True
                                         ;;
                    "kerneldmesg")       gCheckBox_kerneldmesg=1
                                         defaults write "$gUserPrefsFile" kerneldmesg True
                                         ;;
                    "kernelinfo")        gCheckBox_kernelinfo=1
                                         defaults write "$gUserPrefsFile" kernelinfo True
                                         ;;
                    "kexts")             gCheckBox_kexts=1
                                         defaults write "$gUserPrefsFile" kexts True
                                         ;;
                    "lspci")             gCheckBox_lspci=1
                                         defaults write "$gUserPrefsFile" lspci True
                                         ;;
                    "misc")              gCheckBox_misc=1
                                         defaults write "$gUserPrefsFile" misc True
                                         ;;
                    "nvram")             gCheckBox_nvram=1
                                         defaults write "$gUserPrefsFile" nvram True
                                         ;;
                    "opencl")            gCheckBox_opencl=1
                                         defaults write "$gUserPrefsFile" opencl True
                                         ;;
                    "rtc")               gCheckBox_rtc=1
                                         defaults write "$gUserPrefsFile" rtc True
                                         ;;
                    "smc")               gCheckBox_smc=1
                                         defaults write "$gUserPrefsFile" smc True
                                         ;;
                    "sysprof")           gCheckBox_sysprof=1
                                         defaults write "$gUserPrefsFile" sysprof True
                                         ;;
                    "noshow")            gNoShow=1
                                         defaults write "$gUserPrefsFile" noshow True
                                         ;;
                    "user_quit")         gButton_cancel=1 # user quit
                                         ;;
                    "death")             exit 1 # UI has completed and closed
                                         ;; 
        esac
    done
    
    # Set the ownership & permissions so it's readable.
    # This covers the case where creating the file as root.
    if [ -f "$gUserPrefsFile" ]; then
        chmod 755 "$gUserPrefsFile"
        chown 501:20 "$gUserPrefsFile"
    fi
}

# ---------------------------------------------------------------------------------------
CreateDumpDirs()
{
    local dirToMake="$1"

    for dumpDirs in $dirToMake;
    do
        if [ ! -d "${dumpDirs}" ]; then
    	    mkdir "${dumpDirs}"
    	fi
    done
}

# ---------------------------------------------------------------------------------------
CheckOsVersion()
{
    local osVer=`uname -r`
    local osVer=${osVer%%.*}
    local rootSystem=""
    
    if [ "$osVer" == "8" ]; then
	    rootSystem="Tiger"
    elif [ "$osVer" == "9" ]; then
	    rootSystem="LEO"
    elif [ "$osVer" == "10" ]; then
	    rootSystem="SL"
    elif [ "$osVer" == "11" ]; then
	    rootSystem="Lion"
    elif [ "$osVer" == "12" ]; then
	    rootSystem="ML"
	else 
	    rootSystem="Unknown"
    fi
    echo "$rootSystem"  # This line acts as a return to the caller.
}

# ---------------------------------------------------------------------------------------
LoadPciUtilsDriver()
{
    local isLoaded=""
    checkArch=$( uname -a )
    if [[ "$checkArch" == *_64* ]]; then
        cp -r "$pciutildrv" "$gTMPDir"
        local driverName="${pciutildrv##*/}"
    else
        cp -r "$pciutildrvLeo" "$gTMPDir"
        local driverName="${pciutildrvLeo##*/}"
    fi
        
    chmod -R 755 "$gTMPDir/$driverName"
    chown -R 0:0 "$gTMPDir/$driverName"
    isLoaded=$( kextstat -l | egrep "$driverName" )
    if [ "$isLoaded" == "" ]; then
        /sbin/kextload "$gTMPDir/$driverName"
    fi
    echo "$driverName"  # This line acts as a return to the caller.
}

# ---------------------------------------------------------------------------------------
UnloadPciUtilsDriver()
{
    local isLoaded=""
    checkArch=$( uname -a )
    if [[ "$checkArch" == *_64* ]]; then
        local driverName="${pciutildrv##*/}"
    else
        local driverName="${pciutildrvLeo##*/}"
    fi
    isLoaded=$( kextstat -l | egrep "${driverName%*.kext}" )
        if [ ! "$isLoaded" == "" ]; then
        echo "Unloading $driverName"
        /sbin/kextunload "$gTMPDir/$driverName"
    fi
    if [ -d "$gTMPDir/$driverName" ]; then
        rm -r "$gTMPDir/$driverName"
    fi
}

# ---------------------------------------------------------------------------------------
LoadVoodooHdaDriver()
{
    local checkSystemVersion=""
    
    checkSystemVersion=$(CheckOsVersion)
    if [ "$checkSystemVersion" == "ML" ]; then
        cp -R "$voodoohda" "$gTMPDir" # This is one version of VoodooHDA.kext
    else
        cp -R "$voodoohdaPreML" "$gTMPDir" # This is a different version of VoodooHDA.kext
    fi
    chmod -R 755 "$gTMPDir/VoodooHDA.kext"
    chown -R 0:0 "$gTMPDir/VoodooHDA.kext"
    
    # Check to see if VoodooHDA is already loaded on the users system
    local isLoaded=$( kextstat -l | egrep "VoodooHDA" )
    if [ "$isLoaded" == "" ]; then
        # It's not currently loaded, so try to load it.
        echo "       Loading VoodooHDA.kext" >> "${gLogFile}"
        /sbin/kextload "$gTMPDir/VoodooHDA.kext"
        gLoadedVoodooHda=1 # make a note we loaded it.
    else
        # It's already loaded, so don't load it again.
        if [ -d "$gTMPDir/VoodooHDA.kext" ]; then
            rm -r "$gTMPDir/VoodooHDA.kext"
        fi
    fi
}

# ---------------------------------------------------------------------------------------
UnloadVoodooHdaDriver()
{
    if [ $gLoadedVoodooHda -eq 1 ]; then
        # Only unload if we loaded it.
        
        # Check to see if VoodooHDA is already loaded on the users system
        local isLoaded=$( kextstat -l | egrep "VoodooHDA" )
        if [ ! "$isLoaded" == "" ]; then
            # Yes, it's loaded
            echo "       Unloading VoodooHDA.kext" >> "${gLogFile}"
            /sbin/kextunload "$gTMPDir/VoodooHDA.kext"
        fi
    fi
    # Remove the kext from the temporary location.
    if [ -d "$gTMPDir/VoodooHDA.kext" ]; then
        rm -r "$gTMPDir/VoodooHDA.kext"
    fi
}

# ---------------------------------------------------------------------------------------
CheckRoot()
{
    if [ "`whoami`" != "root" ]; then
        #echo "Running this requires you to be root."
        #sudo "$0"
        gRootPriv=0
    else
        gRootPriv=1
    fi
}

# ---------------------------------------------------------------------------------------
CheckSuccess()
{
    local passedPathAndFile="$1"
    if [ ! -f "${passedPathAndFile}" ]; then
         echo "       Error: ${passedPathAndFile} failed to be created." >> "${gLogFile}"
    fi
}

# ---------------------------------------------------------------------------------------
Privatise()
{   
    # ---------------------------------------------------------------------------------------
    CreateMask()
    {
        # This takes a string and creates a masked string by
        # replacing the centre 80% of characters with a *
        # for ACSII strings or 2A for hex strings.
        # The masked string is returned.
        
        local origStr="$1"
        local stringType="$2"
        local maskElement="*"
        if [[ -n "$origStr" ]];then
            tmp=$(( ${#origStr} * 10 )) # Keep 20% of chars
                                        # (so 10% at start and 10% at end)
            tmp=${tmp:0:$(( ${#tmp} - 2)) } # Convert to integer
            [[ -z "$tmp" ]] && tmp=1 # Keep at least 1 char at start and end
            nbToMask=$(( ${#origStr} - ( 2 * $tmp ) ))
            if [ "$stringType" == "Hex" ]; then
                nbToMask=$(( $nbToMask / 2 ))
                maskElement="2A"
            fi
            if [[ $nbToMask -gt 0 ]]; then
                mask=$(printf "${maskElement}"'%.0s' $( seq -s ' ' 1 $nbToMask ) )
            else
                mask=""
            fi
            echo ${origStr:0:$tmp}${mask}${origStr: -$tmp}
            #echo ${mask}${origStr: -( 2 * $tmp ) } # Mask from front, leaving end as original.
        fi
    }
    
    # ---------------------------------------------------------------------------------------
    CreateFindReplaceString()
    {
        # This takes a string array of original values.
        # Each value then has an associated mask created.
        # A sed find and replace string is created and returned.
        
        local passedValues=( "$@" )
        for (( n=0; n < ${#passedValues[@]}; n++ ))
        do
            passedValuesMask+=( $(CreateMask "${passedValues[$n]}") )
            passedValuesSearchReplaceString="${passedValuesSearchReplaceString}s/${passedValues[$n]}/${passedValuesMask[$n]}/g;"
        done
        echo "$passedValuesSearchReplaceString"
    }
    
    # ---------------------------------------------------------------------------------------
    GetValue()
    {
        # This takes a search item, for example "IOPlatformSerialNumber" and returns
        # a string array with all matching values found within ioreg.
        # It works for items with single or multiple appearances, for example "IOMACAddress".
        
        local keyToGet="$1"
        local planeToUse="$2"
        local keyValueRead=""
        local keyValue=""
        
        if [[ -n "$keyToGet" ]]; then
            # Read key from system as user might not have dumped ioreg to file.
            if [ ! "$keyToGet" == "SystemSerialNumber" ] && [ ! "$planeToUse" == "IODeviceTree" ]; then
                keyValueRead=( $(ioreg -lw0 -p "$planeToUse" | grep "$keyToGet" | tr -d '"' | tr -d '<>' ) )
            else
                # Don't remove the quote marks.
                keyValueRead=( $(ioreg -lw0 -p "$planeToUse" | grep "$keyToGet" | tr -d '<>' ) )    
            fi
            keyValueNumCheck=$(( ${#keyValueRead[@]} -1 ))
            grabNext=0
            for (( n=0; n < ${#keyValueRead[@]}; n++ ))
            do
                if [[ -n "${keyValueRead[$n]}" ]] && [ ! "${keyValueRead[$n]}" == "$keyToGet" ]; then
                    if [ $grabNext -eq 1 ]; then
                        keyValue+=( "${keyValueRead[$n]}" )
                        grabNext=0
                    fi
                    if [ "${keyValueRead[$n]}" == "=" ]; then # Next element will be data we want
                        grabNext=1
                    fi
                fi
            done
            echo "${keyValue[@]}"
        fi
    }
    
    # ---------------------------------------------------------------------------------------
    Cleanup()
    {
        local fileToRemove="$1"
        if [ -f "$fileToRemove"e ]; then
            rm "$fileToRemove"e
        fi
    }
    
    # ---------------------------------------------------------------------------------------
    ApplyMask()
    {
        local origStr="$1"
        local maskedStr="$2"
        local targetFile="$3"
        if [ "$maskedStr" == "" ]; then # Used for pre-constructed search/replace string.
            LANG=C sed -ie "${origStr}" "$targetFile"
        else
            LANG=C sed -ie "s/${origStr}/${maskedStr}/g" "$targetFile"
        fi
        Cleanup "$targetFile"
    }
    
    # ---------------------------------------------------------------------------------------
    PatchFullIoregDump()
    {
        local searchString="$1"
        local replacementString="$2"
        
        # Check Full IOReg Dump
        if [ -d "$gIOregDir"/IORegViewer ]; then
            local dirToCheck="$gIOregDir"/IORegViewer/Resources/dataFiles
            if [ -d "$dirToCheck" ]; then
        
                # Loop through each sub directory
                local subDirs=($( ls "$dirToCheck" ))
                for (( n=0; n < ${#subDirs[@]}; n++ ))
                do
                    local filesToPatch=()
                    cd "$dirToCheck/${subDirs[$n]}"
                    
                    # Build array of all files to patch for this item.
                    filesToPatch=(`grep -l "$searchString" * `)
                
                    # Loop through array and patch each file.
                    for (( m=0; m < ${#filesToPatch[@]}; m++ ))
                    do
                        if [ "${filesToPatch[$m]}" ]; then
                            ApplyMask "$replacementString" "" "$dirToCheck"/"${subDirs[$n]}"/"${filesToPatch[$m]}"
                        fi
                    done
                    cd ..
                done
            fi
        fi
    }
    
    # ---------------------------------------------------------------------------------------
    maskBootloaderConfigData()
    {
        local passedFileName="$1"
        local passedValueToFind="$2"
        local tmpValue=""
        declare -a tmpFileArray

        local oIFS="$IFS"; IFS=$'\n'
        tmpFileArray=( $(find "$gBootConfigDir" -type f -name "$passedFileName") )
        IFS="$oIFS"
        for (( p=0; p<${#tmpFileArray[@]}; p++ ))
        do
            # Search command/idea taken from Jadran's parse script - Thanks Jadran.
            # Search for data and read the next line which is assumed to the value, then remove trailing </string>
            local tmpValue=$( grep -A 1 "<key>${passedValueToFind}</key>" "${tmpFileArray[$p]}" | sed 1d | sed -e 's/<\/string>//g')
            
            # only mask if not already masked (or contains 2 consecutive asterisks)
            if [[ ! "$tmpValue" == *\*\** ]]; then
            
                # Remove opening <string>
                tmpValue=${tmpValue#*<string>}
                # Remove any trailing whitespace characters
                tmpValue="${tmpValue%"${tmpValue##*[![:space:]]}"}"
                if [ ! $tmpValue == "" ]; then
                    local tmpValueSearchReplace=$(CreateFindReplaceString "${tmpValue}") 
                    ApplyMask "$tmpValueSearchReplace" "" "${tmpFileArray[$p]}"
                fi
            fi
        done
    }
    
    echo "$(($(date +%s)-gScriptRunTime))s : Making dump(s) private.." >> "${gLogFile}"
    echo "S:privacy" >> /tmp/dd_completed
    
    local targetIOreg="$gIOregDir/IOReg.txt"
    local targetIOregDT="$gIOregDir/IORegDT.txt"
    local targetSMBIOS="$gSMDir/SMBIOS.txt"
    local targetSMBIOSbin="$gSMDir/SMBIOS.bin"
    local targetSysProfTxt="$gSYSinfoDir/System-Profiler.txt"
    local targetSysProfSpx="$gSYSinfoDir/System-Profiler.spx"
    local targetNvramVars="$gMiscDir/gEfiAppleNvramGuid_Vars.txt"
    local targetNvramPlist="$gSYSinfoDir/nvram.plist"
    
    local fmmToken=$( echo $(GetValue "fmm-mobileme-token-FMM" "IOService") | sed 's/^ *//g' )
    local fmmTokenSearchReplace=$(CreateFindReplaceString "${fmmToken[@]}") 
    local serialNo=$( echo $(GetValue "IOPlatformSerialNumber" "IOService") | sed 's/^ *//g' )
    local serialNoSearchReplace=$(CreateFindReplaceString "${serialNo[@]}") 
    local uuidNo=( $( echo $(GetValue "IOPlatformUUID" "IOService") | sed 's/^ *//g' ) )
    local uuidNoSearchReplace=$(CreateFindReplaceString "${uuidNo[@]}") 
    local macAddress=( $( echo $(GetValue "IOMACAddress" "IOService") | sed 's/^ *//g' ) )
    local macAddressSearchReplace=$(CreateFindReplaceString "${macAddress[@]}")
    local usbSerialNo=( $( echo $(GetValue "USB Serial Number" "IOService") | sed 's/^ *//g' ) ) # iPhone / iPad can be here.
    local usbSerialNoSearchReplace=$(CreateFindReplaceString "${usbSerialNo[@]}") 
    local systemSerialNumber=( $( echo $(GetValue "SystemSerialNumber" "IODeviceTree") | sed 's/^ *//g' ) )
    local systemSerialNumberSearchReplace=$(CreateFindReplaceString "${systemSerialNumber[@]}")
    local serialNumber=( $( echo $(GetValue "serial-number" "IODeviceTree") | sed 's/^ *//g' ) )
    local serialNumberSearchReplace=$(CreateFindReplaceString "${serialNumber[@]}")
    # Special situation for masking systemSerialNumber in IORegistry Web Viewer.
    # This is because each letter is enclosed in double quotes and these need to be escaped. 
    local systemSerialNumberIorwvA=$( echo "$systemSerialNumber" | sed 's/\"/\\\\\\\\\\\\\\\\\\\\\\\\\\\"/g' )
    local systemSerialNumberIorwvB=$( echo "$systemSerialNumber" | sed 's/\"//g' )
    local oneOffMask=$(CreateMask "${systemSerialNumberIorwvB}") 
    local systemSerialNumberIorwvSearchReplace="s/${systemSerialNumberIorwvA}/${oneOffMask}/g;"

    # Mask IORegistry text files
    if [ -f "$targetIOreg" ]; then
        ApplyMask "$fmmTokenSearchReplace" "" "$targetIOreg"
        ApplyMask "$serialNoSearchReplace" "" "$targetIOreg"
        ApplyMask "$uuidNoSearchReplace" "" "$targetIOreg"
        ApplyMask "$macAddressSearchReplace" "" "$targetIOreg"
        ApplyMask "$usbSerialNoSearchReplace" "" "$targetIOreg"
    fi
    if [ -f "$targetIOregDT" ]; then
        ApplyMask "$serialNoSearchReplace" "" "$targetIOregDT"
        ApplyMask "$uuidNoSearchReplace" "" "$targetIOregDT"
        ApplyMask "$systemSerialNumberSearchReplace" "" "$targetIOregDT"
        ApplyMask "$serialNumberSearchReplace" "" "$targetIOregDT"
    fi
    
    # Mask IORegistry Web Viewer files
    PatchFullIoregDump "fmm-mobileme-token-FMM" "$fmmTokenSearchReplace"
    PatchFullIoregDump "IOPlatformSerialNumber" "$serialNoSearchReplace"
    PatchFullIoregDump "IOPlatformUUID" "$uuidNoSearchReplace"
    PatchFullIoregDump "IOMACAddress" "$macAddressSearchReplace"
    PatchFullIoregDump "USB Serial Number" "$usbSerialNoSearchReplace"
    PatchFullIoregDump "SystemSerialNumber" "$systemSerialNumberIorwvSearchReplace"
    PatchFullIoregDump "serial-number" "$serialNumberSearchReplace"
    
    # Mask System Profiler files.
    if [ -f "$targetSysProfTxt" ]; then
        ApplyMask "$usbSerialNoSearchReplace" "" "$targetSysProfTxt"
    fi
    if [ -f "$targetSysProfSpx" ]; then
        ApplyMask "$usbSerialNoSearchReplace" "" "$targetSysProfSpx"
    fi
    
    # Mask NVRAM Efivars
    if [ -f "$targetNvramVars" ]; then
        local romVar=$( nvram 4D1EDE05-38C7-4A6A-9CC6-4BCCA8B38C14:ROM | awk '{print $2}' )
        local maskedVar=( $(CreateMask "${romVar}") )
        ApplyMask "$romVar" "$maskedVar" "$targetNvramVars"
        local mlbVar=$( nvram 4D1EDE05-38C7-4A6A-9CC6-4BCCA8B38C14:MLB | awk '{print $2}' )
        maskedVar=( $(CreateMask "${mlbVar}") )
        ApplyMask "$mlbVar" "$maskedVar" "$targetNvramVars"
    fi

    # Mask fmm-mobileme-token-FMM in $gSYSinfoDir/nvram.plist
    if [ -f "$targetNvramPlist" ]; then
        local foundToken=0
        while read -r lineRead
        do
            if [ $foundToken -eq 2 ] && [ "$lineRead" == "</data>" ]; then
                foundToken=0
                break
            fi
            if [ $foundToken -eq 2 ]; then
                local lineMasked=$(CreateMask "$lineRead")
                ApplyMask "$lineRead" "$lineMasked" "$targetNvramPlist"
            fi
            if [ $foundToken -eq 1 ]; then
                if [ "$lineRead" == "<data>" ]; then
                    ((foundToken++))
                fi
            fi
            if [[ "$lineRead" == *fmm-mobileme-token-FMM* ]]; then
                foundToken=1
            fi
        done < "$targetNvramPlist"
    fi
    
    # Mask bootloader configuration files.
    if [ -d "$gBootConfigDir" ]; then
        maskBootloaderConfigData "config.plist" "SerialNumber"
        maskBootloaderConfigData "config.plist" "CustomUUID"
        maskBootloaderConfigData "SMBIOS.plist" "SMserial"
        maskBootloaderConfigData "org.chameleon.Boot.plist" "SystemId"
        maskBootloaderConfigData "settings.plist" "PlatformUUID"
        maskBootloaderConfigData "settings.plist" "SerialNumber"
        maskBootloaderConfigData "settings.plist" "MLBData"
    fi
    
    # Mask DMI dump files.
    if [ -f "$targetSMBIOS" ]; then
        ApplyMask "$serialNoSearchReplace" "" "$targetSMBIOS"
    fi  
    if [ -f "$targetSMBIOSbin" ]; then
        ApplyMask "$serialNoSearchReplace" "" "$targetSMBIOSbin"
    fi
    
    echo "Completed Privatising Dumps"      
    echo "F:privacy" >> /tmp/dd_completed 
}

# ---------------------------------------------------------------------------------------
CloseLog()
{
    gScriptRunTime="$(($(date +%s)-gScriptRunTime))"
    echo "========================================================
DarwinDumper Completed in: ${gScriptRunTime} seconds
========================================================" >> "${gLogFile}"
}

# ---------------------------------------------------------------------------------------
ArchiveDumpFolder()
{
    local prevDateTime
    local existingDumpFolders=()
    local checkIcon=""

    if [ "$gRadio_archiveType" == "Archive.zip" ]; then
        echo "S:archive" >> /tmp/dd_completed
        echo "Compressing latest DarwinDumper folder using .zip"
        zip -r -q "${gThisIndexedDumpFolder}/${gFolderName}".zip "${gThisIndexedDumpFolder}/${gFolderName}"
        sleep 1
        echo "F:archive" >> /tmp/dd_completed
    elif [ "$gRadio_archiveType" == "Archive.lzma" ]; then
        echo "S:archive" >> /tmp/dd_completed
        echo "Compressing latest DarwinDumper folder using .lzma"
        tar -pvczf "${gThisIndexedDumpFolder}/${gFolderName}".tar.gz "${gThisIndexedDumpFolder}/${gFolderName}" &> /dev/null
        sleep 1
        "$lzma" e "${gThisIndexedDumpFolder}/${gFolderName}".tar.gz "${gThisIndexedDumpFolder}/${gFolderName}".tar.lzma
        chmod 755 "${gThisIndexedDumpFolder}/${gFolderName}".tar.lzma
        rm "${gThisIndexedDumpFolder}/${gFolderName}".tar.gz
        sleep 1
        echo "F:archive" >> /tmp/dd_completed
    fi
    
}

# ---------------------------------------------------------------------------------------
Finish()
{
    if [ -f /tmp/diskutilLoaderInfo.txt ]; then
        rm /tmp/diskutilLoaderInfo.txt # Created in the gatherDiskUtilLoaderinfo.sh script
    fi
    
    # Has the used asked not to open the folder and html file? (0 = show, 1 = do not show).
    if [ $gNoShow -ne 1 ]; then
        open "${gThisIndexedDumpFolder}/${gFolderName}"
        if [ -f "${gThisIndexedDumpFolder}/${gFolderName}"/DarwinDump.htm ]; then
            open "${gThisIndexedDumpFolder}/${gFolderName}"/DarwinDump.htm
        fi
    fi

    chown -R 501:80 "$gDumpDir"/"$gAppReportsFolder"
    chmod -R 755 "$gDumpDir"/"$gAppReportsFolder"
}

#
# =======================================================================================
# SYSTEM SCAN & DUMP FILE ROUTINES 
# =======================================================================================
#

# ---------------------------------------------------------------------------------------
DumpFilesAcpiTables()
{   
    local acpi_tbls
    local tbl
    local tbl_name
    local tbl_data

    echo "       Dumping ACPI tables to AML & DSL formats..." >> "${gLogFile}"
    echo "S:acpi" >> /tmp/dd_completed
    CreateDumpDirs "$gACPIDir $gAMLDir $gDSLDir"
    acpi_tbls=`ioreg -lw0 | grep "ACPI Tables" | cut -f2 -d"{" | tr "," " "`
    for tbl in $acpi_tbls
    do
        tbl_name=`echo $tbl | cut -f1 -d"=" | tr -d "\""`
        echo "       Found ACPI table: $tbl_name" >> "${gLogFile}"
        tbl_data=`echo $tbl | cut -f2 -d"<" | tr -d ">"`
        echo $tbl_data | xxd -r -p > "$gAMLDir"/$tbl_name.aml
        "$iasl" -d "$gAMLDir"/$tbl_name.aml &> /dev/null
    done
    if [[ `find "$gAMLDir" -name *.dsl` ]]; then
        mv "$gAMLDir"/*.dsl "$gDSLDir"/
    fi
    echo "$(($(date +%s)-gScriptRunTime))s : -Completed AcpiTables" >> "${gLogFile}"
    echo "Completed ACPI Tables"
    echo "F:acpi" >> /tmp/dd_completed
}

# ---------------------------------------------------------------------------------------
DumpFilesAudioCodec()
{
    echo "       Dumping Audio Codec ID..." >> "${gLogFile}"
    echo "S:codecid" >> /tmp/dd_completed
    CreateDumpDirs "$gSYSinfoDir"
    
    # Remember also for later as this gets passed to the generateHTMLreport script
    # for adding to the header of the HTML report.
    codecID=`$getcodecid`
    
    echo "$codecID" > "$gSYSinfoDir"/AudioCodecID.txt
    CheckSuccess "$gSYSinfoDir/AudioCodecID.txt"
    echo "Completed Audio Codec Dump"
    echo "F:codecid" >> /tmp/dd_completed
    
    # Also try to run VoodooHDA's getdump tool.
    if [ $gRootPriv -eq 1 ]; then
        LoadVoodooHdaDriver
        echo "       Waiting 2 seconds before running getdump" >> "${gLogFile}"
        sleep 2
        voodooDump=`$getdump`
        if [ ! "$voodooDump" == "" ]; then
            echo "       getdump was successful" >> "${gLogFile}"
            echo "$voodooDump" > "$gSYSinfoDir"/AudioDumpVoodoo.txt        
        else
            echo "       getdump produced nothing." >> "${gLogFile}"
        fi
        UnloadVoodooHdaDriver
    else
        echo "** Root privileges required to load VoodooHDA.kext." >> "${gLogFile}"
    fi
    echo "$(($(date +%s)-gScriptRunTime))s : -Completed DumpFilesAudioCodec" >> "${gLogFile}"
}

# ---------------------------------------------------------------------------------------
DumpFilesBiosROM()
{
    echo "       Dumping BIOS with Flashrom..." >> "${gLogFile}"
    echo "S:bios" >> /tmp/dd_completed
    CreateDumpDirs "$gBiosROMDir"
    if [ $gRootPriv -eq 1 ]; then
        local driverName=$(LoadPciUtilsDriver)  
        "$flashrom" -p internal -r "$gBiosROMDir"/biosbackup.rom -o "$gBiosROMDir"/flashrom_log.txt &> /dev/null
        CheckSuccess "$gBiosROMDir/flashrom_log.txt"
    else
        echo "** Root privileges required to dump bios." >> "${gLogFile}"
    fi
    echo "$(($(date +%s)-gScriptRunTime))s : -Completed DumpFilesBiosROM" >> "${gLogFile}"
    echo "Completed BIOS ROM"
    echo "F:bios" >> /tmp/dd_completed
}

# ---------------------------------------------------------------------------------------
DumpFilesDeviceProperties()
{
    echo "       Dumping device-properties..." >> "${gLogFile}"
    echo "S:devprop" >> /tmp/dd_completed
    CreateDumpDirs "$gDEVDir"
    ioreg -lw0 -p IODeviceTree -n efi -r -x | grep device-properties | sed 's/.*<//;s/>.*//;' | cat > "$gDEVDir"/device-properties.hex
    CheckSuccess "$gDEVDir/device-properties.hex"
    "$gfxutil" -s -i hex -o xml "$gDEVDir"/device-properties.hex "$gDEVDir"/device-properties.plist
    CheckSuccess "$gDEVDir/device-properties.plist"
    
    echo "$(($(date +%s)-gScriptRunTime))s : -Completed DumpFilesDeviceProperties" >> "${gLogFile}"
    echo "Completed Device Properties"
    echo "F:devprop" >> /tmp/dd_completed
}

# ---------------------------------------------------------------------------------------
DumpFilesDiskUtilAndLoader()
{
    "$gatherDiskUtilLoaderinfo" "${gMasterDumpFolder}" "$1" "$2" "$3" "$4"

    # ---------------------------------------------------------------------------------------
    BuildBootLoadersFile()
    {
        local passedTextLine="$1"
        if [ ! "$passedTextLine" == "" ]; then
            buildString="${buildString}"$(printf "${passedTextLine}\n")
            buildString="${buildString}\n" 
        fi
    }

    local fileToRead="/tmp/diskutilLoaderInfo.txt" # Created in the gatherDiskUtilLoaderinfo.sh script
    local finalOutFile="$gBootSectDir/Bootloaders.txt"
    buildString=""
    
    if [ -f "$fileToRead" ]; then
        while read -r lineRead
        do
            if [ ! "${lineRead:0:1}" == "=" ]; then
                codeRead="${lineRead%%:*}"
                detailsRead="${lineRead#*:}"
                if [ "$detailsRead" == "" ]; then
                    detailsRead=" "
                fi 
                
                case "$codeRead" in
                    "WD") BuildBootLoadersFile "${detailsRead}"
                          BuildBootLoadersFile "ACTV@DEVICE@TYPE@NAME@SIZE@MBR (Stage0)@PBR (Stage1)@BootFile (Stage 2)@UEFI BootFile" ;;
                    "DS") diskSize="${detailsRead}" ;;
                    "DT") diskType="${detailsRead}" ;;
                    "S0") stageZero="${detailsRead}" 
                          BuildBootLoadersFile " @ @${diskType}@ @${diskSize}@${stageZero}" ;;
                    "VA") volumeActive="${detailsRead}" ;;
                    "VD") volumeDevice="${detailsRead}" ;;
                    "VT") volumeType="${detailsRead}" ;;
                    "VN") volumeName="${detailsRead}" ;;
                    "VS") volumeSize="${detailsRead}" ;;
                    "S1") stageOne="${detailsRead}"
                          BuildBootLoadersFile "${volumeActive}@${volumeDevice}@${volumeType}@${volumeName}@${volumeSize}@ @${stageOne}" ;;
                    "BF") bootFile="${detailsRead}" ;;
                    "S2") if [ "${detailsRead}" == "" ] || [[ "${detailsRead}" =~ ^\ +$ ]] ;then # if blank or only whitespace
                              stageTwo=""
                          else
                              stageTwo="(${detailsRead})"
                          fi
                          BuildBootLoadersFile " @ @ @ @ @ @ @${bootFile}${stageTwo}";;
                    "UF") uefiFile="${detailsRead}" ;;
                    "U2") if [ "${detailsRead}" == "" ] || [[ "${detailsRead}" =~ ^\ +$ ]] ;then # if blank or only whitespace
                              uefiFileVersion=""
                          else
                              uefiFileVersion="(${detailsRead})"
                          fi
                          BuildBootLoadersFile " @ @ @ @ @ @ @ @${uefiFile}${uefiFileVersion}" ;;
                esac
            fi
        done < "$fileToRead"
        printf "$buildString" | column -t -s@ >> "${finalOutFile}"
        echo "F:diskUtilLoaders" >> /tmp/dd_completed
    fi
    echo "$(($(date +%s)-gScriptRunTime))s : -Completed DumpFilesDiskUtilAndLoader" >> "${gLogFile}"
    echo "Completed DiskUtil & Boot Loaders"
}

# ---------------------------------------------------------------------------------------
DumpFilesFirmwareLog()
{
    local bdmesgResult=$("$bdmesg")
    local fileToInclude=""
    if [ "$bdmesgResult" == "\"boot-log\" property not found." ]; then
        # This means the bootloader is not Chameleon
        if [[ ! "${gTheLoader}" =~ "Apple" ]]; then
            # XPC and RevoBoot identify as Apple so this should leave Clover...
            echo "       Dumping ${gTheLoader} Firmware log..." >> "${gLogFile}"
            echo "S:firmlog" >> /tmp/dd_completed
            CreateDumpDirs "$gIOregDir"
            # merged the showlog script in to here
            ioreg -lw0 -pIODeviceTree | grep boot-log > ./log.txt
            logdump=$(cat ./log.txt)
            modified1=${logdump#*'boot-log'}
            modified2=${modified1#*'<'}
            modified3=${modified2%%'>'*}
            echo $modified3 > ./boot-log.txt
            xxd -r -p ./boot-log.txt > ./boot.log
            rm ./log.txt
            rm ./boot-log.txt
            mv boot.log "$gIOregDir/${gTheLoader}_BootLog.txt"
            CheckSuccess "$gIOregDir/${gTheLoader}_BootLog.txt"
        fi
    else
        echo "       Dumping ${gTheLoader} Firmware log..." >> "${gLogFile}"
        echo "S:firmlog" >> /tmp/dd_completed
        CreateDumpDirs "$gIOregDir"
        echo "$bdmesgResult" > "$gIOregDir/Chameleon_BootLog.txt"
        CheckSuccess "$gIOregDir/Chameleon_BootLog.txt"
    fi
    echo "$(($(date +%s)-gScriptRunTime))s : -Completed DumpFilesFirmwareLog" >> "${gLogFile}"
    echo "Completed Firmware Log"
    echo "F:firmlog" >> /tmp/dd_completed
}

# ---------------------------------------------------------------------------------------
DumpFilesFirmwareMemoryMap()
{
    echo "       Dumping ${gTheLoader} FirmwareMemoryMap" >> "${gLogFile}"
    echo "S:firmmemmap" >> /tmp/dd_completed
    CreateDumpDirs "$gSYSinfoDir"
    if [ $gRootPriv -eq 1 ]; then
        "$sbmm" > "$gSYSinfoDir/FirmwareMemoryMap.txt"
        wait
        CheckSuccess "$gSYSinfoDir/FirmwareMemoryMap.txt"
    else
        echo "** Root privileges required to dump firmware memory map." >> "${gLogFile}"
    fi
 	echo "$(($(date +%s)-gScriptRunTime))s : -Completed DumpFilesFirmwareMemoryMap" >> "${gLogFile}"
    echo "Completed Firmware Memory Map"
    echo "F:firmmemmap" >> /tmp/dd_completed
}

# ---------------------------------------------------------------------------------------
DumpFilesIoreg()
{
    local ioregServiceDumpFile="$gIOregDir"/IORegDump
    local ioregDTDumpFile="$gIOregDir"/IORegDTDump
    local ioregACPIDumpFile="$gIOregDir"/IORegACPIDump
    local ioregPowerDumpFile="$gIOregDir"/IORegPOWERDump
    local ioregUSBDumpFile="$gIOregDir"/IORegUSBDump

    echo "       Dumping I/O Kit Registry contents..." >> "${gLogFile}"
    echo "S:ioreg" >> /tmp/dd_completed
    CreateDumpDirs "$gIOregDir"
    
    "$ioregwv" -lw0 > "$ioregServiceDumpFile"
    CheckSuccess "$ioregServiceDumpFile"
 	"$ioregwv" -lw0 -pIODeviceTree > "$ioregDTDumpFile"
    CheckSuccess "$ioregDTDumpFile"
    "$ioregwv" -lw0 -pIOACPIPlane > "$ioregACPIDumpFile"
    CheckSuccess "$ioregACPIDumpFile"
    "$ioregwv" -lw0 -pIOPower > "$ioregPowerDumpFile"
    CheckSuccess "$ioregPowerDumpFile"
    "$ioregwv" -lw0 -pIOUSB > "$ioregUSBDumpFile"
    CheckSuccess "$ioregUSBDumpFile"
    
    "$processIoregDumps" "$gMasterDumpFolder"
    
    # Add necessary scripts to IOReg dump folder.
    cp -R "$ioregViewerDir"/* "$gIOregDir"/IORegViewer/
    
    # Also add normal ioreg text dumps
    ioreg -lw0 > "$gIOregDir"/IOReg.txt
    ioreg -lw0 -pIODeviceTree > "$gIOregDir"/IORegDT.txt
    
 	echo "$(($(date +%s)-gScriptRunTime))s : -Completed DumpFilesIoreg" >> "${gLogFile}"
    echo "Completed Ioreg"
    echo "F:ioreg" >> /tmp/dd_completed
}

# ---------------------------------------------------------------------------------------
DumpFilesKernelBootMessages()
{
    echo "       Dumping Kernel boot messages..." >> "${gLogFile}"
    echo "S:kerneldmesg" >> /tmp/dd_completed
    CreateDumpDirs "$gSYSinfoDir"
    if [ $gRootPriv -eq 1 ]; then
        /sbin/dmesg > "$gSYSinfoDir"/Boot-Messages.txt
        CheckSuccess "$gSYSinfoDir/Boot-Messages.txt"
    else
        echo "** Root privileges required to dump kernel dmesg." >> "${gLogFile}"
    fi
 	echo "$(($(date +%s)-gScriptRunTime))s : -Completed DumpFilesKernelBootMessages" >> "${gLogFile}"
    echo "Completed Kernel Boot Messages"
    echo "F:kerneldmesg" >> /tmp/dd_completed
}

# ---------------------------------------------------------------------------------------
DumpFilesKernelInfo()
{
    echo "       Dumping Kernel Info..." >> "${gLogFile}"
    echo "S:kernelinfo" >> /tmp/dd_completed
    CreateDumpDirs "$gSYSinfoDir"
    uname -v | cat > $gSYSinfoDir/Kernel-Info.txt
    /usr/sbin/sysctl -a | grep cpu | cat >> "$gSYSinfoDir/Kernel-Info.txt"
    /usr/sbin/sysctl -a | grep hw | cat >> "$gSYSinfoDir/Kernel-Info.txt"
    CheckSuccess "$gSYSinfoDir/Kernel-Info.txt"
 	echo "$(($(date +%s)-gScriptRunTime))s : -Completed DumpFilesKernelInfo" >> "${gLogFile}"
    echo "Completed Kernel Info"
    echo "F:kernelinfo" >> /tmp/dd_completed
}

# ---------------------------------------------------------------------------------------
DumpFilesKextLists()
{
    echo "       Dumping Non Apple Kext list..." >> "${gLogFile}"
    echo "S:kexts" >> /tmp/dd_completed
    
    CreateDumpDirs "$gSYSinfoDir"
    /usr/sbin/kextstat -l | egrep -v "com.apple" > "$gSYSinfoDir"/NonAppleKexts.txt
    CheckSuccess "$gSYSinfoDir/NonAppleKexts.txt"   
    echo "       Dumping Apple Kext list..." >> "${gLogFile}"
    /usr/sbin/kextstat -l | egrep "com.apple" > "$gSYSinfoDir"/AppleKexts.txt
    CheckSuccess "$gSYSinfoDir/AppleKexts.txt"    
    echo "$(($(date +%s)-gScriptRunTime))s : -Completed DumpFilesKextLists" >> "${gLogFile}"
    echo "Completed Kext Lists"
    echo "F:kexts" >> /tmp/dd_completed
}

# ---------------------------------------------------------------------------------------
DumpFilesLspci()
{   
    # ---------------------------------------------------------------------------------------
    Updatepciids()
    {
        local SRC="http://pci-ids.ucw.cz/v2.2/pci.ids.gz"
        local DEST="$pciids"
        local DL
        
        # Update pciids file every week. Check to see if current file
        # is older than seven days - if so, update.
        if [ `find "$DEST" -mtime +7` ]; then
            echo  "       Update pciids database" >> "${gLogFile}"
            
            # Test server is available
            local testConnection=$(curl --silent --head http://pci-ids.ucw.cz | egrep "OK")
            if [ "$testConnection" ]; then
                echo "       Update pciids" >> "${gLogFile}"
                if which curl >/dev/null ; then
                	DL="curl -o $DEST $SRC"
                elif which wget >/dev/null ; then
            	    DL="wget -O $DEST $SRC"
                elif which lynx >/dev/null ; then
            	    DL="eval lynx -source $SRC >$DEST"
                else
            	    echo  "       update-pciids: cannot find curl, wget or lynx" >> "${gLogFile}"
        	        return 1
                fi

                if ! $DL ; then
        	        echo  "       update-pciids: download failed" >> "${gLogFile}"
        	        rm -f $DEST
        	        return 1
                fi
            else
                echo "       Note: pciids server not available." >> "${gLogFile}"
            fi
        else
            echo "       pciids file < 7 days old. No update required." >> "${gLogFile}"
        fi
    }
    
    if [ $gRootPriv -eq 1 ]; then 
        Updatepciids
        if [[ `find "${pciids}"` ]]; then 
   
            echo "       Dumping LSPCI info..." >> "${gLogFile}"
            echo "S:lspci" >> /tmp/dd_completed
            CreateDumpDirs "$gSYSinfoDir"
            local driverName=$(LoadPciUtilsDriver)
            "$lspci" -i "$pciids" -nnvv > "$gSYSinfoDir/lspci.txt"
            CheckSuccess "$gSYSinfoDir/lspci.txt"
 	        "$lspci" -i "$pciids" -nnvvbxxxx > "$gSYSinfoDir/lspci_detailed.txt"
 	        CheckSuccess "$gSYSinfoDir/lspci_detailed.txt"
	        "$lspci" -i "$pciids" -nnvvt > "$gSYSinfoDir/lspcitree.txt"
	        CheckSuccess "$gSYSinfoDir/lspcitree.txt"
        	"$lspci" -i "$pciids" -M > "$gSYSinfoDir/lspci_map.txt"
        	CheckSuccess "$gSYSinfoDir/lspci_map.txt"
        else
    	    echo "       Error DumpFilesLspci" >> "${gLogFile}"
        fi
    else
        echo "** Root privileges required to load DirectHW.kext and run lspci." >> "${gLogFile}"
    fi
    echo "$(($(date +%s)-gScriptRunTime))s : -Completed DumpFilesLspci" >> "${gLogFile}"
    echo "Completed lspci"
    echo "F:lspci" >> /tmp/dd_completed
}

# ---------------------------------------------------------------------------------------
DumpFilesOpenCLInfo()
{
    echo "       Dumping OpenCL Info..." >> "${gLogFile}"
    echo "S:opencl" >> /tmp/dd_completed
    CreateDumpDirs "$gSYSinfoDir"
    "$oclinfo" > "$gSYSinfoDir/openCLinfo.txt"
    CheckSuccess "$gSYSinfoDir/openCLinfo.txt"
    echo "$(($(date +%s)-gScriptRunTime))s : -Completed DumpFilesOpenCLInfo" >> "${gLogFile}"
    echo "Completed OpenCL Info"
    echo "F:opencl" >> /tmp/dd_completed
}

# ---------------------------------------------------------------------------------------
DumpFilesRtc()
{
    local systemVersion=$(CheckOsVersion)
    echo "       Dumping RTC..." >> "${gLogFile}"
    echo "S:rtc" >> /tmp/dd_completed
    CreateDumpDirs "$gRTCDir"
    "$rtcdumper" > "$gRTCDir/RTCDump${rtclength}.txt"
    CheckSuccess "$gRTCDir/RTCDump${rtclength}.txt"
    wait
    echo "$(($(date +%s)-gScriptRunTime))s : -Completed DumpFilesRtc" >> "${gLogFile}"
    echo "Completed RTC"
    echo "F:rtc" >> /tmp/dd_completed
}

# ---------------------------------------------------------------------------------------
DumpFilesDmiTables()
{
    echo "       Dumping DMI table..." >> "${gLogFile}"
    echo "S:dmi" >> /tmp/dd_completed
    CreateDumpDirs "$gSMDir"
    cd $gSMDir
    "$smbiosreader"
    mv $gSMDir/dump.bin "$gSMDir/SMBIOS.bin"
    CheckSuccess "$gSMDir/SMBIOS.bin"
    local systemVersion=$(CheckOsVersion)
    "$dmidecode" -i "$gSMDir/SMBIOS.bin" | cat > "$gSMDir/SMBIOS.txt"
    CheckSuccess "$gSMDir/SMBIOS.txt"
    echo "$(($(date +%s)-gScriptRunTime))s : -Completed DumpFilesDmiTables" >> "${gLogFile}"
    echo "Completed DMI Tables"
    echo "F:dmi" >> /tmp/dd_completed
}

# ---------------------------------------------------------------------------------------
DumpFilesSmcKeys()
{
    echo "       Dumping SMC keys..." >> "${gLogFile}"
    echo "S:smc" >> /tmp/dd_completed
    CreateDumpDirs "$gSMCDir"
    "$smcutil" -l | cat > "$gSMCDir/SMC-keys.txt"
    CheckSuccess "$gSMCDir/SMC-keys.txt"
    "$smcutil" -f | cat > "$gSMCDir/SMC-fans.txt"
    CheckSuccess "$gSMCDir/SMC-fans.txt"
    echo "$(($(date +%s)-gScriptRunTime))s : -Completed DumpFilesSmcKeys" >> "${gLogFile}"
    echo "Completed SMC Keys"
    echo "F:smc" >> /tmp/dd_completed
}

# ---------------------------------------------------------------------------------------
DumpFilesSystemProfilerInfo()
{
    echo "       Dumping System Profiler..." >> "${gLogFile}"
    echo "S:sysprof" >> /tmp/dd_completed
    CreateDumpDirs "$gSYSinfoDir"
    /usr/sbin/system_profiler -xml -detailLevel mini | cat > "$gSYSinfoDir"/System-Profiler.spx
    CheckSuccess "$gSYSinfoDir/System-Profiler.spx"
    /usr/sbin/system_profiler -detailLevel mini > "$gSYSinfoDir"/System-Profiler.txt
    CheckSuccess "$gSYSinfoDir/System-Profiler.txt"
    echo "$(($(date +%s)-gScriptRunTime))s : -Completed DumpFilesSystemProfilerInfo" >> "${gLogFile}"
    echo "Completed System Profiler"
    echo "F:sysprof" >> /tmp/dd_completed
}

# ---------------------------------------------------------------------------------------
DumpFilesMisc()
{
    echo "       Dumping Misc Info..." >> "${gLogFile}"
    echo "S:misc" >> /tmp/dd_completed
    CreateDumpDirs "$gMiscDir"
    
    # Dump some gEfiAppleNvramGuid VARS
    nvram 4D1EDE05-38C7-4A6A-9CC6-4BCCA8B38C14:ROM >> "$gMiscDir"/gEfiAppleNvramGuid_Vars.txt
    nvram 4D1EDE05-38C7-4A6A-9CC6-4BCCA8B38C14:MLB >> "$gMiscDir"/gEfiAppleNvramGuid_Vars.txt
    nvram 4D1EDE05-38C7-4A6A-9CC6-4BCCA8B38C14:FirmwareFeatures >> "$gMiscDir"/gEfiAppleNvramGuid_Vars.txt
    nvram 4D1EDE05-38C7-4A6A-9CC6-4BCCA8B38C14:FirmwareFeaturesMask >> "$gMiscDir"/gEfiAppleNvramGuid_Vars.txt
    nvram 8BE4DF61-93CA-11D2-AA0D-00E098032B8C:BootCurrent >> "$gMiscDir"/gEfiAppleNvramGuid_Vars.txt
    nvram 8BE4DF61-93CA-11D2-AA0D-00E098032B8C:BootOptionSupport >> "$gMiscDir"/gEfiAppleNvramGuid_Vars.txt
    nvram 8BE4DF61-93CA-11D2-AA0D-00E098032B8C:BootOrder >> "$gMiscDir"/gEfiAppleNvramGuid_Vars.txt
    # Loop through Boot000X to see if we can dump anything.
    local getBoot=$(nvram 8BE4DF61-93CA-11D2-AA0D-00E098032B8C:Boot0000 2>/dev/null)
    local index=0
    while [ "$getBoot" != "" ]
    do 
        echo "$getBoot" >> "$gMiscDir"/gEfiAppleNvramGuid_Vars.txt
        ((index++))
        if [ ${#index} -eq 1 ]; then
            getBoot=$(nvram 8BE4DF61-93CA-11D2-AA0D-00E098032B8C:Boot000${index})
        elif [ ${#index} -eq 2 ]; then
            getBoot=$(nvram 8BE4DF61-93CA-11D2-AA0D-00E098032B8C:Boot00${index})
        fi
        if [ $index -eq 10 ]; then # Should this be a greater number?
            break
        fi
    done
    
    # Check there's content in the gEfiAppleNvramGuid_Vars.txt file
    if [ $(du "$gMiscDir"/gEfiAppleNvramGuid_Vars.txt | awk '{ print $1 }') -eq 0 ]; then
        rm "$gMiscDir"/gEfiAppleNvramGuid_Vars.txt
    fi
    
    # Dump any startup and shutdown scripts
    if [ -f /etc/rc.local ]; then
        CreateDumpDirs "$gScriptDir"
        cp /etc/rc.local "$gScriptDir/rc.local"
        CheckSuccess "$gScriptDir/rc.local"
    fi
    if [ -f /etc/rc.shutdown.local ]; then
        CreateDumpDirs "$gScriptDir"
        cp /etc/rc.shutdown.local "$gScriptDir/rc.shutdown.local"
        CheckSuccess "$gScriptDir/rc.shutdown.local"
    fi
    echo "$(($(date +%s)-gScriptRunTime))s : -Completed DumpFilesMisc" >> "${gLogFile}"
    echo "Completed Misc (EFI Vars, boot/shutdown scripts)"
    echo "F:misc" >> /tmp/dd_completed
}

# ---------------------------------------------------------------------------------------
DumpFilesNvramPlist()
{
    echo "       Dumping nvram plist..." >> "${gLogFile}"
    echo "S:nvram" >> /tmp/dd_completed
    CreateDumpDirs "$gSYSinfoDir"
    /usr/sbin/nvram -x -p >"$gSYSinfoDir"/nvram.plist
    CheckSuccess "$gSYSinfoDir/nvram.plist"
    echo "$(($(date +%s)-gScriptRunTime))s : -Completed DumpFilesNvramPlist" >> "${gLogFile}"
    echo "Completed nvram.plist"
    echo "F:nvram" >> /tmp/dd_completed
}

# ---------------------------------------------------------------------------------------
DumpFilesEdid()
{
    echo "       Dumping EDID..." >> "${gLogFile}"
    echo "S:edid" >> /tmp/dd_completed
    CreateDumpDirs "$gEDIDDir"

    # check in case there's more than EDID occurrence in ioreg
    local numEdid=$(/usr/sbin/ioreg -lw0 | grep IODisplayEDID | wc -l | tr -d ' ')
    if [ $numEdid -gt 1 ]; then
        for (( e=1; e<=$numEdid; e++ ))
        do
            local lineWanted="sed -n ${e}p"
            /usr/sbin/ioreg -lw0 | grep IODisplayEDID | sed -ne 's/.*EDID" = <//p' | tr -d '>' | $lineWanted > "$gEDIDDir"/EDID${e}.bin
            "$ediddecode" "$gEDIDDir"/EDID${e}.bin | cat > "$gEDIDDir/EDID${e}.txt"
            CheckSuccess "$gEDIDDir/EDID${e}.txt"
        done 
    else
        /usr/sbin/ioreg -lw0 | grep IODisplayEDID | sed -ne 's/.*EDID" = <//p' | tr -d '>' > "$gEDIDDir"/EDID.bin
        "$ediddecode" "$gEDIDDir"/EDID.bin | cat > "$gEDIDDir/EDID.txt"
        CheckSuccess "$gEDIDDir/EDID.txt"
    fi

    echo "$(($(date +%s)-gScriptRunTime))s : -Completed DumpFilesEdid" >> "${gLogFile}"
    echo "Completed EDID"
    echo "F:edid" >> /tmp/dd_completed
}
#
# =======================================================================================
# MAIN
# =======================================================================================
#

InitialiseBeforeUI
getFeedbackFromUI
InitialiseAfterUI

CheckRoot
gScriptRunTime="$(date +%s)"        

# Call routines to scan system and dump text files.
# as long as the cancel button was not ticked.
if [ $gButton_cancel -eq 0 ]; then
    CreateDumpDirs "$gMasterDumpFolder"
    echo "========================================================
Welcome to DarwinDumper ${gtheVersion}
$( date )
--------------------------------------------------------" > "${gLogFile}"
    echo "Initiating dumps..."
 
    # Run the dumps in stages otherwise the system could grind to a complete halt!
    newProcessCount=0
    if [ $gCheckBox_sysprof -eq 1 ]; then
        ((newProcessCount++))
        DumpFilesSystemProfilerInfo & pidFilesSytemProfilerInfo=$! ; flagSP=0
        echo "$(($(date +%s)-gScriptRunTime))s : +Started process DumpFilesSystemProfilerInfo: pid $pidFilesSytemProfilerInfo" >> "${gLogFile}"
    fi
    if [ $gCheckBox_diskLoaderConfigs -eq 1 ] || [ $gCheckBox_diskUtilLoaders -eq 1 ] || [ $gCheckBox_diskVolumeXuid -eq 1 ] || [ $gCheckBox_diskPartitionInfo -eq 1 ]; then
        ((newProcessCount++))
        DumpFilesDiskUtilAndLoader "$gCheckBox_diskLoaderConfigs" "$gCheckBox_diskUtilLoaders" "$gCheckBox_diskVolumeXuid" "$gCheckBox_diskPartitionInfo" & pidFilesDiskUtilAndLoader=$! ; flagDU=0
        echo "$(($(date +%s)-gScriptRunTime))s : +Started process DumpFilesDiskUtilAndLoader: pid $pidFilesDiskUtilAndLoader" >> "${gLogFile}"
    fi
    if [ $gCheckBox_bios -eq 1 ]; then
        ((newProcessCount++))
        DumpFilesBiosROM & pidFilesBiosROM=$! ; flagFB=0
        echo "$(($(date +%s)-gScriptRunTime))s : +Started process DumpFilesBiosROM: pid $pidFilesBiosROM" >> "${gLogFile}"
    fi
    if [ $newProcessCount -gt 0 ]; then
        c=0
        while sleep 0.5; do    
            if [ $gCheckBox_sysprof -eq 1 ]; then
                kill -0 $pidFilesSytemProfilerInfo &> /dev/null || if [ $flagSP -eq 0 ]; then ((c++)); flagSP=1; fi
            fi
            if [ $gCheckBox_diskLoaderConfigs -eq 1 ] || [ $gCheckBox_diskUtilLoaders -eq 1 ] || [ $gCheckBox_diskVolumeXuid -eq 1 ] || [ $gCheckBox_diskPartitionInfo -eq 1 ]; then
                kill -0 $pidFilesDiskUtilAndLoader &> /dev/null || if [ $flagDU -eq 0 ]; then ((c++)); flagDU=1; fi
            fi
            if [ $gCheckBox_bios -eq 1 ]; then
                kill -0 $pidFilesBiosROM &> /dev/null|| if [ $flagFB -eq 0 ]; then ((c++)); flagFB=1; fi
            fi
            if [ $c -eq $newProcessCount ]; then
                break
            fi
        done
        #wait
    fi

    newProcessCount=0
    if [ $gCheckBox_acpi -eq 1 ]; then
        ((newProcessCount++))
        DumpFilesAcpiTables & pidFilesAcpiTables=$! ; flagAT=0
        echo "$(($(date +%s)-gScriptRunTime))s : +Started process DumpFilesAcpiTables: pid $pidFilesAcpiTables" >> "${gLogFile}"
    fi
    if [ $gCheckBox_codecid -eq 1 ]; then
        ((newProcessCount++))
        DumpFilesAudioCodec & pidFilesAudioCodec=$! ; flagAC=0
        echo "$(($(date +%s)-gScriptRunTime))s : +Started process DumpFilesAudioCodec: pid $pidFilesAudioCodec" >> "${gLogFile}"
    fi
    if [ $gCheckBox_firmmemmap -eq 1 ]; then
        ((newProcessCount++))
        DumpFilesFirmwareMemoryMap & pidFirmwareMemoryMap=$! ; flagFM=0
        echo "$(($(date +%s)-gScriptRunTime))s : +Started process DumpFilesFirmwareMemoryMap: pid $pidFirmwareMemoryMap" >> "${gLogFile}"
    fi
    if [ $gCheckBox_kexts -eq 1 ]; then
        ((newProcessCount++))
        DumpFilesKextLists & pidFilesKextLists=$! ; flagKL=0
        echo "$(($(date +%s)-gScriptRunTime))s : +Started process DumpFilesKextLists: pid $pidFilesKextLists" >> "${gLogFile}"
    fi
    if [ $gCheckBox_firmlog -eq 1 ]; then
        ((newProcessCount++))
        DumpFilesFirmwareLog & pidFilesFirmwareLog=$! ; flagFL=0
        echo "$(($(date +%s)-gScriptRunTime))s : +Started process DumpFilesFirmwareLog: pid $pidFilesFirmwareLog" >> "${gLogFile}"
    fi
    if [ $gCheckBox_devprop -eq 1 ]; then
        ((newProcessCount++))
        DumpFilesDeviceProperties & pidFilesDeviceProperties=$! ; flagDP=0
        echo "$(($(date +%s)-gScriptRunTime))s : +Started process DumpFilesDeviceProperties: pid $pidFilesDeviceProperties" >> "${gLogFile}"
    fi
    if [ $gCheckBox_opencl -eq 1 ]; then
        ((newProcessCount++))
        DumpFilesOpenCLInfo & pidFilesOpenCLInfo=$! ; flagOC=0
        echo "$(($(date +%s)-gScriptRunTime))s : +Started process DumpFilesOpenCLInfo: pid $pidFilesOpenCLInfo" >> "${gLogFile}"
    fi
    if [ $gCheckBox_kernelinfo -eq 1 ]; then
        ((newProcessCount++))
        DumpFilesKernelInfo & pidFilesKernelInfo=$! ; flagKI=0
        echo "$(($(date +%s)-gScriptRunTime))s : +Started process DumpFilesKernelInfo: pid $pidFilesKernelInfo" >> "${gLogFile}"
    fi
    if [ $gCheckBox_kerneldmesg -eq 1 ]; then
        ((newProcessCount++))
        DumpFilesKernelBootMessages & pidFilesKernelBootMessages=$! ; flagKB=0
        echo "$(($(date +%s)-gScriptRunTime))s : +Started process DumpFilesKernelBootMessages: pid $pidFilesKernelBootMessages" >> "${gLogFile}"
    fi
    if [ $gCheckBox_smc -eq 1 ]; then
        ((newProcessCount++))
        DumpFilesSmcKeys & pidFilesSmcKeys=$! ; flagSK=0
        echo "$(($(date +%s)-gScriptRunTime))s : +Started process DumpFilesSmcKeys: pid $pidFilesSmcKeys" >> "${gLogFile}"
    fi
    if [ $gCheckBox_rtc -eq 1 ]; then
        ((newProcessCount++))
        DumpFilesRtc & pidFilesRtc=$! ; flagRT=0
        echo "$(($(date +%s)-gScriptRunTime))s : +Started process DumpFilesRtc: pid $pidFilesRtc" >> "${gLogFile}"
    fi   
    if [ $gCheckBox_misc -eq 1 ]; then
        ((newProcessCount++))
        DumpFilesMisc & pidFilesMisc=$! ; flagMS=0
        echo "$(($(date +%s)-gScriptRunTime))s : +Started process DumpFilesMisc: pid $pidFilesMisc" >> "${gLogFile}"
    fi 
    if [ $newProcessCount -gt 0 ]; then    
        c=0
        while sleep 0.5; do      
            if [ $gCheckBox_acpi -eq 1 ]; then
                kill -0 $pidFilesAcpiTables &> /dev/null || if [ $flagAT -eq 0 ]; then ((c++)); flagAT=1; fi
            fi
            if [ $gCheckBox_codecid -eq 1 ]; then
                kill -0 $pidFilesAudioCodec &> /dev/null || if [ $flagAC -eq 0 ]; then ((c++)); flagAC=1; fi
            fi
            if [ $gCheckBox_firmmemmap -eq 1 ]; then
                kill -0 $pidFirmwareMemoryMap &> /dev/null || if [ $flagFM -eq 0 ]; then ((c++)); flagFM=1; fi
            fi
            if [ $gCheckBox_kexts -eq  1 ]; then
                kill -0 $pidFilesKextLists &> /dev/null || if [ $flagKL -eq 0 ]; then ((c++)); flagKL=1; fi
            fi
            if [ $gCheckBox_firmlog -eq 1 ]; then
                kill -0 $pidFilesFirmwareLog &> /dev/null || if [ $flagFL -eq 0 ]; then ((c++)); flagFL=1; fi
            fi
            if [ $gCheckBox_devprop -eq 1 ]; then
                kill -0 $pidFilesDeviceProperties &> /dev/null || if [ $flagDP -eq 0 ]; then ((c++)); flagDP=1; fi
            fi
            if [ $gCheckBox_opencl -eq 1 ]; then
                kill -0 $pidFilesOpenCLInfo &> /dev/null || if [ $flagOC -eq 0 ]; then ((c++)); flagOC=1; fi
            fi
            if [ $gCheckBox_kernelinfo -eq 1 ]; then
                kill -0 $pidFilesKernelInfo &> /dev/null || if [ $flagKI -eq 0 ]; then ((c++)); flagKI=1; fi
            fi
            if [ $gCheckBox_kerneldmesg -eq 1 ]; then
                kill -0 $pidFilesKernelBootMessages &> /dev/null || if [ $flagKB -eq 0 ]; then ((c++)); flagKB=1; fi
            fi
            if [ $gCheckBox_smc -eq 1 ]; then
                kill -0 $pidFilesSmcKeys &> /dev/null || if [ $flagSK -eq 0 ]; then ((c++)); flagSK=1; fi
            fi
            if [ $gCheckBox_rtc -eq 1 ]; then
                kill -0 $pidFilesRtc &> /dev/null || if [ $flagRT -eq 0 ]; then ((c++)); flagRT=1; fi
            fi
            if [ $gCheckBox_misc -eq 1 ]; then
                kill -0 $pidFilesMisc &> /dev/null || if [ $flagMS -eq 0 ]; then ((c++)); flagMS=1; fi
            fi
            if [ $c -eq $newProcessCount ]; then
                break
            fi
        done
        #wait
    fi
    
    newProcessCount=0
    if [ $gCheckBox_lspci -eq 1 ]; then
        ((newProcessCount++))
        DumpFilesLspci & pidFilesLspci=$! ; flagLS=0
        echo "$(($(date +%s)-gScriptRunTime))s : +Started process DumpFilesLspci: pid $pidFilesLspci" >> "${gLogFile}"
    fi
    if [ $gCheckBox_dmi -eq 1 ]; then
        ((newProcessCount++))
        DumpFilesDmiTables & pidFilesDmiTable=$! ; flagDT=0
        echo "$(($(date +%s)-gScriptRunTime))s : +Started process DumpFilesDmiTables: pid $pidFilesDmiTable" >> "${gLogFile}"
    fi
    if [ $gCheckBox_nvram -eq 1 ]; then
        ((newProcessCount++))
        DumpFilesNvramPlist & pidFilesNvramPlist=$! ; flagNP=0
        echo "$(($(date +%s)-gScriptRunTime))s : +Started process DumpFilesNvramPlist: pid $pidFilesNvramPlist" >> "${gLogFile}"
    fi
    if [ $gCheckBox_edid -eq 1 ]; then
        ((newProcessCount++))
        DumpFilesEdid & pidFilesEdid=$! ; flagED=0
        echo "$(($(date +%s)-gScriptRunTime))s : +Started process DumpFilesEdid: pid $pidFilesEdid" >> "${gLogFile}"
    fi
    if [ $newProcessCount -gt 0 ]; then 
        c=0
        while sleep 0.5; do      
            if [ $gCheckBox_lspci -eq 1 ]; then
                kill -0 $pidFilesLspci &> /dev/null || if [ $flagLS -eq 0 ]; then ((c++)); flagLS=1; fi
            fi
            if [ $gCheckBox_dmi -eq 1 ]; then
                kill -0 $pidFilesDmiTable &> /dev/null || if [ $flagDT -eq 0 ]; then ((c++)); flagDT=1; fi
            fi
            if [ $gCheckBox_nvram -eq 1 ]; then
                kill -0 $pidFilesNvramPlist &> /dev/null || if [ $flagNP -eq 0 ]; then ((c++)); flagNP=1; fi
            fi
            if [ $gCheckBox_edid -eq 1 ]; then
                kill -0 $pidFilesEdid &> /dev/null || if [ $flagED -eq 0 ]; then ((c++)); flagED=1; fi
            fi
            if [ $c -eq $newProcessCount ]; then
                break
            fi
        done
        #wait
    fi

    newProcessCount=0
    if [ $gCheckBox_ioreg -eq 1 ]; then
        ((newProcessCount++))
        DumpFilesIoreg & pidFilesIoreg=$! ; flagIO=0
        echo "$(($(date +%s)-gScriptRunTime))s : +Started process DumpFilesIoreg: pid $pidFilesIoreg" >> "${gLogFile}"
    fi
    if [ $newProcessCount -gt 0 ]; then
        c=0
        while sleep 0.5; do      
            if [ $gCheckBox_ioreg -eq 1 ]; then
                kill -0 $pidFilesIoreg &> /dev/null || if [ $flagIO -eq 0 ]; then ((c++)); flagIO=1; fi
            fi
            if [ $c -eq $newProcessCount ]; then
                break
            fi
        done
    fi
    
    if [ "$gRadio_privacy" == "Private" ]; then
        Privatise
    fi

    UnloadPciUtilsDriver

    dumpTime="$(($(date +%s)-gScriptRunTime))"
    echo "========================================================
Dumps complete after: ${dumpTime} seconds
--------------------------------------------------------" >> "${gLogFile}"

    # Did the user request the HTML report?
    if [ $gCheckBox_enablehtml -eq 1 ]; then
    
        # The audio codec ID is passed to the generateHTMLreport script
        # for adding to the header of the HTML report.
        # We get the audio codec easily using AnV's great tool from:
        # http://www.insanelymac.com/forum/topic/285277-getcodecid-command-line-tool-to-detect-codec-id/
        #
        # If the user selected to dump this then we already have it, otherwise
        # dump it here anyway.
        if [ "$codecID" == "" ]; then
            codecID=`$getcodecid`

            if [ "$codecID" == "" ]; then
    
                # Did we run VoodooHDA getdump?
                if [ -f "$gSYSinfoDir"/AudioDumpVoodoo.txt ]; then
                    codecID=`cat "$gSYSinfoDir"/AudioDumpVoodoo.txt | grep "HDA Codec #"`
                    codecID="${codecID##*: }"
                else
                    # Try running VoodooHDA getdump.
                    if [ $gRootPriv -eq 1 ]; then
                        echo "Attempting to get Audio Codec ID by running VoodooHDA's getdump." >> "${gLogFile}"
                        LoadVoodooHdaDriver
                        sleep 2
                        codecID=`$getdump | grep "HDA Codec #"`
                        codecID="${codecID##*: }"
                        UnloadVoodooHdaDriver  
                    fi
                fi 
            fi      
        fi
    
        # Did the user request the HTML divs be collapsed?
        if [ $gCheckBox_collapsetables -eq 1 ]; then
            tableState="none"
        else
            tableState="block"
        fi
        echo "S:enablehtml" >> /tmp/dd_completed
        # Build the html files.
        "$generateHTMLreport" "$gMasterDumpFolder" "$gtheprog" "$gtheVersion" "$tableState" "$codecID" "$gRadio_privacy"
        echo "F:enablehtml" >> /tmp/dd_completed
    fi
    
    # Finish up
    if [ $gButton_cancel -eq 0 ]; then
        CloseLog
        ArchiveDumpFolder
        Finish
    
        # To terminate the UI we write a file named dd_completed
        # to /tmp and populate it with the string "Done".
        echo "Done" >> /tmp/dd_completed
        if [ -f /tmp/dd_completed ]; then
            chmod 755 /tmp/dd_completed
            chown 501:20 /tmp/dd_completed
        fi
        exit 0
    fi
fi
