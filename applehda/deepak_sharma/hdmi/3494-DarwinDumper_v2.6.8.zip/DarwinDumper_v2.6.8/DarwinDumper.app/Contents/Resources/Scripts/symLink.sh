#!/bin/sh

appPath="$1"
task="$2"

if [ "$task" == "Create Symlink" ]; then
    ln -s "$appPath" /usr/local/bin/darwindumper
    echo "Created symlink /usr/local/bin/darwindumper pointing to $appPath"
elif [ "$task" == "Update Symlink" ]; then
    rm /usr/local/bin/darwindumper
    ln -s "$appPath" /usr/local/bin/darwindumper
    echo "Update symlink /usr/local/bin/darwindumper to point to $appPath"
elif [ "$task" == "Delete Symlink" ]; then
    rm /usr/local/bin/darwindumper
    echo "Deleted symlink /usr/local/bin/darwindumper"
fi